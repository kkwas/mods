#version 330 core
#extension GL_ARB_explicit_attrib_location: enable

layout(location = 0) in vec3 vertexPosition;
layout(location = 1) in vec4 normalIn;
layout(location = 2) in vec2 uvIn;
layout(location = 3) in vec3 particlePosition;
layout(location = 4) in float particleScale;
layout(location = 5) in float particleRotation;
layout(location = 6) in float particleEmissiveIntensity;
layout(location = 8) in vec4 particleColor;
layout(location = 9) in vec4 particleLight;
layout(location = 10) in vec4 particleMetadata;

uniform vec3 rgbaAmbientIn;
uniform mat4 projectionMatrix;
uniform mat4 modelViewMatrix;

out vec2 uv;
out vec4 color;
out vec3 emissive;
out float fogDistance;
out float glow;

void main()
{
    float cosine = cos(particleRotation);
    float sine = sin(particleRotation);
    mat3 rotation = mat3(
        cosine, 0.0, -sine,
        0.0, 1.0, 0.0,
        sine, 0.0, cosine
    );
    vec3 worldPosition = rotation * (vertexPosition * particleScale) + particlePosition;
    vec4 cameraPosition = modelViewMatrix * vec4(worldPosition, 1.0);
    vec3 normal = normalize(rotation * normalIn.xyz);
    float directionalLight = 0.55 + 0.45 * max(normal.y, 0.0);
    float sampledLight = max(max(particleLight.r, particleLight.g), particleLight.b);
    vec3 lighting = max(rgbaAmbientIn, vec3(sampledLight)) * directionalLight;

    uv = uvIn;
    color = particleColor * vec4(lighting, 1.0);
    color.a = particleColor.a;
    emissive = particleMetadata.rgb * particleEmissiveIntensity;
    fogDistance = length(cameraPosition.xyz);
    glow = clamp(particleEmissiveIntensity, 0.0, 1.0);
    gl_Position = projectionMatrix * cameraPosition;
}
