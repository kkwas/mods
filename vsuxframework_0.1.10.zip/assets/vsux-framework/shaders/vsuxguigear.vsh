#version 330 core
#extension GL_ARB_explicit_attrib_location: enable

layout(location = 0) in vec3 vertexPositionIn;
layout(location = 1) in vec2 uvIn;

uniform mat4 projectionMatrix;
uniform mat4 modelViewMatrix;

out vec2 uv;
out vec2 screenPosition;

void main(void)
{
    vec4 modelPosition = modelViewMatrix * vec4(vertexPositionIn, 1.0);
    gl_Position = projectionMatrix * modelPosition;
    uv = uvIn;
    screenPosition = modelPosition.xy;
}
