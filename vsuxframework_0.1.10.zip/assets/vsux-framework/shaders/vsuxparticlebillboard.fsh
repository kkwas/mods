#version 330 core
#extension GL_ARB_explicit_attrib_location: enable

in vec2 uv;
in vec2 localUv;
in vec4 color;
in vec3 emissive;
in float fogDistance;
in float glow;

uniform sampler2D particleTexture;
uniform int maskMode;
uniform float edgeSoftness;
uniform vec4 rgbaFogIn;
uniform float fogMinIn;
uniform float fogDensityIn;

#include oit.fsh

void main()
{
    vec4 outputColor = color;
    if (maskMode == 1)
    {
        float radius = length(localUv * 2.0 - 1.0);
        outputColor.a *= 1.0 - smoothstep(1.0 - max(0.08, edgeSoftness), 1.0, radius);
    }
    else if (maskMode == 2)
    {
        outputColor *= texture(particleTexture, uv);
    }

    // Feather square coverage in frame-local UVs, as native torch quads do.
    // Texture alpha still controls the internal silhouette; feathering requires no extra texture samples.
    if (maskMode != 1 && edgeSoftness > 0.0)
    {
        vec2 edgeDistance = max(abs(localUv * 2.0 - 1.0) - (1.0 - edgeSoftness), vec2(0.0));
        outputColor.a *= clamp(1.0 - length(edgeDistance) / edgeSoftness, 0.0, 1.0);
    }

    if (outputColor.a <= 0.001)
    {
        discard;
    }

    // OIT expects straight RGB and applies coverage alpha during accumulation.
    // Applying alpha here too makes emissive particles fade quadratically.
    outputColor.rgb += emissive;
    float fogAmount = clamp(fogMinIn + 1.0 - exp(-fogDistance * fogDensityIn), 0.0, 1.0);
    outputColor.rgb = mix(outputColor.rgb, rgbaFogIn.rgb, fogAmount);
    OIT(clamp(outputColor, vec4(0.0), vec4(1.0)), glow);
}
