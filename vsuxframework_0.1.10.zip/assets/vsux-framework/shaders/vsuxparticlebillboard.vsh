#version 330 core
#extension GL_ARB_explicit_attrib_location: enable

layout(location = 0) in vec3 vertexPosition;
layout(location = 1) in vec2 uvIn;
layout(location = 2) in vec4 baseColor;
layout(location = 3) in vec3 particlePosition;
layout(location = 4) in float particleScale;
layout(location = 5) in float particleRotation;
layout(location = 6) in float particleEmissiveIntensity;
layout(location = 7) in float particleFrame;
layout(location = 8) in vec4 particleColor;
layout(location = 9) in vec4 particleLight;
layout(location = 10) in vec4 particleMetadata;

uniform vec3 rgbaAmbientIn;
uniform mat4 projectionMatrix;
uniform mat4 modelViewMatrix;
uniform int spriteSheetColumns;
uniform int spriteSheetRows;

out vec2 uv;
out vec2 localUv;
out vec4 color;
out vec3 emissive;
out float fogDistance;
out float glow;

void main()
{
    float cosine = cos(particleRotation);
    float sine = sin(particleRotation);
    vec2 rotated = mat2(cosine, -sine, sine, cosine) * vertexPosition.xy;
    vec4 cameraPosition = modelViewMatrix * vec4(particlePosition, 1.0);
    cameraPosition.xy += rotated * particleScale;

    float sampledLight = max(max(particleLight.r, particleLight.g), particleLight.b);
    vec3 lighting = max(rgbaAmbientIn, vec3(sampledLight));
    vec2 spriteGrid = vec2(max(spriteSheetColumns, 1), max(spriteSheetRows, 1));
    float frame = clamp(floor(particleFrame + 0.5), 0.0, spriteGrid.x * spriteGrid.y - 1.0);
    vec2 spriteCell = vec2(mod(frame, spriteGrid.x), floor(frame / spriteGrid.x));
    uv = (uvIn + spriteCell) / spriteGrid;
    localUv = uvIn;
    color = baseColor * particleColor * vec4(lighting, 1.0);
    color.a = baseColor.a * particleColor.a;
    emissive = particleMetadata.rgb * particleEmissiveIntensity;
    fogDistance = length(cameraPosition.xyz);
    glow = clamp(particleEmissiveIntensity, 0.0, 1.0);
    gl_Position = projectionMatrix * cameraPosition;
}
