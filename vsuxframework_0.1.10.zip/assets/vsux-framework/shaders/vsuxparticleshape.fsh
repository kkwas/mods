#version 330 core
#extension GL_ARB_explicit_attrib_location: enable

in vec2 uv;
in vec4 color;
in vec3 emissive;
in float fogDistance;
in float glow;

uniform sampler2D particleTexture;
uniform vec4 rgbaFogIn;
uniform float fogMinIn;
uniform float fogDensityIn;

#include oit.fsh

void main()
{
    vec4 outputColor = texture(particleTexture, uv) * color;
    if (outputColor.a <= 0.001)
    {
        discard;
    }

    // OIT expects straight RGB and applies coverage alpha during accumulation.
    // Applying alpha here too makes emissive particles fade quadratically.
    outputColor.rgb += emissive;
    float fogAmount = clamp(fogMinIn + 1.0 - exp(-fogDistance * fogDensityIn), 0.0, 1.0);
    outputColor.rgb = mix(outputColor.rgb, rgbaFogIn.rgb, fogAmount);
    OIT(clamp(outputColor, vec4(0.0), vec4(1.0)), glow);
}
