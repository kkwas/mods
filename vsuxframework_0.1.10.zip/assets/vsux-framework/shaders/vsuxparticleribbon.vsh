#version 330 core
#extension GL_ARB_explicit_attrib_location: enable

layout(location = 0) in vec3 vertexPosition;
layout(location = 1) in vec2 uvIn;
layout(location = 2) in vec4 baseColor;
layout(location = 3) in float ribbonEmissiveIntensity;
layout(location = 4) in vec4 ribbonMetadata;

uniform vec3 rgbaAmbientIn;
uniform mat4 projectionMatrix;
uniform mat4 modelViewMatrix;

out vec2 uv;
out vec4 color;
out vec3 emissive;
out float fogDistance;
out float glow;

void main()
{
    vec4 cameraPosition = modelViewMatrix * vec4(vertexPosition, 1.0);
    color = baseColor * vec4(rgbaAmbientIn, 1.0);
    color.a = baseColor.a;
    uv = uvIn;
    emissive = ribbonMetadata.rgb * ribbonEmissiveIntensity;
    fogDistance = length(cameraPosition.xyz);
    glow = clamp(ribbonEmissiveIntensity, 0.0, 1.0);
    gl_Position = projectionMatrix * cameraPosition;
}
