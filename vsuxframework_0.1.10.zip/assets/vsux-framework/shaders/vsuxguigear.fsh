#version 330 core

in vec2 uv;
in vec2 screenPosition;

out vec4 outColor;

uniform sampler2D tex2d;
uniform vec4 poweredColor;
uniform vec4 depletedColor;
uniform float stabilityLevel;
uniform float shadeYPos;
uniform float gearHeight;
uniform float hotbarYPos;

void main(void)
{
    vec4 sourceColor = texture(tex2d, uv);
    if (sourceColor.a <= 0.01)
    {
        discard;
    }

    float drawableHeight = max(gearHeight - 10.0, 1.0);
    float relativeY = (screenPosition.y - hotbarYPos + drawableHeight * 0.685) / drawableHeight;
    float levelFromBottom = 1.0 - relativeY;
    float poweredEdge = 0.5 + stabilityLevel / 2.0;
    float poweredAmount = smoothstep(-0.0125, 0.0125, poweredEdge - levelFromBottom);
    vec4 themedColor = mix(depletedColor, poweredColor, poweredAmount);

    float sourceLuminance = dot(sourceColor.rgb, vec3(0.2126, 0.7152, 0.0722));
    float nativeRelief = mix(0.72, 1.16, smoothstep(0.0, 0.9, sourceLuminance));
    float hotbarShade = 1.0 - max(0.0, screenPosition.y - shadeYPos) / 15.0;
    float alpha = themedColor.a * sourceColor.a;
    outColor = vec4(themedColor.rgb * nativeRelief * hotbarShade, alpha);
}
