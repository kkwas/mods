#version 330 core

const float PI = 3.14159265358979323846;

in vec2 uv;
in float dist;
in vec4 rgbaFog;
in float fogAmount;

out vec4 outColor;

uniform sampler2D primaryFb;
uniform sampler2D depthTex;
uniform vec2 invFrameSize;
uniform float counter;
uniform float counterSmooth;
uniform vec3 projectilePrimaryColor;
uniform float u_time;

#include noise2d.ash
#include fogandlight.fsh

float hash21(vec2 p)
{
    p = fract(p * vec2(123.34, 456.21));
    p += dot(p, p + 45.32);
    return fract(p.x * p.y);
}

float ringMask(float radius, float center, float width)
{
    return 1.0 - smoothstep(width, width * 2.0, abs(radius - center));
}

void main()
{
    vec2 screenUv = gl_FragCoord.xy * invFrameSize;

    float sceneDepth = linearDepth(texture(depthTex, screenUv).r);
    float fragmentDepth = linearDepth(gl_FragCoord.z);
    float depthDifference = max(0.0, fragmentDepth - sceneDepth) * 10000.0;

    if (depthDifference > 2.0)
    {
        discard;
    }

    vec2 p = uv * 2.0 - 1.0;
    float radius = length(p);
    float angle = atan(p.y, p.x);

    if (radius > 1.0)
    {
        discard;
    }

    float time = u_time;

    /*
     * Gravitational lensing. The framebuffer is sampled away from the
     * singularity, bending the scene around the black core.
     */
    vec2 radialDirection = p / max(radius, 0.0001);
    float lensFalloff = 1.0 - smoothstep(0.18, 0.92, radius);
    float lensStrength = 0.055 * lensFalloff / max(radius + 0.12, 0.12);
    vec2 lensedUv = screenUv + radialDirection * lensStrength;

    vec3 background = texture(primaryFb, lensedUv).rgb;

    /* Event horizon and photon ring. */
    float eventHorizonRadius = 0.245;
    float eventHorizon = 1.0 - smoothstep(
        eventHorizonRadius - 0.012,
        eventHorizonRadius + 0.012,
        radius
    );

    float photonRing = ringMask(radius, 0.295, 0.012);
    float outerLensGlow = ringMask(radius, 0.355, 0.035);

    /*
     * Accretion disk. It is flattened into an ellipse and split into front
     * and back portions so the disk appears to wrap around the black hole.
     */
    vec2 diskPoint = vec2(p.x, p.y * 3.15);
    float diskRadius = length(diskPoint);
    float diskAngle = atan(diskPoint.y, diskPoint.x);

    float diskBand = smoothstep(0.30, 0.36, diskRadius)
        * (1.0 - smoothstep(0.84, 0.98, diskRadius));

    float innerHeat = 1.0 - smoothstep(0.32, 0.88, diskRadius);

    float spiralNoise = cnoise2(vec2(
        diskAngle * 3.0 - time * 1.8,
        diskRadius * 13.0 - time * 0.65
    ));

    float fineNoise = cnoise2(vec2(
        diskAngle * 11.0 + time * 2.5,
        diskRadius * 31.0
    ));

    float streaks = 0.58
        + spiralNoise * 0.30
        + fineNoise * 0.12;

    streaks = smoothstep(0.28, 0.88, streaks);

    float frontDisk = diskBand * smoothstep(-0.08, 0.14, p.y);
    float backDisk = diskBand * (1.0 - smoothstep(-0.14, 0.08, p.y));

    /* The back half is partially hidden by the event horizon. */
    backDisk *= 1.0 - eventHorizon;

    float diskIntensity = diskBand * streaks;

    vec3 coolColor = max(projectilePrimaryColor, vec3(0.12, 0.03, 0.18));
    vec3 hotColor = vec3(1.0, 0.72, 0.30);
    vec3 whiteHot = vec3(1.0, 0.96, 0.82);

    vec3 diskColor = mix(coolColor, hotColor, innerHeat);
    diskColor = mix(diskColor, whiteHot, pow(innerHeat, 4.0) * 0.72);

    /* Mild Doppler-style brightness difference across the disk. */
    float directionalBoost = 0.72 + 0.52 * smoothstep(-1.0, 1.0, cos(diskAngle));
    diskColor *= directionalBoost;

    vec3 color = background;

    /* Darken the strongly lensed region before adding the luminous disk. */
    float lensShadow = (1.0 - smoothstep(0.24, 0.57, radius)) * (1.0 - eventHorizon);
    color *= 1.0 - lensShadow * 0.42;

    color += diskColor * backDisk * diskIntensity * 0.72;

    vec3 photonColor = mix(hotColor, whiteHot, 0.72);
    color += photonColor * photonRing * 2.45;
    color += coolColor * outerLensGlow * 0.42;

    /* The event horizon is fully black. */
    color = mix(color, vec3(0.0), eventHorizon);

    color += diskColor * frontDisk * diskIntensity * 1.38;

    /* A subtle, irregular outer halo keeps the edge from looking synthetic. */
    float haloNoise = 0.65 + 0.35 * cnoise2(vec2(angle * 5.0, time * 0.22));
    float halo = ringMask(radius, 0.72, 0.16) * haloNoise * 0.12;
    color += coolColor * halo;

    float alpha = 1.0 - smoothstep(0.76, 1.0, radius);
    alpha = max(alpha, diskBand * 0.95);
    alpha = max(alpha, photonRing);
    alpha = max(alpha, eventHorizon);
    alpha = clamp(alpha - depthDifference, 0.0, 1.0);

    alpha -= clamp(
        (dist * (1.0 + fogAmount * 0.5) - 50.0) / 40.0,
        0.0,
        0.7 + fogAmount * 0.3
    );

    if (alpha < 0.015)
    {
        discard;
    }

    outColor = applyFog(vec4(color, clamp(alpha, 0.0, 1.0)), fogAmount);
}
