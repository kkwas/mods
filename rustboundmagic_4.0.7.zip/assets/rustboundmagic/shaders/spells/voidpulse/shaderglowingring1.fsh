#version 330 core

const float PI = 3.1415926535897932384626433832795;

in vec2 uv;
in float dist;
in vec4 rgbaFog;
in float fogAmount;


out vec4 outColor;

uniform int riftIndex;
uniform sampler2D primaryFb;
uniform sampler2D depthTex;
uniform vec2 invFrameSize;
uniform float counter;
uniform float counterSmooth;

uniform vec3 projectilePrimaryColor;
uniform float u_time;

#include noise2d.ash
#include fogandlight.fsh


void main()
{
	float x = gl_FragCoord.x * invFrameSize.x;
	float y = gl_FragCoord.y * invFrameSize.y;
	
	float z1 = linearDepth(texture(depthTex, vec2(x,y)).r); //depth from gbuffer depth, a float32 texture
	float z2 = linearDepth(gl_FragCoord.z);
	

	//float aDiff = max(0, z2 - z1) * 10; // Makes the shader appear over all blocks.
	float aDiff = max(0, z2 - z1) * 10000; //Makes the shader disappear in solid blocks.
	if (aDiff > 2) discard;
	
	float f = length(uv - 0.5) * 2;

	// Radius of the orb.
	float ringRadius = 0.75;

	// Completely remove anything outside the orb.
	float outerMask =
		1.0 - smoothstep(
			ringRadius,
			ringRadius + 0.03,
			f
		);

	// Density increases toward the outer shell.
	float shellDensity =
		smoothstep(
			0.18,
			ringRadius,
			f
		);

	// Control how quickly it fades inward.
	shellDensity = pow(shellDensity, 2.5);



	// -------------------------------------------------------------------------
	// Combined black-hole style screen distortion
	//
	// 1. Gravitational lensing bends the background radially around the shell.
	// 2. Turbulence adds animated, irregular ripples.
	// 3. Swirl twists the background around the center of the orb.
	// -------------------------------------------------------------------------
	vec2 screenUV = vec2(x, y);
	vec2 orbDelta = uv - vec2(0.5);
	float orbLength = length(orbDelta);
	vec2 radialDirection = orbLength > 0.0001
		? orbDelta / orbLength
		: vec2(0.0);
	vec2 tangentDirection = vec2(-radialDirection.y, radialDirection.x);

	// 0.0 at the center, 1.0 at the visible shell.
	float distortionRadial = clamp(f / ringRadius, 0.0, 1.0);

	// Master distortion control. Raise this for a stronger black-hole effect.
	float distortionStrength = 5.75;

	// Gravitational lensing is strongest close to the outer shell and weaker
	// toward the center. The sign controls whether the image appears pulled
	// inward or pushed outward.
	// Broad lensing band. This remains visible across most of the orb instead
	// of existing only in a very narrow strip at the shell.
	float lensBand =
		smoothstep(0.08, 0.55, distortionRadial)
		* (1.0 - smoothstep(0.88, 1.02, distortionRadial));

	float lensAmount =
		0.028 * distortionStrength * lensBand;

	// Animated turbulence. Two noise layers prevent the warp from looking like
	// a uniform circular ripple.
	float distortionTime = counter * 0.55 + u_time * 0.25;
	float turbulenceA = cnoise2(vec2(
		orbDelta.x * 11.0 + distortionTime,
		orbDelta.y * 11.0 - distortionTime * 0.73
	));
	float turbulenceB = cnoise2(vec2(
		orbDelta.y * 23.0 - distortionTime * 1.21,
		orbDelta.x * 23.0 + distortionTime * 0.91
	));
	float turbulence = turbulenceA * 0.68 + turbulenceB * 0.32;
	float turbulenceMask = outerMask * smoothstep(0.08, 0.92, distortionRadial);
	float turbulenceAmount = 0.009 * distortionStrength * turbulenceMask;

	// Swirling distortion grows toward the center, but fades at the exact
	// center to avoid a singular pinching artifact.
	float swirlMask = pow(1.0 - distortionRadial, 1.35)
		* smoothstep(0.02, 0.18, distortionRadial)
		* outerMask;
	float swirlAmount = 0.026 * distortionStrength * swirlMask;

	vec2 distortionOffset = vec2(0.0);

	// Radial gravitational bend.
	distortionOffset -= radialDirection * lensAmount;

	// Turbulent ripple with both radial and tangential motion.
	distortionOffset += radialDirection
		* turbulence
		* turbulenceAmount;
	distortionOffset += tangentDirection
		* turbulenceB
		* turbulenceAmount
		* 0.75;

	// Rotational black-hole twist.
	distortionOffset += tangentDirection * swirlAmount;

	// Keep the texture lookup on-screen.
	vec2 distortedScreenUV = clamp(
		screenUV + distortionOffset,
		invFrameSize,
		vec2(1.0) - invFrameSize
	);

	vec4 col = texture(primaryFb, distortedScreenUV);
	
	


	
	float seed = 1/1000.0 + counterSmooth / 1000.0;
	// Makes the outer circle effect
	//float spikeNoise = cnoise2(vec2(riftIndex, f * counterSmooth/10.0)) + cnoise2(vec2(riftIndex + 4, f * counterSmooth/10000.0)) / 200.0;
	float spikeNoise = cnoise2(vec2(riftIndex, f * counterSmooth/1.0)) + cnoise2(vec2(riftIndex + 4, f * counterSmooth/10.0)) / 150.0;
	
	float angle = mod(atan(uv.y - 0.5, uv.x - 0.5) + spikeNoise, 2*3.14159);
	

	// Animated noise around the circumference. These layers preserve the
	// flowing, wispy movement of the original shader.
	float broadWispNoise =
		cnoise2(vec2(angle * 4.0, seed * 1.35)) * 1.55
		+ cnoise2(vec2(angle * 9.0 - seed * 0.65, seed * 2.10)) * 0.30
		+ cnoise2(vec2(angle * 20.0 + seed * 0.30, seed * 3.70)) * 0.15;

	broadWispNoise = clamp(
		broadWispNoise * 0.5 + 0.5,
		0.0,
		1.0
	);

	// Radial detail causes the strands to curl, break apart, and move instead
	// of forming smooth triangular wedges.
	float flowingDetail =
		cnoise2(vec2(
			angle * 17.0 + f * 7.0 - seed * 1.8,
			seed * 3.0 + f * 9.0
		)) * 0.30
		+ cnoise2(vec2(
			angle * 38.0 - f * 13.0 + seed * 0.9,
			seed * 5.0 - f * 6.0
		)) * 0.20;

	flowingDetail = clamp(
		flowingDetail * 0.5 + 0.5,
		0.0,
		1.0
	);

	// 0.0 is the center and 1.0 is the outer edge.
	float radial = clamp(
		f / ringRadius,
		0.0,
		1.0
	);

	// Warp the radial coordinate with moving noise. This is what restores the
	// inward-curling wisps while keeping them densest at the outer shell.
	float radialWarp =
		(broadWispNoise - 0.5) * 0.34
		+ (flowingDetail - 0.5) * 0.16;

	float warpedRadial = clamp(
		radial + radialWarp * (1.0 - radial * 0.35),
		0.0,
		1.0
	);

	// Bright, dense outer ring.
	float shell = smoothstep(
		0.7,
		1.0,
		warpedRadial
	);

	// Wisps extend inward from the shell. Noise controls their penetration
	// depth, and a soft edge prevents a hollow-looking center.
	float inwardReach = mix(
		0.65,
		0.98,
		pow(broadWispNoise, 1.15)
	);

	float wispInnerEdge = 1.0 - inwardReach;

	float inwardWisps = smoothstep(
		wispInnerEdge - 0.16,
		wispInnerEdge + 0.20,
		warpedRadial
	);

	// Break the inward layer into animated strands. The nonzero minimum keeps
	// soft traces visible instead of cutting the center into a transparent hole.
	float wispBreakup = mix(
		0.18,
		1.0,
		smoothstep(0.16, 0.82, flowingDetail)
	);

	float wispEnergy = inwardWisps * wispBreakup;

	// Faint moving energy remains in the center. It is intentionally much
	// weaker than the ring, giving a dense-to-sparse inward gradient without
	// leaving the middle completely empty.
	float centerNoise = clamp(
		cnoise2(vec2(
			angle * 11.0 + seed * 1.7,
			f * 12.0 - seed * 2.4
		)) * 0.5 + 0.5,
		0.0,
		1.0
	);

	float centerHaze =
		pow(1.0 - radial, 0.75)
		* mix(0.10, 0.28, centerNoise);

	float energyAlpha =
		shell * 0.82
		+ wispEnergy * 0.72
		+ centerHaze;

	// Nothing is rendered outside the orb.
	col.a = clamp(
		energyAlpha * outerMask,
		0.0,
		1.0
	);

	// Preserve soft translucent strands. A low exponent gives definition
	// without crushing the wisps back into invisibility.
	col.a = pow(col.a, 1.20);

	col.a = clamp(
		col.a - aDiff,
		0.0,
		1.0
	);

	col.a -= clamp(
		(dist * (1.0 + fogAmount / 2.0) - 50.0) / 40.0,
		0.0,
		0.7 + fogAmount * 0.3
	);



	// Apply black outline
    //if (outlineMask > 0.0) {
    //    col.rgb = vec3(0.0); // Set color to black for the outline
    //    col.a = outlineMask; // Set the alpha for the outline
    //}

	// Apply the black outline to the inner ring
    //if (innerRingOutlineMask > 0.0) {
    //    col.rgb = vec3(0.0); // Black outline
    //    col.a = innerRingOutlineMask; // Alpha for outline visibility
    //}






	vec2 coord = gl_FragCoord.xy;

	float sin_factor = sin(u_time);
    float cos_factor = cos(u_time);

	coord = vec2((coord.x - 0.5) * (gl_FragCoord.x / gl_FragCoord.y), coord.y - 0.5) * mat2(cos_factor, sin_factor, -sin_factor, cos_factor);

	coord += 0.5;

	if (col.a < 0.02) discard;
	
	vec3 rust = vec3(
			(col.r * 0.393) + (col.g * 0.769) + (col.b * 0.189),
			(col.r * 0.349) + (col.g * 0.686) + (col.b * 0.168),
			(col.r * 0.272) + (col.g * 0.534) + (col.b * 0.131)
	);
	
	float fg = 1 + clamp(f * 20 - 2, 0.13, 1) * cnoise2(vec2(angle*20, seed));
	
	rust.r *= fg;
	rust.g /= fg;
	
	

	rust = vec3(
	projectilePrimaryColor.r,
	projectilePrimaryColor.g,
	projectilePrimaryColor.b
	);
	
	//float gdiff = min(col.g, 0.1);
	//float bdiff = min(col.b, 0.1);
	//rust.g -= gdiff;
	//rust.b -= bdiff;
	//rust.r += gdiff + bdiff;

	
	// Keep the distorted framebuffer visible. The old value of 1.0 here
	// replaced the sampled background completely with the solid projectile
	// color, which erased all visible lensing.
	float colorTint =
		clamp(
			0.18
			+ shell * 0.52
			+ wispEnergy * 0.30,
			0.0,
			0.82
		);

	col.rgb = mix(
		col.rgb,
		rust,
		colorTint
	);

	// Add a small emissive contribution without hiding the warped scene.
	col.rgb += rust * shell * 0.12;
	
	outColor = applyFog(col, fogAmount);
}