#version 330 core

const float PI = 3.1415926535897932384626433832795;

in vec2 uv;
in float dist;
in vec4 rgbaFog;
in float fogAmount;

out vec4 outColor;

uniform sampler2D primaryFb;
uniform sampler2D depthTex;

uniform vec2 invFrameSize;
uniform vec3 projectilePrimaryColor;

uniform float projectileSize;
uniform float effectProgress;
uniform float layerSeed;
uniform float layerOpacity;

uniform float counter;
uniform float counterSmooth;
uniform float u_time;

#include noise2d.ash
#include fogandlight.fsh


float saturate(float value)
{
    return clamp(value, 0.0, 1.0);
}


float inverseSmoothstep(float edge0, float edge1, float value)
{
    return 1.0 - smoothstep(edge0, edge1, value);
}


float remap01(float value, float startValue, float endValue)
{
    return saturate(
        (value - startValue)
        / max(endValue - startValue, 0.00001)
    );
}


float pulse(float value, float startValue, float peakValue, float endValue)
{
    float rise = smoothstep(startValue, peakValue, value);
    float fall = 1.0 - smoothstep(peakValue, endValue, value);

    return rise * fall;
}


void main()
{
    vec2 screenUV = gl_FragCoord.xy * invFrameSize;

    float sceneDepth = linearDepth(
        texture(depthTex, screenUV).r
    );

    float fragmentDepth = linearDepth(gl_FragCoord.z);

    float depthDifference =
        max(0.0, fragmentDepth - sceneDepth)
        * 10000.0;

    if (depthDifference > 2.0)
    {
        discard;
    }

    float progress = saturate(effectProgress);

    /*
        The shared projectile quad uses UV coordinates from 0 to 1.
        Keep the effect inside most of the quad so the corners remain clear.
    */
    vec2 centeredUV = uv - vec2(0.5);
    float radial = length(centeredUV) / 0.48;

    /*
        Circular billboard mask. The quad itself is square, so the effect
        must become fully transparent before reaching its left/right/top/
        bottom edges. This prevents the explosion from appearing clipped
        into a square.
    */
    float circularBounds =
        1.0 - smoothstep(
            0.91,
            1.01,
            radial
        );

    vec2 radialDirection =
        length(centeredUV) > 0.0001
        ? normalize(centeredUV)
        : vec2(0.0);

    vec2 tangentDirection = vec2(
        -radialDirection.y,
        radialDirection.x
    );

    float angle = atan(
        centeredUV.y,
        centeredUV.x
    );

    float time =
        counter * 0.60
        + u_time * 0.22
        + layerSeed * 4.73;

    // ------------------------------------------------------------
    // TIMING
    //
    // 0.00 - 0.24 : corpse compresses inward
    // 0.22 - 0.47 : internal rupture and blast
    // 0.43 - 1.00 : expanding shockwave and residue
    // ------------------------------------------------------------

    float collapseProgress =
        remap01(progress, 0.00, 0.24);

    float ruptureProgress =
        remap01(progress, 0.22, 0.47);

    float residueProgress =
        remap01(progress, 0.43, 1.00);

    float collapseLife =
        smoothstep(0.00, 0.055, progress)
        * inverseSmoothstep(0.235, 0.34, progress);

    float ruptureFlash =
        pulse(progress, 0.215, 0.285, 0.39);

    float blastLife =
        smoothstep(0.22, 0.29, progress)
        * inverseSmoothstep(0.67, 1.00, progress);

    float residueLife =
        smoothstep(0.40, 0.50, progress)
        * inverseSmoothstep(0.78, 1.00, progress);

    // ------------------------------------------------------------
    // ORGANIC NOISE
    // ------------------------------------------------------------

    float broadNoise =
        cnoise2(vec2(
            angle * 3.4 + time * 0.31,
            radial * 4.8 - time * 0.82
        )) * 0.56
        +
        cnoise2(vec2(
            angle * 8.7 - time * 0.68,
            radial * 11.3 + time * 0.44
        )) * 0.30
        +
        cnoise2(vec2(
            angle * 18.0 + layerSeed * 8.0,
            radial * 24.0 - time * 1.12
        )) * 0.14;

    broadNoise = broadNoise * 0.5 + 0.5;

    float fineNoise =
        cnoise2(vec2(
            centeredUV.x * 31.0 + time * 1.08,
            centeredUV.y * 31.0 - time * 0.83
        )) * 0.64
        +
        cnoise2(vec2(
            centeredUV.y * 66.0 - time * 1.53,
            centeredUV.x * 66.0 + time * 1.27
        )) * 0.36;

    fineNoise = fineNoise * 0.5 + 0.5;

    float veinNoise =
        cnoise2(vec2(
            angle * 12.5
                - time * 1.55
                + radial * 4.0,
            radial * 9.5
                + time * 1.76
                + layerSeed * 7.0
        )) * 0.5 + 0.5;

    // ------------------------------------------------------------
    // PHASE 1: INWARD COLLAPSE
    // ------------------------------------------------------------

    float collapsingRadius =
        mix(
            1.04,
            0.12,
            pow(collapseProgress, 0.78)
        );

    float collapseBand =
        1.0 - smoothstep(
            0.05,
            0.23,
            abs(radial - collapsingRadius)
        );

    float spiralCoordinate =
        angle * 5.0
        + radial * 11.0
        - time * 4.2
        - collapseProgress * 7.0;

    float spiralLines =
        0.5 + 0.5 * sin(spiralCoordinate);

    spiralLines =
        smoothstep(
            0.68,
            0.94,
            spiralLines * 0.55
                + veinNoise * 0.45
        );

    float inwardTendrils =
        collapseLife
        * spiralLines
        * inverseSmoothstep(0.06, 1.10, radial)
        * smoothstep(0.015, 0.15, radial);

    inwardTendrils *=
        0.24
        + collapseBand * 1.10;

    float compressedCoreRadius =
        mix(0.24, 0.055, collapseProgress);

    float compressedCore =
        collapseLife
        * inverseSmoothstep(
            compressedCoreRadius * 0.25,
            compressedCoreRadius,
            radial
        );

    // ------------------------------------------------------------
    // PHASE 2: VIOLENT RUPTURE
    // ------------------------------------------------------------

    float blastRadius =
        mix(
            0.045,
            1.10,
            pow(ruptureProgress, 0.63)
        );

    /*
        Angular spikes break the expanding shell out of a smooth bubble shape.
        Two different spike frequencies are combined so the silhouette looks
        torn and necrotic instead of like a regular star.
    */
    float coarseSpikes =
        pow(
            max(
                0.0,
                sin(
                    angle * 11.0
                    + time * 0.85
                    + broadNoise * 3.4
                )
            ),
            5.0
        );

    float fineSpikes =
        pow(
            max(
                0.0,
                sin(
                    angle * 19.0
                    - time * 0.55
                    + fineNoise * 4.2
                )
            ),
            8.0
        );

    float spikeField =
        coarseSpikes * 0.72
        + fineSpikes * 0.38;

    /*
        Spikes grow during the rupture and soften slightly near the end.
    */
    float spikeStrength =
        spikeField
        * smoothstep(0.08, 0.42, ruptureProgress)
        * inverseSmoothstep(0.72, 1.0, residueProgress);

    /*
        Limit the outer radius so even the longest spikes remain inside
        the circular part of the billboard instead of striking the square
        quad boundary.
    */
    float irregularBlastRadius =
        min(
            0.885,
            blastRadius
                + (broadNoise - 0.5) * 0.15
                + (fineNoise - 0.5) * 0.040
                + spikeStrength * 0.19
        );

    float insideBlast =
        1.0 - smoothstep(
            irregularBlastRadius - 0.10,
            irregularBlastRadius + 0.025,
            radial
        );

    float blastFront =
        1.0 - smoothstep(
            0.025,
            0.145,
            abs(radial - irregularBlastRadius)
        );

    float tornEdge =
        blastFront
        * smoothstep(0.34, 0.81, broadNoise)
        * blastLife;

    /*
        Brighter, sharper material at the tips of the shell spikes.
    */
    float spikeTips =
        blastFront
        * spikeField
        * blastLife
        * smoothstep(0.18, 0.66, ruptureProgress);

    float blastInterior =
        insideBlast
        * blastLife
        * mix(0.58, 1.0, fineNoise);

    float branchingVeins =
        insideBlast
        * blastLife
        * smoothstep(
            0.72,
            0.92,
            veinNoise * 0.58
                + fineNoise * 0.42
        );

    float hotCoreRadius =
        mix(0.23, 0.035, ruptureProgress);

    float hotCore =
        ruptureFlash
        * inverseSmoothstep(
            hotCoreRadius * 0.28,
            hotCoreRadius,
            radial
        );

    // ------------------------------------------------------------
    // PHASE 3: SHOCKWAVE AND NECROTIC RESIDUE
    // ------------------------------------------------------------

    float shockwaveRadius =
        mix(
            0.08,
            1.38,
            pow(residueProgress, 0.66)
        );

    float irregularShockwaveRadius =
        shockwaveRadius
        + (broadNoise - 0.5) * 0.052;

    float shockwave =
        1.0 - smoothstep(
            0.012,
            0.058,
            abs(radial - irregularShockwaveRadius)
        );

    shockwave *=
        inverseSmoothstep(0.72, 1.0, residueProgress);

    float innerShockwave =
        1.0 - smoothstep(
            0.016,
            0.068,
            abs(
                radial
                - irregularShockwaveRadius * 0.84
            )
        );

    innerShockwave *=
        residueLife
        * inverseSmoothstep(0.72, 1.0, residueProgress);

    float residueHaze =
        residueLife
        * inverseSmoothstep(0.04, 1.18, radial)
        * smoothstep(0.26, 0.70, broadNoise)
        * mix(0.42, 0.78, fineNoise);

    float blastFill =
        insideBlast
        * blastLife
        * inverseSmoothstep(0.06, 1.04, radial)
        * mix(0.42, 0.82, broadNoise);

    float middleCloud =
        insideBlast
        * blastLife
        * inverseSmoothstep(0.18, 0.92, radial)
        * mix(0.35, 0.72, fineNoise);

    // ------------------------------------------------------------
    // FRAMEBUFFER DISTORTION
    //
    // Pull inward during compression.
    // Push outward during rupture.
    // Refract around the shockwave afterward.
    // ------------------------------------------------------------

    float collapseLens =
        collapseLife
        * inverseSmoothstep(0.10, 1.08, radial)
        * smoothstep(0.025, 0.17, radial);

    float turbulentOffset =
        (fineNoise - 0.5)
        * (
            collapseLife
            + blastLife * 1.35
        );

    vec2 distortionOffset = vec2(0.0);

    distortionOffset -=
        radialDirection
        * collapseLens
        * 0.052;

    distortionOffset +=
        tangentDirection
        * collapseLens
        * (veinNoise - 0.5)
        * 0.026;

    distortionOffset +=
        radialDirection
        * blastFront
        * ruptureFlash
        * 0.086;

    distortionOffset +=
        radialDirection
        * shockwave
        * 0.055;

    distortionOffset +=
        radialDirection
        * turbulentOffset
        * 0.016;

    distortionOffset +=
        tangentDirection
        * turbulentOffset
        * 0.011;

    vec2 distortedScreenUV = clamp(
        screenUV + distortionOffset,
        invFrameSize,
        vec2(1.0) - invFrameSize
    );

    vec4 sceneColor =
        texture(primaryFb, distortedScreenUV);

    // ------------------------------------------------------------
    // COLOR
    //
    // Necromancy palette:
    // - void-black body
    // - blood-red rupture
    // - purple corruption
    // - sparse sickly-green soul energy
    // ------------------------------------------------------------

    vec3 bloodColor = projectilePrimaryColor;

    if (length(bloodColor) < 0.01)
    {
        bloodColor = vec3(
            0.52,
            0.012,
            0.035
        );
    }

    vec3 voidBlack = vec3(
        0.004,
        0.002,
        0.009
    );

    vec3 blackPurple = vec3(
        0.025,
        0.004,
        0.045
    );

    vec3 deepBlood = vec3(
        0.15,
        0.002,
        0.012
    );

    vec3 necroticCrimson = vec3(
        0.58,
        0.012,
        0.055
    );

    vec3 necroticPurple = vec3(
        0.24,
        0.012,
        0.39
    );

    vec3 brightPurple = vec3(
        0.46,
        0.045,
        0.72
    );

    vec3 sicklyGreen = vec3(
        0.12,
        0.48,
        0.10
    );

    vec3 soulGreen = vec3(
        0.34,
        0.86,
        0.22
    );

    vec3 ruptureFlashColor = vec3(
        0.95,
        0.16,
        0.30
    );

    /*
        Animated fragment masks prevent the palette from blending into brown.
        Each color occupies its own noisy regions.
    */
    float redFragments =
        smoothstep(
            0.44,
            0.75,
            fineNoise * 0.58
                + broadNoise * 0.42
        );

    float purpleFragments =
        smoothstep(
            0.50,
            0.82,
            veinNoise * 0.70
                + (1.0 - broadNoise) * 0.30
        );

    float greenFragments =
        smoothstep(
            0.86,
            0.97,
            fineNoise * 0.38
                + veinNoise * 0.62
        );

    /*
        Sparse drifting green motes concentrated around the middle and edge.
    */
    float soulMotes =
        smoothstep(
            0.91,
            0.985,
            cnoise2(vec2(
                centeredUV.x * 72.0
                    + time * 2.4,
                centeredUV.y * 72.0
                    - time * 1.9
            )) * 0.5 + 0.5
        );

    soulMotes *=
        blastLife
        * inverseSmoothstep(0.14, 1.18, radial)
        * smoothstep(0.18, 0.96, radial);

    /*
        Central black void sphere. It grows slightly during the rupture,
        remains strongly opaque, and has a thin purple necrotic rim.
    */
    float voidSphereRadius =
        mix(
            0.145,
            0.235,
            smoothstep(0.08, 0.48, ruptureProgress)
        );

    float voidSphere =
        1.0 - smoothstep(
            voidSphereRadius - 0.025,
            voidSphereRadius + 0.018,
            radial
        );

    float voidSphereRim =
        smoothstep(
            voidSphereRadius - 0.060,
            voidSphereRadius - 0.012,
            radial
        )
        * (
            1.0 - smoothstep(
                voidSphereRadius - 0.004,
                voidSphereRadius + 0.045,
                radial
            )
        );

    float voidCore =
        voidSphere
        * max(
            blastLife,
            collapseLife * 0.90
        );

    float purpleVeins =
        saturate(
            branchingVeins * 1.15
            + inwardTendrils * 0.72
            + shockwave * purpleFragments * 0.52
        );

    float crimsonRupture =
        saturate(
            tornEdge * 1.10
            + spikeTips * 0.86
            + blastFront * ruptureFlash * 0.72
            + blastInterior * redFragments * 0.66
        );

    float greenEnergy =
        saturate(
            greenFragments
                * (
                    branchingVeins * 0.34
                    + residueHaze * 0.26
                )
            + soulMotes
        );

    vec3 effectColor = mix(
        voidBlack,
        blackPurple,
        saturate(
            blastInterior * 0.36
            + residueHaze * 0.28
        )
    );

    effectColor = mix(
        effectColor,
        deepBlood,
        saturate(
            blastInterior * 0.54
            + blastFill * 0.42
            + middleCloud * 0.28
        )
    );

    effectColor = mix(
        effectColor,
        necroticCrimson,
        crimsonRupture
    );

    effectColor = mix(
        effectColor,
        necroticPurple,
        purpleVeins
    );

    effectColor = mix(
        effectColor,
        brightPurple,
        saturate(
            purpleVeins
            * ruptureFlash
            * 0.72
        )
    );

    effectColor = mix(
        effectColor,
        sicklyGreen,
        greenEnergy * 0.72
    );

    effectColor = mix(
        effectColor,
        soulGreen,
        soulMotes * 0.92
    );

    /*
        Preserve a nearly black central void instead of allowing the
        surrounding colors to wash over the middle.
    */
    effectColor = mix(
        effectColor,
        brightPurple,
        saturate(voidSphereRim * 0.58)
    );

    effectColor = mix(
        effectColor,
        vec3(0.0),
        saturate(voidCore)
    );

    /*
        The rupture flash is crimson/purple rather than orange-white.
    */
    effectColor = mix(
        effectColor,
        ruptureFlashColor,
        saturate(
            hotCore * 0.82
            + blastFront * ruptureFlash * 0.24
        )
    );

    // ------------------------------------------------------------
    // ALPHA
    // ------------------------------------------------------------

    float alpha =
        inwardTendrils * 0.72
        + compressedCore * 0.88
        + blastInterior * 0.88
        + blastFill * 0.66
        + middleCloud * 0.52
        + tornEdge * 0.94
        + spikeTips * 0.88
        + branchingVeins * 0.42
        + hotCore
        + shockwave * 0.56
        + innerShockwave * 0.22
        + residueHaze * 0.31;

    /*
        The void sphere remains opaque while the rest of the effect is
        clipped to a circular silhouette.
    */
    alpha = max(
        alpha,
        voidCore * 0.985
    );

    alpha *= circularBounds;
    alpha *= max(layerOpacity, 0.01);

    alpha = saturate(
        alpha - depthDifference
    );

    alpha -= clamp(
        (
            dist
            * (1.0 + fogAmount / 2.0)
            - 50.0
        ) / 40.0,
        0.0,
        0.7 + fogAmount * 0.3
    );

    alpha = saturate(alpha);

    if (alpha < 0.012)
    {
        discard;
    }

    /*
        Keep the distorted framebuffer visible under the magic.
        Never replace sceneColor.rgb completely or the lensing disappears.
    */
    float colorOpacity =
        saturate(
            alpha * 0.78
            + ruptureFlash * 0.13
        );

    vec3 finalRgb = mix(
        sceneColor.rgb,
        effectColor,
        colorOpacity
    );

    finalRgb +=
        ruptureFlashColor
        * hotCore
        * 0.38;

    finalRgb +=
        necroticCrimson
        * tornEdge
        * 0.16;

    finalRgb +=
        mix(necroticCrimson, brightPurple, purpleFragments)
        * spikeTips
        * 0.28;

    finalRgb +=
        brightPurple
        * purpleVeins
        * ruptureFlash
        * 0.10;

    finalRgb +=
        soulGreen
        * soulMotes
        * 0.22;

    /*
        Reinforce the center after the additive highlights so it remains a
        true black void instead of being washed out by the rupture flash.
    */
    finalRgb = mix(
        finalRgb,
        vec3(0.0),
        saturate(voidCore * 0.98)
    );

    finalRgb +=
        brightPurple
        * voidSphereRim
        * 0.16;

    outColor = applyFog(
        vec4(finalRgb, alpha),
        fogAmount
    );
}
