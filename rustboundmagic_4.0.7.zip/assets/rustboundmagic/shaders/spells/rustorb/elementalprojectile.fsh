#version 330 core

in vec2 uv;
in float dist;
in vec4 rgbaFog;
in float fogAmount;

uniform int projectileType;
uniform float u_time;
uniform float entitySeed;
uniform float intensity;
uniform float distortionStrength;
uniform vec3 projectilePrimaryColor;
uniform vec3 projectileSecondaryColor;
uniform vec3 projectileAccentColor;
uniform vec2 invFrameSize;
uniform sampler2D primaryFb;

layout(location = 0) out vec4 outColor;

const float PI = 3.14159265358979323846;

float saturate(float value)
{
    return clamp(value, 0.0, 1.0);
}

float hash21(vec2 p)
{
    p = fract(p * vec2(123.34, 456.21));
    p += dot(p, p + 45.32);

    return fract(p.x * p.y);
}

float valueNoise(vec2 p)
{
    vec2 i = floor(p);
    vec2 f = fract(p);

    f = f * f * (3.0 - 2.0 * f);

    float a = hash21(i);
    float b = hash21(i + vec2(1.0, 0.0));
    float c = hash21(i + vec2(0.0, 1.0));
    float d = hash21(i + vec2(1.0, 1.0));

    return mix(
        mix(a, b, f.x),
        mix(c, d, f.x),
        f.y
    );
}

float fbm(vec2 p)
{
    float value = 0.0;
    float amplitude = 0.5;

    for (int i = 0; i < 5; i++)
    {
        value += valueNoise(p) * amplitude;
        p = p * 2.03 + vec2(13.7, 9.2);
        amplitude *= 0.5;
    }

    return value;
}

float lineField(vec2 p, float scale, float width)
{
    float n = fbm(p * scale);

    return 1.0 - smoothstep(
        width,
        width + 0.08,
        abs(n - 0.5)
    );
}

vec3 sceneRefraction(vec2 direction, float amount)
{
    vec2 screenUv = gl_FragCoord.xy * invFrameSize;

    return texture(
        primaryFb,
        screenUv + direction * amount
    ).rgb;
}

void materialRust(
    vec2 p,
    float radius,
    float angle,
    float time,
    out vec3 color,
    out float alpha)
{
    /*
     * TEMPORAL RUST PORTAL
     *
     * This is intentionally not flame-like. The material is built from:
     * - a translucent rust-filled temporal center
     * - rotating bands of corroded matter
     * - bright rust fractures
     * - drifting granular debris
     * - an unstable, irregular outer boundary
     */

    float slowTime = time * 0.42;

    /*
     * Warp the coordinates so the portal continually folds and breathes.
     */
    float warpA = fbm(
        p * 3.8
        + vec2(
            slowTime * 0.22,
            -slowTime * 0.17
        )
        + entitySeed * 0.021
    );

    float warpB = fbm(
        p.yx * 7.5
        + vec2(
            -slowTime * 0.31,
            slowTime * 0.26
        )
        - entitySeed * 0.017
    );

    vec2 warpedP = p;

    warpedP += vec2(
        warpA - 0.5,
        warpB - 0.5
    ) * 0.105;

    float warpedRadius = length(warpedP);
    float warpedAngle = atan(warpedP.y, warpedP.x);

    /*
     * Irregular outer volume.
     */
    float edgeNoise = fbm(
        vec2(
            warpedAngle * 2.4,
            slowTime * 0.36
        )
        + vec2(
            warpedRadius * 4.0,
            entitySeed * 0.013
        )
    );

    float outerBoundary =
        0.98
        + (edgeNoise - 0.5) * 0.15
        + sin(
            warpedAngle * 5.0
            - slowTime * 1.35
        ) * 0.025;

    float portalBody =
        1.0
        - smoothstep(
            outerBoundary - 0.08,
            outerBoundary + 0.08,
            warpedRadius
        );

    /*
     * Central temporal volume. This defines the rust-filled core without
     * cutting a transparent hole through the projectile.
     */
    float centerDistortion =
        (warpA - 0.5) * 0.10
        + (warpB - 0.5) * 0.055
        + sin(
            warpedAngle * 3.0
            + slowTime * 1.10
        ) * 0.025;

    float centerRadius =
        warpedRadius
        + centerDistortion;

    float hollowCenter =
        1.0
        - smoothstep(
            0.17,
            0.43,
            centerRadius
        );

    float innerRim =
        smoothstep(
            0.20,
            0.39,
            centerRadius
        )
        * (
            1.0
            - smoothstep(
                0.43,
                0.58,
                centerRadius
            )
        );

    /*
     * Broad rotating streams of temporal rust.
     */
    float spiralA = sin(
        warpedAngle * 4.0
        - warpedRadius * 14.0
        + slowTime * 2.25
        + warpA * 4.2
    );

    float spiralB = sin(
        warpedAngle * 7.0
        + warpedRadius * 19.0
        - slowTime * 1.55
        + warpB * 3.6
    );

    float spiralField =
        spiralA * 0.63
        + spiralB * 0.37;

    float rustStreams = smoothstep(
        0.12,
        0.72,
        spiralField
    );

    rustStreams *= portalBody;
    rustStreams *= 0.72 + hollowCenter * 0.28;

    /*
     * Broken corroded plates orbiting within the portal.
     */
    float plateNoise = fbm(
        vec2(
            warpedAngle * 5.5
            - slowTime * 0.74,
            warpedRadius * 12.0
        )
        + entitySeed * 0.029
    );

    float rustPlates = smoothstep(
        0.54,
        0.74,
        plateNoise
    );

    rustPlates *= portalBody;
    rustPlates *= smoothstep(
        0.30,
        0.52,
        warpedRadius
    );

    /*
     * Thin glowing fractures. These should read as temporal cracks,
     * not tongues of fire.
     */
    float fractureNoise = fbm(
        vec2(
            warpedAngle * 9.0
            + slowTime * 0.90,
            warpedRadius * 24.0
            - slowTime * 0.45
        )
        + entitySeed * 0.041
    );

    float fractures =
        1.0
        - smoothstep(
            0.02,
            0.020,
            abs(fractureNoise - 0.5)
        );

    fractures *= portalBody;
    fractures *= smoothstep(
        0.24,
        0.42,
        warpedRadius
    );

    /*
     * Sparse granular rust suspended in the portal.
     */
    float granuleNoise = fbm(
        p * 28.0
        + vec2(
            slowTime * 0.62,
            -slowTime * 0.41
        )
        + entitySeed * 0.037
    );

    float granules = smoothstep(
        0.73,
        0.90,
        granuleNoise
    );

    granules *= portalBody;
    granules *= 0.78 + hollowCenter * 0.22;

    /*
     * A subtle temporal pulse. Keep this restrained so the portal
     * feels unstable rather than fiery.
     */
    float temporalPulse =
        0.88
        + sin(
            slowTime * 4.2
            + warpA * 7.0
        ) * 0.055
        + sin(
            slowTime * 7.1
            + warpB * 5.0
        ) * 0.025;

    /*
     * COLOR PALETTE
     *
     * Primary: dark oxidized rust
     * Secondary: burnt orange corrosion
     * Accent: hot metallic rust fractures
     */
    vec3 voidColor =
        projectilePrimaryColor
        * vec3(
            0.055,
            0.030,
            0.020
        );

    vec3 darkRust =
        projectilePrimaryColor
        * vec3(
            0.42,
            0.26,
            0.18
        );

    vec3 oxidizedRust = mix(
        projectilePrimaryColor,
        projectileSecondaryColor,
        0.34
    );

    vec3 brightRust = mix(
        projectileSecondaryColor,
        projectileAccentColor,
        0.22
    );

    color = mix(
        darkRust,
        oxidizedRust,
        rustStreams * 0.72
    );

    color = mix(
        color,
        projectilePrimaryColor * 0.34,
        rustPlates * 0.62
    );

    /*
     * Make the inner rim look like the edge of a portal opening.
     */
    color +=
        brightRust
        * innerRim
        * (
            0.52
            + warpA * 0.34
        );

    /*
     * Temporal cracks provide the brightest feature.
     */
    color +=
        projectileAccentColor
        * fractures
        * (
            0.20
            + rustStreams * 0.1
        );

    color +=
        projectileSecondaryColor
        * granules
        * 0.42;

    /*
     * Layered rust fog fills the center. Two differently moving noise
     * fields prevent it from looking like a flat colored disk.
     */
    float centerFogA = fbm(
        p * 6.5
        + vec2(
            -slowTime * 0.31,
            slowTime * 0.24
        )
        + entitySeed * 0.023
    );

    float centerFogB = fbm(
        p.yx * 11.0
        + vec2(
            slowTime * 0.18,
            slowTime * 0.37
        )
        - entitySeed * 0.031
    );

    float centerFog =
        centerFogA * 0.62
        + centerFogB * 0.38;

    float centerVeins = smoothstep(
        0.46,
        0.72,
        sin(
            warpedAngle * 5.0
            - warpedRadius * 13.0
            + slowTime * 1.30
            + centerFog * 4.0
        ) * 0.5 + 0.5
    );

    vec3 translucentRust = mix(
        projectilePrimaryColor * vec3(0.30, 0.19, 0.13),
        projectileSecondaryColor * vec3(0.48, 0.30, 0.18),
        centerFog
    );

    translucentRust +=
        projectileAccentColor
        * centerVeins
        * 0.075;

    /*
     * Fill the center with transparent rust rather than turning it into
     * an empty hole. The edge retains stronger corrosion and fractures.
     */
    color = mix(
        color,
        translucentRust,
        hollowCenter * 0.78
    );

    color +=
        projectilePrimaryColor
        * hollowCenter
        * centerFog
        * 0.055;

    color *= temporalPulse;

    /*
     * ALPHA
     *
     * The entire sphere remains present. The center is translucent rust,
     * while the surrounding bands and fractures are more opaque.
     */
    alpha =
        portalBody
        * (
            0.43
            + rustStreams * 0.19
            + rustPlates * 0.09
            + fractures * 0.15
            + granules * 0.06
        );

    alpha +=
        innerRim * 0.16;

    float centerAlpha =
        0.20
        + centerFog * 0.10
        + centerVeins * 0.035;

    alpha = mix(
        alpha,
        centerAlpha,
        hollowCenter * 0.86
    );

    alpha *= portalBody;
    alpha = saturate(alpha);
}

void materialFire(
    vec2 p,
    float radius,
    float angle,
    float time,
    out vec3 color,
    out float alpha)
{
    /*
     * Fire coordinates.
     *
     * A slight vertical compression makes the silhouette stretch
     * upward while still behaving like a projectile rather than
     * a stationary campfire.
     */
    vec2 firePos = p;

    firePos.y *= 0.94;

    float fireRadius = length(firePos);
    float fireAngle = atan(firePos.y, firePos.x);

    /*
     * Independent noise layers.
     *
     * Large noise controls the broad body.
     * Medium noise creates flowing heat.
     * Fine noise creates flicker and edge breakup.
     * Detail noise gives the core and ribbons additional texture.
     */
    float largeNoise = fbm(
        firePos * 3.6
        + vec2(
            sin(time * 0.65) * 0.24,
            -time * 1.15
        )
        + entitySeed * 0.031
    );

    float mediumNoise = fbm(
        firePos * 8.2
        + vec2(
            cos(time * 0.87) * 0.18,
            -time * 2.25
        )
        - entitySeed * 0.019
    );

    float fineNoise = fbm(
        firePos * 17.5
        + vec2(
            sin(time * 1.35) * 0.09,
            -time * 4.10
        )
        + entitySeed * 0.047
    );

    float detailNoise = fbm(
        firePos * 31.0
        + vec2(
            -time * 0.70,
            -time * 5.20
        )
    );

    /*
     * Flames become longer and more active toward the top.
     */
    float upwardMask = smoothstep(
        -0.72,
        0.72,
        firePos.y
    );

    /*
     * ------------------------------------------------------------
     * MAIN FIRE BODY
     * ------------------------------------------------------------
     *
     * Keep the central body relatively compact so the exterior
     * red wisps remain visible as separate flame structures.
     */
    float bodyDistortion =
        (largeNoise - 0.5) * 0.17
        + (mediumNoise - 0.5) * 0.075
        + (fineNoise - 0.5) * 0.025;

    float distortedBodyRadius =
        fireRadius
        + bodyDistortion;

    float mainBody =
        1.0
        - smoothstep(
            0.67,
            0.98,
            distortedBodyRadius
        );

    /*
     * A denser inner volume prevents the fireball from looking
     * hollow when the outer noise becomes thin.
     */
    float innerBody =
        1.0
        - smoothstep(
            0.32,
            0.76,
            fireRadius
            + (mediumNoise - 0.5) * 0.08
        );

    float fireBody = max(
        mainBody,
        innerBody * 0.88
    );

    /*
     * ------------------------------------------------------------
     * TURBULENT HEAT FIELD
     * ------------------------------------------------------------
     *
     * This drives one continuous gradient:
     *
     * deep red -> red -> red-orange -> orange -> yellow
     *
     * It does not use separate circular bands, so the boundaries
     * are distorted and blended by moving noise.
     */
    float radialHeat =
        1.0
        - smoothstep(
            0.34,
            0.92,
            fireRadius
        );

    float turbulentHeat =
        radialHeat
        + (largeNoise - 0.5) * 0.17
        + (mediumNoise - 0.5) * 0.15
        + (fineNoise - 0.5) * 0.155;

    turbulentHeat = saturate(
        turbulentHeat
    );

    /*
     * Wide overlapping blend ranges remove visible color rings.
     */
    float orangeBlend = smoothstep(
        0.24,
        0.58,
        turbulentHeat
    ) * 0.42;

    /*
     * The yellow range begins much closer to the center than in
     * the previous version.
     */
    float yellowBlend = smoothstep(
        0.88,
        0.995,
        turbulentHeat
    ) * 0.22;

    /*
     * ------------------------------------------------------------
     * SMALL YELLOW CORE
     * ------------------------------------------------------------
     *
     * The yellow center is deliberately compact. Its outline is
     * distorted by convection rather than appearing as a circle.
     */
    float coreDistortion =
        (mediumNoise - 0.5) * 0.055
        + (fineNoise - 0.5) * 0.025
        + (detailNoise - 0.5) * 0.012;

    float coreRadius =
        fireRadius
        + coreDistortion;

    float yellowCore =
        1.0
        - smoothstep(
            0.58,
            0.70,
            coreRadius
        );

    /*
     * Restrict the heat-field yellow to the compact core.
     */
    yellowBlend *= yellowCore;

    /*
     * ------------------------------------------------------------
     * CORE CONVECTION
     * ------------------------------------------------------------
     *
     * Two independent moving noise layers make the yellow center
     * boil underneath the rotating plasma ribbons.
     */
    float convectionA = fbm(
        firePos * 13.0
        + vec2(
            time * 0.34,
            -time * 0.48
        )
    );

    float convectionB = fbm(
        firePos.yx * 20.0
        + vec2(
            -time * 0.50,
            time * 0.29
        )
    );

    float convection =
        convectionA * 0.64
        + convectionB * 0.36;

    float convectionCells = smoothstep(
        0.32,
        0.82,
        convection
    );

    convectionCells *= yellowCore;

    /*
     * Break small red-orange cavities into the yellow center.
     */
    float coreCavities = smoothstep(
        0.13,
        0.75,
        fbm(
            firePos * 24.0
            + vec2(
                time * 0.72,
                -time * 0.55
            )
        )
    );

    coreCavities *= yellowCore;

    /*
     * ------------------------------------------------------------
     * ROTATING CORE PLASMA RIBBONS
     * ------------------------------------------------------------
     *
     * These rotate independently from the outer flames.
     * Several frequencies overlap to create approximately three
     * irregular plasma streams crossing the yellow center.
     */
    float rotatingAngle =
        fireAngle
        + time * 10.55;

    float spiralCoordinate =
        rotatingAngle
        + fireRadius * 11.0
        + (mediumNoise - 0.5) * 2.8;

    float ribbonWaveA = sin(
        spiralCoordinate * 2.0
        + time * 0.55
    );

    float ribbonWaveB = sin(
        rotatingAngle * 3.0
        - fireRadius * 16.0
        - time * 0.85
        + fineNoise * 3.0
    );

    float ribbonWaveC = sin(
        rotatingAngle * 5.0
        + fireRadius * 10.0
        + time * 0.38
        + detailNoise * 2.0
    );

    float ribbonField =
        ribbonWaveA * 0.52
        + ribbonWaveB * 0.31
        + ribbonWaveC * 0.17;

    /*
     * Higher thresholds make the streams narrow rather than
     * covering most of the yellow center.
     */
    float coreRibbons = smoothstep(
        0.44,
        0.78,
        ribbonField
    );

    /*
     * Keep the ribbons around and across the core while allowing
     * them to extend slightly into the surrounding orange.
     */
    float ribbonRegion =
        1.0
        - smoothstep(
            0.18,
            0.48,
            fireRadius
        );

    /*
     * Noise causes ribbons to split, weaken, and reconnect.
     */
    float ribbonBreakup = smoothstep(
        0.34,
        0.68,
        fbm(
            vec2(
                rotatingAngle * 2.5,
                fireRadius * 18.0 - time * 1.65
            )
            + entitySeed * 0.021
        )
    );

    coreRibbons *= ribbonRegion;
    coreRibbons *= 0.50 + ribbonBreakup * 0.66;

    /*
     * A second thinner ribbon layer rotates at a different speed.
     * This prevents the entire center from looking like one spiral.
     */
    float secondaryRibbonAngle =
        fireAngle
        - time * 1.10;

    float secondaryRibbon = sin(
        secondaryRibbonAngle * 4.0
        + fireRadius * 21.0
        + largeNoise * 4.0
    );

    secondaryRibbon = smoothstep(
        0.62,
        0.88,
        secondaryRibbon
    );

    secondaryRibbon *=
        ribbonRegion
        * (
            0.40
            + fineNoise * 0.60
        );

    coreRibbons = saturate(
        coreRibbons
        + secondaryRibbon * 0.48
    );

    /*
     * ------------------------------------------------------------
     * OUTER RED FIRE WISPS
     * ------------------------------------------------------------
     *
     * Narrow angular patterns select individual flame strands.
     */
    float outerWispA = sin(
        fireAngle * 7.0
        - time * 1.85
        + largeNoise * 4.8
    );

    float outerWispB = sin(
        fireAngle * 13.0
        + time * 1.23
        + mediumNoise * 3.7
    );

    float outerWispC = sin(
        fireAngle * 21.0
        - time * 2.38
        + fineNoise * 2.6
    );

    float outerWispPattern =
        outerWispA * 0.54
        + outerWispB * 0.30
        + outerWispC * 0.16;

    float outerWispSelection = smoothstep(
        0.38,
        0.77,
        outerWispPattern
    );

    /*
     * Outer strands grow farther toward the top.
     */
    float wispLength =
        (
            0.10
            + largeNoise * 0.16
            + mediumNoise * 0.065
        )
        * (
            0.58
            + upwardMask * 0.72
        );

    /*
     * Start measuring extension outside the compact body.
     */
    float outsideDistance = max(
        fireRadius - 0.70,
        0.0
    );

    float wispTaper =
        1.0
        - smoothstep(
            0.0,
            wispLength,
            outsideDistance
        );

    /*
     * Keep wisps attached near the exterior of the main body.
     */
    float wispAttachment = smoothstep(
        0.50,
        0.76,
        fireRadius
    );

    float outerWispBreakup = smoothstep(
        0.35,
        0.69,
        mediumNoise * 0.58
        + fineNoise * 0.42
    );

    float outerWisps =
        outerWispSelection
        * wispTaper
        * wispAttachment
        * (
            0.42
            + outerWispBreakup * 0.72
        );

    /*
     * Smaller tongues fill some gaps, but do not recreate a solid
     * circular shell.
     */
    float shortTongues = smoothstep(
        0.61,
        0.82,
        largeNoise * 0.57
        + mediumNoise * 0.43
    );

    shortTongues *= smoothstep(
        0.57,
        0.76,
        fireRadius
    );

    shortTongues *=
        1.0
        - smoothstep(
            0.80,
            1.04,
            fireRadius
        );

    shortTongues *=
        0.30
        + upwardMask * 0.70;

    /*
     * ------------------------------------------------------------
     * COLOR CONSTRUCTION
     * ------------------------------------------------------------
     */

    vec3 deepRed =
        projectilePrimaryColor
        * vec3(
            0.62,
            0.20,
            0.14
        );

    vec3 redColor = mix(
        deepRed,
        projectilePrimaryColor,
        0.52 + largeNoise * 0.38
    );

    vec3 orangeColor =
        projectileSecondaryColor;

    vec3 yellowColor =
        projectileAccentColor;

    /*
     * Continuous red-to-orange transition.
     */
    color = mix(
        redColor,
        orangeColor,
        orangeBlend
    );

    /* Keep red dominant across the entire body. */
    color = mix(
        color,
        projectilePrimaryColor,
        fireBody * 0.28
    );

    /*
     * Orange-to-yellow transition restricted to the small core.
     */
    color = mix(
        color,
        yellowColor,
        yellowBlend
    );

    /*
     * Core convection alternates between rich orange and yellow.
     */
    vec3 convectionColor = mix(
        orangeColor,
        yellowColor,
        convectionCells
    );

    color = mix(
        color,
        convectionColor,
        convectionCells * yellowCore * 0.12
    );

    /*
     * Orange-red cavities break apart the yellow surface.
     */
    vec3 cavityColor = mix(
        projectilePrimaryColor,
        orangeColor,
        0.44
    );

    color = mix(
        color,
        cavityColor,
        coreCavities * 0.32
    );

    /*
     * Rotating ribbons pass over the core in red-orange.
     */
    vec3 ribbonColor = mix(
        projectilePrimaryColor * 0.74,
        orangeColor,
        0.26 + mediumNoise * 0.18
    );

    color = mix(
        color,
        ribbonColor,
        coreRibbons * 0.78
    );

    /*
     * A narrow bright edge alongside portions of the ribbons gives
     * them depth without turning them yellow.
     */
    float ribbonEdge = smoothstep(
        0.12,
        0.36,
        coreRibbons
    ) * (
        1.0
        - smoothstep(
            0.62,
            0.95,
            coreRibbons
        )
    );

    color +=
        orangeColor
        * ribbonEdge
        * 0.07;

    /*
     * Outer wisps remain deep red. Their bases become slightly
     * orange where they connect to the hotter body.
     */
    float outerWispHeat =
        1.0
        - smoothstep(
            0.54,
            0.89,
            fireRadius
        );

    vec3 outerWispColor = mix(
        projectilePrimaryColor * 0.46,
        orangeColor * 0.68,
        outerWispHeat * 0.45
    );

    color +=
        outerWispColor
        * outerWisps
        * 0.90;

    color +=
        mix(
            projectilePrimaryColor,
            orangeColor,
            0.22
        )
        * shortTongues
        * 0.46;

    /*
     * Slightly reinforce the outer red body so the projectile does
     * not become predominantly orange.
     */
    float redShell =
        smoothstep(
            0.40,
            0.74,
            fireRadius
        )
        * fireBody;

    color = mix(
        color,
        projectilePrimaryColor * 0.88,
        redShell * 0.48
    );

    /*
     * A restrained center glow keeps the small yellow nucleus hot,
     * but does not recreate a large flat yellow disk.
     */
    float centerGlow =
        1.0
        - smoothstep(
            0.015,
            0.085,
            fireRadius
        );

    color +=
        yellowColor
        * centerGlow
        * (
            0.05
            + convection * 0.035
        );

    /*
     * Independent flicker.
     */
    float flicker =
        0.90
        + sin(
            time * 7.3
            + largeNoise * 8.0
        ) * 0.055
        + sin(
            time * 13.7
            + mediumNoise * 11.0
        ) * 0.035
        + (fineNoise - 0.5) * 0.045;

    color *= flicker;

    /*
     * ------------------------------------------------------------
     * ALPHA
     * ------------------------------------------------------------
     *
     * Keep the core and body solid while allowing the exterior
     * flame strands to taper naturally.
     */
    alpha =
        fireBody * (
            0.82
            + turbulentHeat * 0.13
        );

    alpha +=
        outerWisps * 0.86;

    alpha +=
        shortTongues * 0.34;

    /*
     * Ribbons remain fully inside the existing fire silhouette,
     * so they affect color more than transparency.
     */
    alpha +=
        coreRibbons
        * ribbonRegion
        * 0.06;

    alpha = saturate(alpha);
}

void materialWater(
    vec2 p,
    float radius,
    float angle,
    float time,
    out vec3 color,
    out float alpha)
{
    /*
     * Suspended water flowing around a dense central mass.
     *
     * The center is deep blue and visually heavy. Water currents
     * approach from the left, divide above and below the core, and
     * reconnect on the right rather than spiraling inward.
     */

    vec2 waterPos = p;

    float largeNoise = fbm(
        waterPos * 4.2
        + vec2(
            -time * 0.24,
            time * 0.07
        )
        + entitySeed * 0.021
    );

    float mediumNoise = fbm(
        waterPos * 9.0
        + vec2(
            -time * 0.52,
            -time * 0.11
        )
        - entitySeed * 0.017
    );

    float fineNoise = fbm(
        waterPos * 19.0
        + vec2(
            -time * 0.86,
            time * 0.18
        )
    );

    /*
     * Slightly irregular outer water volume.
     */
    float distortedRadius =
        radius
        + (largeNoise - 0.5) * 0.095
        + (mediumNoise - 0.5) * 0.035;

    float body =
        1.0
        - smoothstep(
            0.82,
            1.04,
            distortedRadius
        );

    /*
     * Dense central object / deep-water core.
     *
     * This is deliberately darker than the surrounding water.
     */
    float coreDistortion =
        (mediumNoise - 0.5) * 0.035
        + (fineNoise - 0.5) * 0.012;

    float coreRadius =
        radius
        + coreDistortion;

    float deepCore =
        1.0
        - smoothstep(
            0.28,
            0.48,
            coreRadius
        );

    float coreHalo =
        1.0
        - smoothstep(
            0.40,
            0.68,
            coreRadius
        );

    /*
     * Potential-flow-inspired coordinates around a circular object.
     *
     * The vertical displacement becomes stronger near the core.
     * Incoming horizontal currents split above and below it, then
     * converge again behind it.
     */
    float radiusSquared =
        dot(waterPos, waterPos)
        + 0.035;

    float obstacleInfluence =
        0.19
        / radiusSquared;

    obstacleInfluence = min(
        obstacleInfluence,
        2.2
    );

    vec2 flowCoordinates;

    flowCoordinates.x =
        waterPos.x
        - waterPos.x
        * obstacleInfluence
        * 0.30;

    flowCoordinates.y =
        waterPos.y
        * (
            1.0
            + obstacleInfluence * 0.82
        );

    /*
     * Add gentle turbulence without turning the flow into a spiral.
     */
    flowCoordinates.y +=
        (largeNoise - 0.5) * 0.16
        + (mediumNoise - 0.5) * 0.075;

    flowCoordinates.x +=
        (fineNoise - 0.5) * 0.035;

    /*
     * Long current bands traveling horizontally.
     */
    float currentWaveA = sin(
        flowCoordinates.y * 12.0
        + flowCoordinates.x * 2.8
        + time * 2.4
        + largeNoise * 3.2
    );

    float currentWaveB = sin(
        flowCoordinates.y * 20.0
        - flowCoordinates.x * 3.8
        + time * 3.1
        + mediumNoise * 4.0
    );

    float currentWaveC = sin(
        flowCoordinates.y * 31.0
        + flowCoordinates.x * 5.5
        + time * 4.0
        + fineNoise * 3.0
    );

    float currentField =
        currentWaveA * 0.55
        + currentWaveB * 0.30
        + currentWaveC * 0.15;

    float broadCurrents = smoothstep(
        0.12,
        0.72,
        currentField
    );

    /*
     * Thin bright stream edges riding along the broad currents.
     */
    float currentEdges =
        1.0
        - smoothstep(
            0.04,
            0.16,
            abs(currentField - 0.44)
        );

    /*
     * Suppress currents inside the dense core itself.
     */
    float outsideCore =
        smoothstep(
            0.36,
            0.54,
            coreRadius
        );

    broadCurrents *= outsideCore;
    currentEdges *= outsideCore;

    /*
     * Pressure increases along the sides of the central mass.
     * This produces brighter compressed water above and below it.
     */
    float sidePressure =
        exp(
            -pow(
                abs(waterPos.x) / 0.42,
                2.0
            )
        )
        * exp(
            -pow(
                (abs(waterPos.y) - 0.31) / 0.16,
                2.0
            )
        );

    sidePressure *=
        0.62
        + mediumNoise * 0.38;

    /*
     * A soft wake behind the heavy center.
     *
     * It remains horizontal and trailing rather than curling into
     * a whirlpool.
     */
    float behindCore = smoothstep(
        -0.12,
        0.48,
        waterPos.x
    );

    float wakeShape =
        exp(
            -pow(
                waterPos.y / 0.30,
                2.0
            )
        )
        * behindCore
        * (
            1.0
            - smoothstep(
                0.18,
                0.88,
                waterPos.x
            )
        );

    float wakeRipples =
        sin(
            waterPos.x * 24.0
            - time * 3.6
            + mediumNoise * 3.0
        )
        * 0.5
        + 0.5;

    float wake =
        wakeShape
        * smoothstep(
            0.30,
            0.76,
            wakeRipples
        )
        * outsideCore;

    /*
     * Caustics stay mostly in the moving outer water and along the
     * compressed side currents. The center remains deep blue.
     */
    float causticA = lineField(
        flowCoordinates
        + vec2(
            -time * 0.11,
            time * 0.035
        ),
        8.0,
        0.055
    );

    float causticB = lineField(
        flowCoordinates.yx
        + vec2(
            time * 0.045,
            -time * 0.085
        ),
        12.0,
        0.043
    );

    float caustics = saturate(
        causticA * 0.34
        + causticB * 0.27
    );

    float outerWaterMask =
        smoothstep(
            0.48,
            0.78,
            radius
        )
        * body;

    caustics *=
        outerWaterMask
        * (
            0.42
            + broadCurrents * 0.38
            + sidePressure * 0.55
        );

    /*
     * Refraction follows the diverted current direction.
     */
    vec2 flowDirection = vec2(
        1.0,
        (
            flowCoordinates.y - waterPos.y
        ) * 1.8
    );

    flowDirection = normalize(
        flowDirection
        + vec2(0.0001)
    );

    float refractionAmount =
        distortionStrength
        * (
            0.0025
            + broadCurrents * 0.0035
            + sidePressure * 0.0045
            + caustics * 0.0020
        );

    vec3 refracted = sceneRefraction(
        flowDirection,
        refractionAmount
    );

    /*
     * Color construction:
     *
     * deep sapphire core
     * -> blue moving body
     * -> cyan currents
     * -> pale aqua caustics
     */
    vec3 deepBlue =
        projectilePrimaryColor
        * vec3(
            0.30,
            0.34,
            0.46
        );

    vec3 bodyBlue = mix(
        projectilePrimaryColor,
        projectileSecondaryColor,
        broadCurrents * 0.46
    );

    color = mix(
        refracted,
        bodyBlue,
        0.73
    );

    /*
     * Compressed water around the obstacle becomes brighter cyan.
     */
    color = mix(
        color,
        projectileSecondaryColor,
        sidePressure * 0.52
    );

    /*
     * The wake is slightly darker than the side currents.
     */
    color = mix(
        color,
        projectilePrimaryColor * 0.72,
        wake * 0.28
    );

    /*
     * Caustics and current edges add pale aqua highlights.
     */
    float brightWater =
        saturate(
            caustics * 0.38
            + currentEdges * 0.10
            + sidePressure * 0.09
        );

    color = mix(
        color,
        projectileAccentColor,
        brightWater * 0.46
    );

    /*
     * Reinforce depth around the central object before applying the
     * darkest inner core.
     */
    color = mix(
        color,
        projectilePrimaryColor * 0.52,
        coreHalo * 0.62
    );

    color = mix(
        color,
        deepBlue,
        deepCore * 0.98
    );

    /*
     * Subtle internal motion keeps the deep core from looking like
     * a completely flat painted circle.
     */
    float coreMovement =
        0.82
        + largeNoise * 0.10
        + mediumNoise * 0.08;

    color *= mix(
        1.0,
        coreMovement,
        deepCore
    );

    /*
     * Soft cyan rim around the heavy central mass helps separate it
     * from the water currents flowing around it.
     */
    float coreBoundary =
        smoothstep(
            0.29,
            0.43,
            coreRadius
        )
        * (
            1.0
            - smoothstep(
                0.44,
                0.58,
                coreRadius
            )
        );

    color +=
        projectileSecondaryColor
        * coreBoundary
        * (
            0.055
            + sidePressure * 0.065
        );

    /*
     * Outer watery rim.
     */
    float outerRim =
        smoothstep(
            0.66,
            0.96,
            distortedRadius
        )
        * body;

    color +=
        projectileSecondaryColor
        * outerRim
        * (
            0.055
            + caustics * 0.075
        );

    /*
     * Alpha keeps the water translucent at the edge but dense around
     * the central mass.
     */
    alpha =
        body
        * (
            0.58
            + broadCurrents * 0.11
            + sidePressure * 0.09
            + caustics * 0.055
            + outerRim * 0.065
        );

    alpha = max(
        alpha,
        deepCore * 0.92
    );

    alpha = saturate(alpha);
}

void materialWind(
    vec2 p,
    float radius,
    float angle,
    float time,
    out vec3 color,
    out float alpha)
{
    float bands = sin(
        angle * 8.0
        + radius * 20.0
        - time * 5.0
        + fbm(p * 4.0) * 4.0
    );

    bands = smoothstep(
        0.25,
        0.92,
        bands * 0.5 + 0.5
    );

    float wisps = smoothstep(
        0.46,
        0.75,
        fbm(
            vec2(
                angle * 3.0 - time * 0.55,
                radius * 11.0 - time * 1.7
            )
        )
    );

    float shell = smoothstep(
        1.02,
        0.42,
        radius
    );

    float hollow = smoothstep(
        0.18,
        0.56,
        radius
    );

    float visible =
        shell
        * hollow
        * saturate(
            bands * 0.75
            + wisps * 0.58
        );

    vec2 direction = normalize(
        p + vec2(0.0001)
    );

    vec3 refracted = sceneRefraction(
        direction,
        distortionStrength * 0.008 * visible
    );

    color = mix(
        refracted,
        projectilePrimaryColor,
        0.30
    );

    color = mix(
        color,
        projectileSecondaryColor,
        bands * 0.72
    );

    color +=
        projectileAccentColor
        * wisps
        * 0.28;

    alpha = visible * 0.72;
}

void materialEarth(
    vec2 p,
    float radius,
    float angle,
    float time,
    out vec3 color,
    out float alpha)
{
    float rock = fbm(
        p * 8.0
        + entitySeed * 0.17
    );

    float rockFine = fbm(
        p * 21.0
        - entitySeed * 0.11
    );

    float cracks =
        1.0
        - smoothstep(
            0.035,
            0.11,
            abs(fbm(p * 5.5 + rockFine) - 0.50)
        );

    cracks *= smoothstep(
        0.12,
        0.95,
        radius
    );

    float pulse =
        0.72
        + 0.28 * sin(time * 3.0 + rock * 5.0);

    float jaggedRadius =
        radius
        + (rock - 0.5) * 0.18
        + (rockFine - 0.5) * 0.05;

    float body = smoothstep(
        1.03,
        0.50,
        jaggedRadius
    );

    color = mix(
        projectilePrimaryColor,
        projectileSecondaryColor,
        rock
    );

    color *=
        0.62
        + rockFine * 0.38;

    color +=
        projectileAccentColor
        * cracks
        * pulse
        * 1.15;

    alpha = body;
}

void materialLightning(
    vec2 p,
    float radius,
    float angle,
    float time,
    out vec3 color,
    out float alpha)
{
    /*
     * A dense ball of unstable electricity rather than a smooth
     * glowing orb. Multiple independently moving arc systems cross
     * the sphere, fork, flash, and briefly overpower one another.
     */

    float phase =
        floor(time * 22.0)
        + entitySeed;

    float randomFlash = hash21(
        vec2(
            phase,
            phase * 0.731
        )
    );

    float fastPulse =
        0.78
        + 0.22
        * sin(
            time * 19.0
            + entitySeed * 0.37
        );

    float irregularPulse =
        0.72
        + randomFlash * 0.38;

    float flicker =
        fastPulse
        * irregularPulse;

    /*
     * Uneven electrical volume.
     */
    float bodyNoise = fbm(
        p * 7.5
        + vec2(
            time * 1.7,
            -time * 1.2
        )
        + entitySeed * 0.019
    );

    float fineNoise = fbm(
        p * 18.0
        + vec2(
            -time * 3.2,
            time * 2.4
        )
    );

    float distortedRadius =
        radius
        + (bodyNoise - 0.5) * 0.16
        + (fineNoise - 0.5) * 0.045;

    float electricBody =
        1.0
        - smoothstep(
            0.72,
            1.06,
            distortedRadius
        );

    /*
     * Dim blue electrical atmosphere behind the visible bolts.
     */
    float innerEnergy =
        1.0
        - smoothstep(
            0.18,
            0.88,
            radius
            + (bodyNoise - 0.5) * 0.10
        );

    /*
     * ------------------------------------------------------------
     * PRIMARY ARC NETWORK
     * ------------------------------------------------------------
     *
     * Several angular/radial fields create bolts that cross the
     * whole sphere instead of merely tracing its outside edge.
     */
    float arcs = 0.0;
    float arcGlow = 0.0;

    for (int i = 0; i < 5; i++)
    {
        float fi = float(i);

        float arcRotation =
            time * (
                1.15
                + fi * 0.23
            )
            * (
                mod(fi, 2.0) < 1.0
                ? 1.0
                : -1.0
            );

        float warpedAngle =
            angle
            + arcRotation
            + sin(
                radius * (
                    15.0
                    + fi * 3.5
                )
                - time * (
                    7.0
                    + fi * 1.2
                )
                + bodyNoise * 4.2
            ) * 0.42;

        float arcWave = sin(
            warpedAngle
            * (
                2.0
                + fi
            )
            + radius
            * (
                11.0
                + fi * 4.0
            )
            + fi * 2.13
        );

        float arcDistance = abs(
            arcWave
            + (fineNoise - 0.5) * 0.38
        );

        float thinArc =
            1.0
            - smoothstep(
                0.018,
                0.075,
                arcDistance
            );

        float softArc =
            1.0
            - smoothstep(
                0.035,
                0.19,
                arcDistance
            );

        /*
         * Each arc appears in broken sections so the sphere looks
         * electrically unstable rather than wrapped in clean rings.
         */
        float breakup = hash21(
            vec2(
                floor(
                    warpedAngle * 6.0
                    + radius * 13.0
                ),
                phase + fi * 17.0
            )
        );

        float segmentMask = smoothstep(
            0.22,
            0.54,
            breakup
            + bodyNoise * 0.34
        );

        thinArc *=
            segmentMask
            * electricBody;

        softArc *=
            segmentMask
            * electricBody;

        arcs = max(
            arcs,
            thinArc
        );

        arcGlow = max(
            arcGlow,
            softArc
        );
    }

    /*
     * ------------------------------------------------------------
     * FORKED DISCHARGES
     * ------------------------------------------------------------
     *
     * Narrow branching arcs shoot outward from the inner sphere.
     */
    float forks = 0.0;
    float forkGlow = 0.0;

    for (int i = 0; i < 4; i++)
    {
        float fi = float(i);

        float forkAngle =
            angle
            + time * (
                1.8
                + fi * 0.31
            )
            + fi * 1.61
            + sin(
                radius * 19.0
                - time * 10.0
                + fi * 2.4
            ) * 0.31;

        float forkShape = abs(
            sin(
                forkAngle
                * (
                    3.0
                    + fi
                )
                + radius * (
                    17.0
                    + fi * 5.0
                )
                + fineNoise * 2.7
            )
        );

        float thinFork =
            1.0
            - smoothstep(
                0.012,
                0.060,
                forkShape
            );

        float softFork =
            1.0
            - smoothstep(
                0.025,
                0.16,
                forkShape
            );

        float forkRegion =
            smoothstep(
                0.18,
                0.46,
                radius
            )
            * (
                1.0
                - smoothstep(
                    0.78,
                    1.08,
                    distortedRadius
                )
            );

        float forkBreakup = smoothstep(
            0.34,
            0.66,
            fbm(
                vec2(
                    forkAngle * 2.2,
                    radius * 18.0
                    - time * 5.0
                    + fi * 3.0
                )
            )
        );

        thinFork *=
            forkRegion
            * forkBreakup;

        softFork *=
            forkRegion
            * forkBreakup;

        forks = max(
            forks,
            thinFork
        );

        forkGlow = max(
            forkGlow,
            softFork
        );
    }

    /*
     * ------------------------------------------------------------
     * CENTRAL ELECTRICAL KNOT
     * ------------------------------------------------------------
     *
     * A compact turbulent knot gives the bolts something to erupt
     * from without turning the projectile into a smooth solid core.
     */
    float knotNoise = fbm(
        p * 15.0
        + vec2(
            time * 4.4,
            -time * 3.6
        )
    );

    float centralKnot =
        1.0
        - smoothstep(
            0.10,
            0.34,
            radius
            + (knotNoise - 0.5) * 0.10
        );

    float knotFlash =
        centralKnot
        * (
            0.55
            + randomFlash * 0.65
        );

    /*
     * Thin electrical shell arcs along the outside boundary.
     */
    float shellBand =
        smoothstep(
            0.68,
            0.92,
            distortedRadius
        )
        * (
            1.0
            - smoothstep(
                0.92,
                1.08,
                distortedRadius
            )
        );

    float shellBreakup = smoothstep(
        0.34,
        0.70,
        fbm(
            vec2(
                angle * 5.0
                - time * 4.0,
                radius * 20.0
                + time * 2.0
            )
        )
    );

    float shellElectricity =
        shellBand
        * shellBreakup;

    /*
     * ------------------------------------------------------------
     * COLOR
     * ------------------------------------------------------------
     */

    vec3 darkElectricColor =
        projectilePrimaryColor
        * 0.42;

    vec3 bodyColor = mix(
        darkElectricColor,
        projectilePrimaryColor,
        innerEnergy * 0.72
    );

    color = bodyColor;

    /*
     * Broad arc glow is secondary-colored, while the actual bolt
     * centers use the hottest accent color.
     */
    color +=
        projectileSecondaryColor
        * arcGlow
        * 0.58;

    color +=
        projectileAccentColor
        * arcs
        * (
            1.30
            + randomFlash * 0.65
        );

    color +=
        projectileSecondaryColor
        * forkGlow
        * 0.54;

    color +=
        projectileAccentColor
        * forks
        * (
            1.45
            + randomFlash * 0.75
        );

    color +=
        projectileSecondaryColor
        * shellElectricity
        * 0.62;

    color +=
        projectileAccentColor
        * shellElectricity
        * shellBreakup
        * 0.48;

    /*
     * The center flashes irregularly but remains textured.
     */
    color = mix(
        color,
        projectileSecondaryColor,
        knotFlash * 0.42
    );

    color +=
        projectileAccentColor
        * centralKnot
        * knotNoise
        * (
            0.42
            + randomFlash * 0.38
        );

    /*
     * Whole-ball electrical flicker.
     */
    color *= flicker;

    /*
     * Rare stronger flash frames.
     */
    float burstFlash = smoothstep(
        0.88,
        0.985,
        randomFlash
    );

    color +=
        projectileAccentColor
        * electricBody
        * burstFlash
        * 0.44;

    /*
     * Alpha is driven by the electrical atmosphere and the visible
     * discharge network. Edges remain irregular and energetic.
     */
    alpha =
        electricBody * 0.48
        + innerEnergy * 0.20
        + arcGlow * 0.24
        + arcs * 0.66
        + forkGlow * 0.20
        + forks * 0.72
        + centralKnot * 0.31
        + shellElectricity * 0.30;

    alpha *=
        0.82
        + randomFlash * 0.22;

    alpha = saturate(alpha);
}

void materialFrost(
    vec2 p,
    float radius,
    float angle,
    float time,
    out vec3 color,
    out float alpha)
{
    /*
     * Six-pointed frost crystal.
     *
     * The existing star silhouette is preserved, but the interior now
     * contains layered ice, cyan frozen veins, crystalline fractures,
     * drifting frost grains, and a cold outer haze.
     */

    float sixPointShape = abs(
        sin(
            angle * 6.0
            + fbm(p * 3.5) * 1.35
        )
    );

    float crystalFacets = smoothstep(
        0.24,
        0.94,
        sixPointShape
    );

    /*
     * Maintain the pointed star shape while making the points feel
     * more like ice blades.
     */
    float starExtension =
        pow(
            crystalFacets,
            1.35
        )
        * 0.20;

    float surfaceNoise = fbm(
        p * 6.5
        + vec2(
            time * 0.025,
            -time * 0.018
        )
        + entitySeed * 0.013
    );

    float fineIceNoise = fbm(
        p * 16.0
        + entitySeed * 0.027
    );

    float shapedRadius =
        radius
        - starExtension
        + (surfaceNoise - 0.5) * 0.055;

    float body =
        1.0
        - smoothstep(
            0.76,
            1.03,
            shapedRadius
        );

    /*
     * Dense frozen center.
     */
    float frozenCore =
        1.0
        - smoothstep(
            0.15,
            0.48,
            radius
            + (surfaceNoise - 0.5) * 0.045
        );

    float coreHalo =
        1.0
        - smoothstep(
            0.34,
            0.68,
            radius
        );

    /*
     * Radial ice veins running from the center into all six points.
     */
    float radialVeinWave = abs(
        sin(
            angle * 6.0
            + radius * 18.0
            + surfaceNoise * 2.4
        )
    );

    float radialVeins =
        1.0
        - smoothstep(
            0.025,
            0.105,
            radialVeinWave
        );

    radialVeins *=
        smoothstep(
            0.10,
            0.30,
            radius
        )
        * body;

    /*
     * Secondary branching fractures create the frozen/cracked look.
     */
    float fractureFieldA =
        abs(
            fbm(
                p * 10.0
                + vec2(
                    time * 0.015,
                    0.0
                )
                + entitySeed
            )
            - 0.5
        );

    float fractureFieldB =
        abs(
            fbm(
                vec2(
                    p.y,
                    -p.x
                ) * 14.0
                - entitySeed * 0.43
            )
            - 0.5
        );

    float fracturesA =
        1.0
        - smoothstep(
            0.018,
            0.070,
            fractureFieldA
        );

    float fracturesB =
        1.0
        - smoothstep(
            0.015,
            0.055,
            fractureFieldB
        );

    float fractures =
        max(
            fracturesA,
            fracturesB * 0.72
        )
        * body;

    /*
     * Tiny frozen grains trapped inside the ice.
     */
    vec2 grainGrid = p * 18.0;
    vec2 grainCell = floor(grainGrid);
    vec2 grainUv = fract(grainGrid) - 0.5;

    vec2 grainPoint = vec2(
        hash21(grainCell + entitySeed),
        hash21(grainCell + entitySeed + 31.0)
    ) - 0.5;

    float grainDistance = length(
        grainUv
        - grainPoint * 0.58
    );

    float frostGrains =
        1.0
        - smoothstep(
            0.025,
            0.105,
            grainDistance
        );

    float grainVisibility = hash21(
        grainCell
        + floor(time * 1.4)
        + entitySeed * 0.3
    );

    frostGrains *=
        smoothstep(
            0.67,
            0.88,
            grainVisibility
        )
        * body
        * (
            1.0
            - frozenCore * 0.55
        );

    /*
     * Cyan rim concentrated along the six icy points.
     */
    float edge =
        smoothstep(
            0.58,
            0.94,
            shapedRadius
        )
        * body;

    float pointedEdge =
        edge
        * (
            0.42
            + crystalFacets * 0.78
        );

    /*
     * Cold mist beyond the hard crystal body.
     */
    float mistNoise = fbm(
        p * 4.0
        + vec2(
            time * 0.08,
            -time * 0.055
        )
    );

    float coldMist =
        (
            1.0
            - smoothstep(
                0.82,
                1.18,
                radius
                + (mistNoise - 0.5) * 0.16
            )
        )
        * (
            1.0 - body
        );

    /*
     * Slow crystalline shimmer, intentionally restrained so it reads
     * as ice rather than a generic glowing star.
     */
    float shimmer =
        0.90
        + 0.10
        * sin(
            time * 1.65
            + angle * 6.0
            + radius * 14.0
            + fineIceNoise * 2.0
        );

    /*
     * COLOR
     *
     * primary   = deep icy blue
     * secondary = cyan
     * accent    = pale ice highlight
     */
    vec3 deepIce =
        projectilePrimaryColor
        * vec3(
            0.50,
            0.68,
            0.92
        );

    vec3 iceBody = mix(
        deepIce,
        projectilePrimaryColor,
        crystalFacets * 0.44
        + surfaceNoise * 0.18
    );

    color = iceBody;

    /*
     * The large frozen center remains blue rather than white.
     */
    color = mix(
        color,
        projectilePrimaryColor * 0.72,
        coreHalo * 0.52
    );

    color = mix(
        color,
        projectileSecondaryColor,
        frozenCore * 0.40
    );

    /*
     * Cyan is strongest in the six radial veins and around the points.
     */
    float cyanIce =
        saturate(
            radialVeins * 0.72
            + pointedEdge * 0.42
            + fractures * 0.20
        );

    color = mix(
        color,
        projectileSecondaryColor,
        cyanIce * 0.72
    );

    /*
     * Pale highlights are thin and localized to cracks and grains,
     * avoiding an overly white projectile.
     */
    float paleIce =
        saturate(
            fractures * 0.34
            + frostGrains * 0.55
            + pointedEdge * 0.12
        );

    color = mix(
        color,
        projectileAccentColor,
        paleIce * 0.42
    );

    color +=
        projectileSecondaryColor
        * coldMist
        * 0.16;

    color *= shimmer;

    /*
     * A small cold glint at the absolute center.
     */
    float centerGlint =
        1.0
        - smoothstep(
            0.02,
            0.15,
            radius
        );

    color +=
        projectileAccentColor
        * centerGlint
        * 0.28;

    alpha =
        body
        * (
            0.72
            + frozenCore * 0.14
            + radialVeins * 0.08
            + fractures * 0.08
            + pointedEdge * 0.10
        );

    alpha +=
        coldMist * 0.18;

    alpha = saturate(alpha);
}

void materialNature(
    vec2 p,
    float radius,
    float angle,
    float time,
    out vec3 color,
    out float alpha)
{
    /*
     * A solid living green seed/orb.
     *
     * The center is an opaque emerald object rather than a generic
     * glowing energy ball. Leaf-like cells, branching veins, a soft
     * chlorophyll pulse, and a restrained green aura give it a
     * distinctly natural identity.
     */

    float surfaceNoise = fbm(
        p * 5.5
        + vec2(
            time * 0.035,
            -time * 0.025
        )
        + entitySeed * 0.017
    );

    float fineNoise = fbm(
        p * 14.0
        + vec2(
            -time * 0.055,
            time * 0.045
        )
        + entitySeed * 0.031
    );

    float distortedRadius =
        radius
        + (surfaceNoise - 0.5) * 0.075
        + (fineNoise - 0.5) * 0.025;

    float body =
        1.0
        - smoothstep(
            0.78,
            1.04,
            distortedRadius
        );

    /*
     * Large dense green center.
     */
    float seedCore =
        1.0
        - smoothstep(
            0.18,
            0.62,
            radius
            + (surfaceNoise - 0.5) * 0.055
        );

    float innerBody =
        1.0
        - smoothstep(
            0.42,
            0.84,
            radius
        );

    /*
     * Organic cellular pattern, like plant cells beneath the surface.
     */
    vec2 cellularP = p * 7.5;
    vec2 cellId = floor(cellularP);
    vec2 cellUv = fract(cellularP) - 0.5;

    float nearest = 10.0;
    float secondNearest = 10.0;

    for (int y = -1; y <= 1; y++)
    {
        for (int x = -1; x <= 1; x++)
        {
            vec2 offset = vec2(
                float(x),
                float(y)
            );

            vec2 randomPoint = vec2(
                hash21(cellId + offset + entitySeed),
                hash21(cellId + offset + entitySeed + 19.0)
            );

            randomPoint =
                0.5
                + 0.30
                * sin(
                    time * 0.28
                    + 6.2831 * randomPoint
                );

            float distanceToCell = length(
                offset
                + randomPoint
                - (cellUv + 0.5)
            );

            if (distanceToCell < nearest)
            {
                secondNearest = nearest;
                nearest = distanceToCell;
            }
            else if (distanceToCell < secondNearest)
            {
                secondNearest = distanceToCell;
            }
        }
    }

    float cellInterior =
        1.0
        - smoothstep(
            0.20,
            0.52,
            nearest
        );

    float cellBorders =
        1.0
        - smoothstep(
            0.015,
            0.075,
            secondNearest - nearest
        );

    cellInterior *= body;
    cellBorders *= body;

    /*
     * Branching leaf veins.
     */
    float majorVeinField = abs(
        fbm(
            vec2(
                p.x * 4.2,
                p.y * 7.8
            )
            + vec2(
                0.0,
                -time * 0.045
            )
            + entitySeed * 0.021
        )
        - 0.5
    );

    float majorVeins =
        1.0
        - smoothstep(
            0.022,
            0.085,
            majorVeinField
        );

    float minorVeinField = abs(
        fbm(
            vec2(
                p.y * 11.0,
                -p.x * 8.5
            )
            + vec2(
                time * 0.035,
                0.0
            )
            - entitySeed * 0.013
        )
        - 0.5
    );

    float minorVeins =
        1.0
        - smoothstep(
            0.018,
            0.060,
            minorVeinField
        );

    float veins =
        max(
            majorVeins,
            minorVeins * 0.58
        )
        * body;

    /*
     * Leaf-shaped highlights rotate very slowly inside the object.
     */
    float leafAngle =
        angle
        + sin(
            radius * 9.0
            - time * 0.45
        ) * 0.18;

    float leafPattern = abs(
        sin(
            leafAngle * 3.0
            + radius * 12.0
            + surfaceNoise * 2.0
        )
    );

    float leafShapes =
        1.0
        - smoothstep(
            0.055,
            0.18,
            leafPattern
        );

    leafShapes *=
        smoothstep(
            0.20,
            0.50,
            radius
        )
        * (
            1.0
            - smoothstep(
                0.66,
                0.96,
                radius
            )
        )
        * body;

    /*
     * Restrained living pulse. This changes brightness slightly
     * without making the entire object look like pure energy.
     */
    float lifePulse =
        0.91
        + 0.09
        * sin(
            time * 1.65
            + surfaceNoise * 3.0
            + entitySeed * 0.11
        );

    /*
     * Soft green haze at the boundary.
     */
    float rim =
        smoothstep(
            0.60,
            0.94,
            distortedRadius
        )
        * body;

    float auraNoise = fbm(
        p * 4.2
        + vec2(
            time * 0.08,
            -time * 0.06
        )
    );

    float aura =
        (
            1.0
            - smoothstep(
                0.86,
                1.18,
                radius
                + (auraNoise - 0.5) * 0.12
            )
        )
        * (
            1.0 - body
        );

    /*
     * COLOR
     *
     * primary   = saturated emerald green
     * secondary = fresh leaf green
     * accent    = yellow-green highlights
     */
    vec3 shadedGreen =
        projectilePrimaryColor
        * vec3(
            0.42,
            0.66,
            0.38
        );

    color = mix(
        shadedGreen,
        projectilePrimaryColor,
        innerBody * 0.62
        + surfaceNoise * 0.20
    );

    /*
     * Plant-cell interiors vary between emerald and leaf green.
     */
    color = mix(
        color,
        projectileSecondaryColor,
        cellInterior * 0.30
    );

    /*
     * Veins and leaf marks are brighter but remain green.
     */
    float brightGrowth =
        saturate(
            veins * 0.66
            + leafShapes * 0.42
            + cellBorders * 0.20
        );

    color = mix(
        color,
        projectileSecondaryColor,
        brightGrowth * 0.62
    );

    color = mix(
        color,
        projectileAccentColor,
        veins * 0.22
        + leafShapes * 0.18
        + seedCore * 0.08
    );

    /*
     * Keep the center rich green and solid.
     */
    color = mix(
        color,
        projectilePrimaryColor,
        seedCore * 0.46
    );

    color +=
        projectileSecondaryColor
        * rim
        * 0.12;

    color +=
        projectileSecondaryColor
        * aura
        * 0.10;

    color *= lifePulse;

    alpha =
        body
        * (
            0.82
            + seedCore * 0.10
            + veins * 0.05
            + rim * 0.05
        );

    alpha +=
        aura * 0.13;

    alpha = saturate(alpha);
}

void materialArcane(
    vec2 p,
    float radius,
    float angle,
    float time,
    out vec3 color,
    out float alpha)
{
    /*
     * Shadowbolt-style arcane projectile.
     *
     * A light-absorbing black-violet center surrounded by swirling
     * purple smoke, rotating magical fractures, tiny void discharges,
     * and unraveling shadow wisps.
     */

    float phase =
        floor(time * 13.0)
        + entitySeed;

    float randomFlash = hash21(
        vec2(
            phase,
            phase * 0.713
        )
    );

    /*
     * Slowly rotating coordinate fields for layered shadow motion.
     */
    float rotationA =
        time * 0.42;

    float rotationB =
        -time * 0.31;

    mat2 rotA = mat2(
        cos(rotationA), -sin(rotationA),
        sin(rotationA),  cos(rotationA)
    );

    mat2 rotB = mat2(
        cos(rotationB), -sin(rotationB),
        sin(rotationB),  cos(rotationB)
    );

    vec2 shadowP =
        rotA * p;

    vec2 fractureP =
        rotB * p;

    /*
     * Swirling interior smoke.
     */
    float smokeA = fbm(
        shadowP * 5.2
        + vec2(
            time * 0.22,
            -time * 0.16
        )
        + entitySeed * 0.017
    );

    float smokeB = fbm(
        fractureP * 10.5
        + vec2(
            -time * 0.31,
            time * 0.26
        )
        - entitySeed * 0.011
    );

    float fineSmoke = fbm(
        p * 19.0
        + vec2(
            time * 0.55,
            -time * 0.48
        )
    );

    float distortedRadius =
        radius
        + (smokeA - 0.5) * 0.12
        + (smokeB - 0.5) * 0.055
        + (fineSmoke - 0.5) * 0.022;

    float shadowBody =
        1.0
        - smoothstep(
            0.56,
            1.08,
            distortedRadius
        );

    /*
     * Dense black void core that absorbs rather than emits light.
     */
    float voidCore =
        1.0
        - smoothstep(
            0.42,
            0.90,
            radius
            + (smokeA - 0.5) * 0.065
        );

    float innerVoid =
        1.0
        - smoothstep(
            0.76,
            0.94,
            radius
            + (fineSmoke - 0.5) * 0.04
        );

    /*
     * Purple smoke pockets beneath the surface.
     */
    float violetSmoke =
        smoothstep(
            0.42,
            0.78,
            smokeA
        )
        * shadowBody
        * (
            1.0 - innerVoid * 0.70
        );

    float brightSmoke =
        smoothstep(
            0.58,
            1.86,
            smokeB
        )
        * shadowBody
        * (
            1.0 - voidCore * 0.42
        );

    /*
     * ------------------------------------------------------------
     * ROTATING ARCANE FRACTURES
     * ------------------------------------------------------------
     *
     * These behave like glowing cracks through black obsidian.
     */
    float fractureAngle =
        atan(
            fractureP.y,
            fractureP.x
        );

    float fractureWaveA = abs(
        sin(
            fractureAngle * 5.0
            + radius * 14.0
            + smokeB * 3.6
        )
    );

    float fractureWaveB = abs(
        sin(
            fractureAngle * 8.0
            - radius * 21.0
            + smokeA * 4.2
            + 1.7
        )
    );

    float fractureA =
        1.0
        - smoothstep(
            0.022,
            0.085,
            fractureWaveA
        );

    float fractureB =
        1.0
        - smoothstep(
            0.018,
            0.070,
            fractureWaveB
        );

    float fractures =
        max(
            fractureA,
            fractureB * 0.72
        );

    float fractureBreakup = smoothstep(
        0.30,
        0.70,
        fbm(
            vec2(
                fractureAngle * 3.0,
                radius * 18.0
                - time * 0.75
            )
            + entitySeed * 0.023
        )
    );

    fractures *=
        fractureBreakup
        * shadowBody
        * smoothstep(
            0.42,
            0.72,
            radius
        );

    float fractureGlow =
        (
            1.0
            - smoothstep(
                0.24,
                0.78,
                min(
                    fractureWaveA,
                    fractureWaveB
                )
            )
        )
        * fractureBreakup
        * shadowBody;

    /*
     * ------------------------------------------------------------
     * TINY VOID LIGHTNING
     * ------------------------------------------------------------
     */
    float voidArcs = 0.0;
    float voidArcGlow = 0.0;

    for (int i = 0; i < 3; i++)
    {
        float fi = float(i);

        float arcAngle =
            angle
            + time * (
                1.25
                + fi * 0.33
            )
            * (
                mod(fi, 2.0) < 1.0
                ? 1.0
                : -1.0
            );

        float arcWave = abs(
            sin(
                arcAngle * (
                    4.0
                    + fi
                )
                + radius * (
                    20.0
                    + fi * 5.0
                )
                + smokeB * 3.5
                + fi * 2.1
            )
        );

        float thinArc =
            1.0
            - smoothstep(
                0.064,
                0.080,
                arcWave
            );

        float softArc =
            1.0
            - smoothstep(
                0.030,
                0.15,
                arcWave
            );

        float arcRegion =
            smoothstep(
                0.45,
                0.72,
                radius
            )
            * (
                1.0
                - smoothstep(
                    0.72,
                    1.02,
                    radius
                )
            );

        float breakup = smoothstep(
            0.34,
            0.69,
            fbm(
                vec2(
                    arcAngle * 2.0,
                    radius * 17.0
                    - time * 3.0
                    + fi * 4.0
                )
            )
        );

        thinArc *=
            arcRegion
            * breakup;

        softArc *=
            arcRegion
            * breakup;

        voidArcs = max(
            voidArcs,
            thinArc
        );

        voidArcGlow = max(
            voidArcGlow,
            softArc
        );
    }

    /*
     * ------------------------------------------------------------
     * UNRAVELING SHADOW WISPS
     * ------------------------------------------------------------
     *
     * Wisps curl beyond the main sphere and fade away.
     */
    float wispAngle =
        angle
        + time * 0.48
        + smokeA * 1.8;

    float wispWave = abs(
        sin(
            wispAngle * 4.0
            - radius * 13.0
            + time * 1.1
        )
    );

    float wispStrands =
        1.0
        - smoothstep(
            0.035,
            0.16,
            wispWave
        );

    float wispRegion =
        smoothstep(
            0.74,
            0.92,
            radius
        )
        * (
            1.0
            - smoothstep(
                0.94,
                1.28,
                radius
                + (smokeA - 0.5) * 0.16
            )
        );

    float wispBreakup = smoothstep(
        0.38,
        0.74,
        fbm(
            vec2(
                wispAngle * 2.6,
                radius * 10.0
                - time * 0.9
            )
        )
    );

    float shadowWisps =
        wispStrands
        * wispRegion
        * wispBreakup;

    /*
     * Dark outer vapor around the body.
     */
    float outerShadow =
        (
            1.0
            - smoothstep(
                0.82,
                1.20,
                radius
                + (smokeA - 0.5) * 0.18
            )
        )
        * (
            1.0 - shadowBody
        );

    /*
     * Rare pulse through cracks and arcs.
     */
    float pulse =
        0.88
        + 0.12
        * sin(
            time * 2.2
            + smokeB * 4.0
            + entitySeed * 0.15
        );

    float burstFlash = smoothstep(
        0.91,
        0.995,
        randomFlash
    );

    /*
     * COLOR
     *
     * primary   = black-violet
     * secondary = saturated purple
     * accent    = lavender-magenta flare
     */
    vec3 nearBlack =
        vec3(
            0.004,
            0.000,
            0.010
        );

    vec3 blackViolet =
        projectilePrimaryColor
        * vec3(
            0.20,
            0.08,
            0.32
        );

    color = mix(
        blackViolet,
        nearBlack,
        voidCore * 0.88
    );

    /*
     * Keep the absolute center almost black.
     */
    color = mix(
        color,
        nearBlack,
        innerVoid
    );

    /*
     * Purple smoke lives beneath the black surface.
     */
    color +=
        projectilePrimaryColor
        * violetSmoke
        * 0.34;

    color +=
        projectileSecondaryColor
        * brightSmoke
        * 0.24;

    /*
     * Cracks are the principal bright feature.
     */
    color +=
        projectileSecondaryColor
        * fractureGlow
        * 0.42;

    color +=
        projectileAccentColor
        * fractures
        * (
            0.92
            + randomFlash * 0.34
        );

    /*
     * Tiny void lightning.
     */
    color +=
        projectileSecondaryColor
        * voidArcGlow
        * 0.38;

    color +=
        projectileAccentColor
        * voidArcs
        * (
            1.10
            + randomFlash * 0.45
        );

    /*
     * Wisps remain mostly black-purple, with only their innermost
     * portions catching purple light.
     */
    color +=
        projectilePrimaryColor
        * shadowWisps
        * 0.26;

    color +=
        projectileSecondaryColor
        * shadowWisps
        * wispBreakup
        * 0.14;

    color +=
        projectilePrimaryColor
        * outerShadow
        * 0.10;

    /*
     * Rare reality-tear flare.
     */
    color +=
        projectileAccentColor
        * (
            fractures * 0.42
            + voidArcs * 0.55
        )
        * burstFlash;

    color *= pulse;

    /*
     * Preserve the black center after all additive effects.
     */
    color = mix(
        color,
        nearBlack,
        innerVoid * 0.78
    );

    alpha =
        shadowBody
        * (
            0.74
            + voidCore * 0.13
            + fractureGlow * 0.08
            + fractures * 0.10
            + voidArcGlow * 0.06
            + voidArcs * 0.12
        );

    alpha +=
        shadowWisps * 0.30
        + outerShadow * 0.16;

    alpha = saturate(alpha);
}

void main()
{
    vec2 p = uv * 2.0 - 1.0;

    float radius = length(p);
    float angle = atan(p.y, p.x);
    float time = u_time + entitySeed * 0.013;

    vec3 color = vec3(0.0);
    float alpha = 0.0;

    if (projectileType == 0)
    {
        materialRust(
            p,
            radius,
            angle,
            time,
            color,
            alpha
        );
    }
    else if (projectileType == 1)
    {
        materialFire(
            p,
            radius,
            angle,
            time,
            color,
            alpha
        );
    }
    else if (projectileType == 2)
    {
        materialWater(
            p,
            radius,
            angle,
            time,
            color,
            alpha
        );
    }
    else if (projectileType == 3)
    {
        materialWind(
            p,
            radius,
            angle,
            time,
            color,
            alpha
        );
    }
    else if (projectileType == 4)
    {
        materialEarth(
            p,
            radius,
            angle,
            time,
            color,
            alpha
        );
    }
    else if (projectileType == 5)
    {
        materialLightning(
            p,
            radius,
            angle,
            time,
            color,
            alpha
        );
    }
    else if (projectileType == 6)
    {
        materialFrost(
            p,
            radius,
            angle,
            time,
            color,
            alpha
        );
    }
    else if (projectileType == 7)
    {
        materialNature(
            p,
            radius,
            angle,
            time,
            color,
            alpha
        );
    }
    else
    {
        materialArcane(
            p,
            radius,
            angle,
            time,
            color,
            alpha
        );
    }

    /*
     * Fire receives a wider quad mask so the exterior red wisps
     * are not clipped. Other projectile types keep the tighter mask.
     */
    float quadMask;

    if (projectileType == 1)
    {
        quadMask = smoothstep(
            1.40,
            1.18,
            radius
        );
    }
    else
    {
        quadMask = smoothstep(
            1.12,
            0.94,
            radius
        );
    }

    alpha *= quadMask * intensity;
    color *= intensity;

    if (alpha <= 0.003)
    {
        discard;
    }

    vec4 projectileColor = vec4(
        color,
        saturate(alpha)
    );

    projectileColor.rgb = mix(
        projectileColor.rgb,
        rgbaFog.rgb,
        saturate(fogAmount)
    );

    projectileColor.a *=
        1.0
        - saturate(fogAmount) * 0.45;

    outColor = projectileColor;
}
