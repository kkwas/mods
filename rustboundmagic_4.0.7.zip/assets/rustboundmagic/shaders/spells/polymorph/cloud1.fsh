#version 330 core

in vec2 uv;
in float dist;
in vec4 rgbaFog;
in float fogAmount;

out vec4 outColor;

uniform sampler2D primaryFb;
uniform vec2 invFrameSize;

uniform vec3 projectilePrimaryColor;
uniform vec3 projectileSecondaryColor;
uniform vec3 projectileAccentColor;

uniform float u_time;
uniform float growthProgress;
uniform float entitySeed;
uniform float intensity;
uniform float distortionStrength;

#include noise2d.ash
#include fogandlight.fsh

float fbm(vec2 p)
{
    float value = 0.0;
    float amplitude = 0.52;

    value += cnoise2(p) * amplitude;
    p = p * 2.03 + vec2(17.13, 9.71);
    amplitude *= 0.50;

    value += cnoise2(p) * amplitude;
    p = p * 2.01 + vec2(-7.31, 13.37);
    amplitude *= 0.50;

    value += cnoise2(p) * amplitude;
    p = p * 2.07 + vec2(5.93, -11.17);
    amplitude *= 0.50;

    value += cnoise2(p) * amplitude;

    return value * 0.5 + 0.5;
}

float puff(vec2 p, vec2 center, vec2 scale, float softness)
{
    vec2 q = (p - center) / scale;
    float d = length(q);

    return 1.0 - smoothstep(1.0 - softness, 1.0, d);
}

float smokeLayer(vec2 p, float t, vec2 layerOffset, float layerScale, float seedOffset)
{
    vec2 q = (p - layerOffset) / layerScale;

    q.x += sin(t * 0.42 + q.y * 2.3 + seedOffset) * 0.050;
    q.y += cos(t * 0.31 + q.x * 2.0 + seedOffset * 0.7) * 0.028;

    vec2 warp1 = vec2(
        cnoise2(q * 1.30 + vec2(t * 0.32, -t * 0.19) + seedOffset),
        cnoise2(q * 1.30 + vec2(-t * 0.24, t * 0.29) + 18.4 + seedOffset)
    );

    vec2 warp2 = vec2(
        cnoise2(q * 2.55 + warp1 * 0.75 + vec2(t * 0.23, t * 0.36) + seedOffset * 0.5),
        cnoise2(q * 2.55 + warp1 * 0.75 + vec2(-t * 0.28, t * 0.21) + 37.8 + seedOffset * 0.5)
    );

    vec2 smokeP = q
        + warp1 * (0.115 * distortionStrength)
        + warp2 * (0.060 * distortionStrength);

    float wobbleA = sin(t * 0.51 + seedOffset) * 0.040;
    float wobbleB = cos(t * 0.43 + seedOffset * 1.2) * 0.038;
    float wobbleC = sin(t * 0.61 + 1.7 + seedOffset * 0.8) * 0.034;

    float body = 0.0;

    body = max(body, puff(smokeP, vec2(-0.36 + wobbleA, -0.08 + wobbleC), vec2(0.54, 0.48), 0.32));
    body = max(body, puff(smokeP, vec2( 0.00 + wobbleB,  0.08 + wobbleA), vec2(0.66, 0.59), 0.30));
    body = max(body, puff(smokeP, vec2( 0.37 - wobbleA, -0.03 - wobbleC), vec2(0.52, 0.47), 0.32));

    body = max(body, puff(smokeP, vec2(-0.17 - wobbleB,  0.39 + wobbleA), vec2(0.47, 0.43), 0.34));
    body = max(body, puff(smokeP, vec2( 0.22 + wobbleC,  0.41 - wobbleB), vec2(0.45, 0.41), 0.34));

    body = max(body, puff(smokeP, vec2(-0.20 + wobbleC, -0.38 - wobbleA), vec2(0.49, 0.39), 0.34));
    body = max(body, puff(smokeP, vec2( 0.23 - wobbleB, -0.35 + wobbleC), vec2(0.50, 0.39), 0.34));

    if (body <= 0.001)
    {
        return 0.0;
    }

    float broadNoise = fbm(
        smokeP * 1.85 +
        vec2(t * 0.08, t * 0.24) +
        seedOffset
    );

    float midNoise = fbm(
        smokeP * 3.70 +
        warp1 * 0.70 +
        vec2(-t * 0.14, t * 0.38) +
        seedOffset * 0.6
    );

    float fineNoise = fbm(
        smokeP * 7.40 +
        warp2 * 0.50 +
        vec2(t * 0.22, t * 0.52) +
        seedOffset * 0.3
    );

    float densityNoise =
        broadNoise * 0.52 +
        midNoise   * 0.33 +
        fineNoise  * 0.15;

    float centerDensity =
        1.0 - smoothstep(0.18, 1.18, length(smokeP));

    float density =
        densityNoise * 0.88 +
        centerDensity * 0.34;

    float erosion = fbm(
        smokeP * 4.85 +
        warp1 * 0.28 +
        vec2(-t * 0.20, t * 0.45) +
        seedOffset * 0.4
    );

    density -= (1.0 - erosion) * 0.22;

    float alpha =
        smoothstep(0.29, 0.60, density) *
        body;

    alpha *= smoothstep(0.01, 0.20, body);

    return clamp(alpha, 0.0, 1.0);
}

void main()
{
    vec2 p = uv * 2.0 - 1.0;

    float t = u_time * 0.72 + entitySeed * 5.317;

    // Seven internal layers: close to the visual density of many overlapping
    // smoke quads, but still one effect / one draw call.
    float a1 = smokeLayer(p, t + 0.00, vec2( 0.00,  0.00), 1.00,  0.0);
    float a2 = smokeLayer(p, t + 1.31, vec2( 0.10,  0.05), 0.96, 11.7);
    float a3 = smokeLayer(p, t + 2.47, vec2(-0.11,  0.07), 1.04, 23.1);
    float a4 = smokeLayer(p, t + 3.83, vec2( 0.06, -0.10), 0.94, 37.4);
    float a5 = smokeLayer(p, t + 5.16, vec2(-0.08, -0.07), 1.08, 51.9);
    float a6 = smokeLayer(p, t + 6.42, vec2( 0.14, -0.01), 0.92, 68.3);
    float a7 = smokeLayer(p, t + 7.71, vec2(-0.14,  0.01), 1.02, 84.6);

    // Alpha-composite the internal smoke layers instead of simply averaging them.
    // This is what creates the thick, stacked-cloud appearance.
    float cloudAlpha = 1.0;
    cloudAlpha *= (1.0 - a1 * 0.68);
    cloudAlpha *= (1.0 - a2 * 0.58);
    cloudAlpha *= (1.0 - a3 * 0.56);
    cloudAlpha *= (1.0 - a4 * 0.53);
    cloudAlpha *= (1.0 - a5 * 0.50);
    cloudAlpha *= (1.0 - a6 * 0.47);
    cloudAlpha *= (1.0 - a7 * 0.44);
    cloudAlpha = 1.0 - cloudAlpha;

    float fadeIn = smoothstep(0.00, 0.10, growthProgress);

    // Smoothly fade the entire smoke cloud out near the end of the effect
    // instead of letting it vanish abruptly when the effect is removed.
    float fadeOut = 1.0 - smoothstep(0.78, 1.00, growthProgress);

    cloudAlpha *= fadeIn * fadeOut;

    // Detail field used only for shading so density stays stable while the surface
    // still looks alive.
    float detail = fbm(
        p * 3.0 +
        vec2(t * 0.10, -t * 0.13)
    );

    float center = 1.0 - smoothstep(0.10, 1.15, length(p));

    vec3 darkGray   = vec3(0.18, 0.19, 0.20);
    vec3 mediumGray = vec3(0.42, 0.43, 0.45);
    vec3 lightGray  = vec3(0.67, 0.68, 0.70);
    vec3 smokeWhite = vec3(0.90, 0.91, 0.93);

    vec3 color = mix(darkGray, mediumGray, clamp(center * 0.55 + detail * 0.30, 0.0, 1.0));

    float lightMask =
        smoothstep(0.60, 0.90, detail) *
        (1.0 - center * 0.55);

    color = mix(color, lightGray, lightMask * 0.32);
    color = mix(color, smokeWhite, lightMask * 0.10);

    color *= intensity;

    // Thick, but not an opaque cardboard cutout.
    cloudAlpha *= 0.94;

    cloudAlpha -= clamp(
        (dist * (1.0 + fogAmount * 0.5) - 50.0) / 40.0,
        0.0,
        0.7 + fogAmount * 0.3
    );

    cloudAlpha = clamp(cloudAlpha, 0.0, 1.0);

    if (cloudAlpha < 0.015)
    {
        discard;
    }

    outColor = applyFog(vec4(color, cloudAlpha), fogAmount);
}
