#version 330 core
#extension GL_ARB_explicit_attrib_location: enable

layout(location = 0) in vec3 vertexPosition;
layout(location = 1) in vec2 uvIn;

uniform mat4 projectionMatrix;
uniform mat4 modelViewMatrix;
uniform vec4 worldPos;
uniform vec4 rgbaFogIn;
uniform float fogMinIn;
uniform float fogDensityIn;
uniform float projectileSize;

out vec2 uv;
out float dist;
out vec4 rgbaFog;
out float fogAmount;

#include vertexflagbits.ash
#include fogandlight.vsh

void main()
{
    uv = uvIn;

    // Keep the projectile quad billboarded by the renderer. In this shader,
    // a larger projectileSize means a physically larger projectile.
    vec3 scaledPosition = vertexPosition * projectileSize;
    vec4 cameraPosition = modelViewMatrix * vec4(scaledPosition, 1.0);

    gl_Position = projectionMatrix * cameraPosition;

    fogAmount = getFogLevel(worldPos, fogMinIn, fogDensityIn);
    rgbaFog = rgbaFogIn;
    dist = length(worldPos);
}
