#version 330 core

in vec2 uv;
in float dist;
in vec4 rgbaFog;
in float fogAmount;

out vec4 outColor;

uniform sampler2D primaryFb;
uniform sampler2D depthTex;
uniform vec2 invFrameSize;

uniform float counter;
uniform float counterSmooth;
uniform float u_time;

uniform float rippleIntensity;
uniform float membraneTransparency;

uniform vec3 projectilePrimaryColor;

/*
    Oculus ripple palette.

    Feed these from the renderer.
    Any unset (0,0,0) color falls back to the built-in palette.
*/
uniform vec3 portalMembraneColor;
uniform vec3 portalRingPrimaryColor;
uniform vec3 portalRingSecondaryColor;
uniform vec3 portalVeinColor;

#include noise2d.ash
#include fogandlight.fsh

float saturate(float value)
{
    return clamp(value, 0.0, 1.0);
}

float fbm(vec2 p)
{
    float value = 0.0;
    float amplitude = 0.52;

    for (int octave = 0; octave < 5; octave++)
    {
        value += cnoise2(p) * amplitude;
        p = p * 2.03 + vec2(17.2, 9.4);
        amplitude *= 0.50;
    }

    return value * 0.5 + 0.5;
}

float surfaceHeight(vec2 p, float time, float rippleIntensityIn)
{
    /*
        rippleIntensity:
        0.0 = slow, broad, subdued ripples
        1.0 = fast, tight, bright ripples
    */
    float ripplePower = clamp(rippleIntensityIn, 0.0, 1.0);
    float rippleSpeed = mix(0.45, 2.25, ripplePower);
    float rippleFrequency = mix(0.70, 1.65, ripplePower);

    /*
        Multiple ripple sources spread over the entire square plane.
        No radial mask is used, so the effect fills the full 3x3 surface.
    */
    vec2 sourceA = vec2(
        0.20 + 0.18 * sin(time * 0.31),
        0.34 + 0.14 * cos(time * 0.27)
    );

    vec2 sourceB = vec2(
        0.73 + 0.13 * cos(time * 0.23),
        0.65 + 0.17 * sin(time * 0.35)
    );

    vec2 sourceC = vec2(
        0.52 + 0.22 * sin(time * 0.19),
        0.18 + 0.11 * cos(time * 0.29)
    );

    float distanceA = length(p - sourceA);
    float distanceB = length(p - sourceB);
    float distanceC = length(p - sourceC);

    float rippleA =
        sin(distanceA * (38.0 * rippleFrequency) - time * (3.2 * rippleSpeed))
        * exp(-distanceA * 1.35);

    float rippleB =
        sin(distanceB * (34.0 * rippleFrequency) - time * (2.8 * rippleSpeed))
        * exp(-distanceB * 1.30);

    float rippleC =
        sin(distanceC * (42.0 * rippleFrequency) - time * (3.6 * rippleSpeed))
        * exp(-distanceC * 1.45);

    /*
        Broad traveling waves prevent the plane from looking like several
        isolated pond splashes.
    */
    float broadWaveA =
        sin(
            p.x * (15.0 * rippleFrequency)
            + p.y * (9.0 * rippleFrequency)
            - time * (1.9 * rippleSpeed)
        );

    float broadWaveB =
        sin(
            p.x * (-10.0 * rippleFrequency)
            + p.y * (17.0 * rippleFrequency)
            - time * (1.45 * rippleSpeed)
        );

    float flowingNoise =
        fbm(
            p * 5.0
            + vec2(
                time * (0.10 * rippleSpeed),
                -time * (0.085 * rippleSpeed)
            )
        )
        * 2.0
        - 1.0;

    return
        rippleA * 0.58
        + rippleB * 0.52
        + rippleC * 0.46
        + broadWaveA * 0.18
        + broadWaveB * 0.14
        + flowingNoise * 0.18;
}

void main()
{
    vec2 screenUv =
        gl_FragCoord.xy
        * invFrameSize;

    float sceneDepth =
        linearDepth(
            texture(
                depthTex,
                screenUv
            ).r
        );

    float planeDepth =
        linearDepth(gl_FragCoord.z);

    float depthDifference =
        max(
            0.0,
            planeDepth - sceneDepth
        )
        * 10000.0;

    if (depthDifference > 2.0)
    {
        discard;
    }

    float time = u_time;

    float ripplePower = clamp(rippleIntensity, 0.0, 1.0);
    float rippleBrightness = mix(0.25, 1.00, ripplePower);

    /*
        Use the full UV square.
        There is intentionally NO circular clipping and NO decorative edge.
    */
    vec2 p = uv;

    /*
        Tiny inset fade only to hide interpolation artifacts at the exact
        billboard border. It is not a portal rim.
    */
    float edgeDistance =
        min(
            min(p.x, 1.0 - p.x),
            min(p.y, 1.0 - p.y)
        );

    float squareMask =
        smoothstep(
            0.002,
            0.018,
            edgeDistance
        );

    /*
        Build a fake liquid surface normal from the ripple height field.
    */
    float height =
        surfaceHeight(
            p,
            time,
            rippleIntensity
        );

    float sampleDistance = 0.0065;

    float heightX =
        surfaceHeight(
            p + vec2(sampleDistance, 0.0),
            time,
            rippleIntensity
        );

    float heightY =
        surfaceHeight(
            p + vec2(0.0, sampleDistance),
            time,
            rippleIntensity
        );

    vec3 surfaceNormal =
        normalize(
            vec3(
                (height - heightX) * 11.0,
                (height - heightY) * 11.0,
                sampleDistance * 1.45
            )
        );

    /*
        Refraction remains subtle. The Oculus should read primarily as a
        colored magical liquid plane, not as a black-hole portal.
    */
    vec2 distortedScreenUv =
        screenUv
        + surfaceNormal.xy * mix(0.008, 0.024, ripplePower)
        + vec2(
            cnoise2(p * 5.5 + time * 0.20),
            cnoise2(p * 5.5 - time * 0.17)
        ) * 0.0015;

    distortedScreenUv =
        clamp(
            distortedScreenUv,
            vec2(0.001),
            vec2(0.999)
        );

    vec3 sceneColor =
        texture(
            primaryFb,
            distortedScreenUv
        ).rgb;

    /*
        Renderer-controlled palette with bright fallbacks.
    */
    vec3 baseColor =
        length(portalMembraneColor) > 0.001
        ? portalMembraneColor
        : vec3(0.16, 0.42, 1.00);

    vec3 colorA =
        length(portalRingPrimaryColor) > 0.001
        ? portalRingPrimaryColor
        : vec3(0.74, 0.10, 1.00);

    vec3 colorB =
        length(portalRingSecondaryColor) > 0.001
        ? portalRingSecondaryColor
        : vec3(0.05, 0.95, 1.00);

    vec3 colorC =
        length(portalVeinColor) > 0.001
        ? portalVeinColor
        : vec3(1.00, 0.28, 0.78);

    /*
        Ripple crests and troughs.
    */
    float crest =
        smoothstep(
            0.18,
            0.72,
            height
        );

    float trough =
        smoothstep(
            0.18,
            0.72,
            -height
        );

    /*
        Large-scale color flow.
        This intentionally uses a LOT of color and lets the supplied palette
        roll across the square instead of assigning one flat tint.
    */
    float colorFlowA =
        fbm(
            p * 3.1
            + vec2(
                time * 0.055,
                -time * 0.070
            )
        );

    float colorFlowB =
        fbm(
            p * 5.4
            + vec2(
                -time * 0.072,
                time * 0.048
            )
        );

    float colorFlowC =
        sin(
            p.x * 7.0
            + p.y * 5.0
            - time * 0.82
            + colorFlowA * 3.0
        )
        * 0.5
        + 0.5;

    vec3 magicalColor =
        mix(
            baseColor,
            colorA,
            colorFlowA
        );

    magicalColor =
        mix(
            magicalColor,
            colorB,
            colorFlowB * 0.72
        );

    magicalColor =
        mix(
            magicalColor,
            colorC,
            colorFlowC * 0.48
        );

    /*
        Bright liquid highlights make the ripples visible.
    */
    vec3 lightDirection =
        normalize(
            vec3(
                -0.35,
                0.42,
                0.84
            )
        );

    float surfaceLighting =
        dot(
            surfaceNormal,
            lightDirection
        )
        * 0.5
        + 0.5;

    float highlight =
        pow(
            saturate(
                dot(
                    surfaceNormal,
                    normalize(
                        vec3(
                            -0.18,
                            0.25,
                            1.0
                        )
                    )
                )
            ),
            10.0
        );

    /*
        Thin luminous ripple lines.
    */
    float rippleLine =
        smoothstep(
            0.25,
            0.70,
            abs(height)
        );

    vec3 brightColor =
        mix(
            colorB,
            vec3(1.0),
            0.72
        );

    vec3 finalRgb =
        magicalColor
        * (
            0.62
            + surfaceLighting * 0.58
        );

    finalRgb +=
        brightColor
        * crest
        * mix(0.18, 0.52, rippleBrightness);

    finalRgb +=
        colorA
        * trough
        * 0.24;

    finalRgb +=
        brightColor
        * rippleLine
        * mix(0.07, 0.28, rippleBrightness);

    finalRgb +=
        vec3(1.0)
        * highlight
        * mix(0.08, 0.44, rippleBrightness);

    /*
        Preserve a little of the scene behind the plane so it feels like
        translucent magical liquid rather than an opaque texture.
    */
    finalRgb =
        mix(
            sceneColor,
            finalRgb,
            0.82
        );

    /*
        membraneTransparency:
        0.0 = fully transparent
        1.0 = normal/full membrane opacity
    */
    float membraneAlpha = clamp(membraneTransparency, 0.0, 1.0);

    float alpha =
        (
            0.72
            + crest * 0.12
            + rippleLine * 0.08
        )
        * squareMask
        * membraneAlpha;

    alpha =
        clamp(
            alpha - depthDifference,
            0.0,
            1.0
        );

    alpha -=
        clamp(
            (
                dist
                * (
                    1.0
                    + fogAmount * 0.5
                )
                - 50.0
            )
            / 40.0,
            0.0,
            0.72
            + fogAmount * 0.28
        );

    if (alpha < 0.015)
    {
        discard;
    }

    outColor =
        applyFog(
            vec4(
                finalRgb,
                alpha
            ),
            fogAmount
        );
}
