#version 330 core

const float PI = 3.14159265358979323846;
const float TAU = 6.28318530717958647692;

in vec2 uv;
in float dist;
in vec4 rgbaFog;
in float fogAmount;

out vec4 outColor;

uniform int riftIndex;
uniform sampler2D primaryFb;
uniform sampler2D depthTex;
uniform vec2 invFrameSize;

uniform float counter;
uniform float counterSmooth;
uniform float u_time;

// Legacy tint uniform retained for renderer compatibility.
uniform vec3 projectilePrimaryColor;

// Renderer-controlled portal palette. If a color is not supplied,
// the shader falls back to the original built-in portal color.
uniform vec3 portalMembraneColor;
uniform vec3 portalRingPrimaryColor;
uniform vec3 portalRingSecondaryColor;
uniform vec3 portalVeinColor;

#include noise2d.ash
#include fogandlight.fsh

float saturate(float value)
{
    return clamp(value, 0.0, 1.0);
}

float inverseSmoothstep(
    float edge0,
    float edge1,
    float value
)
{
    return 1.0 - smoothstep(edge0, edge1, value);
}

mat2 rotate2d(float angle)
{
    float s = sin(angle);
    float c = cos(angle);

    return mat2(
        c, -s,
        s,  c
    );
}

float hash21(vec2 p)
{
    p = fract(
        p * vec2(123.34, 456.21)
    );

    p += dot(
        p,
        p + 45.32
    );

    return fract(p.x * p.y);
}

float fbm(vec2 p)
{
    float value = 0.0;
    float amplitude = 0.52;

    for (int octave = 0; octave < 5; octave++)
    {
        value +=
            cnoise2(p)
            * amplitude;

        p =
            p * 2.03
            + vec2(17.2, 9.4);

        amplitude *= 0.50;
    }

    return value * 0.5 + 0.5;
}


float portalSurfaceHeight(vec2 p, float time)
{
    float r = length(p);

    /*
        Broad outward-traveling waves. The slower radial frequency creates
        larger rings that visibly move from the center toward the outer rim.
        The decay is intentionally gentle so the waves survive farther out.
    */
    float centerRipple =
        sin(
            r * 18.0
            - time * 2.2
        )
        * exp(-r * 0.25);

    float centerRippleFine =
        sin(
            r * 34.0
            - time * 3.4
        )
        * exp(-r * 0.95);

    vec2 sourceA =
        vec2(
            0.24 * sin(time * 0.31),
            0.20 * cos(time * 0.27)
        );

    vec2 sourceB =
        vec2(
            -0.28 * cos(time * 0.23),
            0.18 * sin(time * 0.35)
        );

    float rippleA =
        sin(
            length(p - sourceA) * 42.0
            - time * 3.4
        )
        * exp(
            -length(p - sourceA) * 2.1
        );

    float rippleB =
        sin(
            length(p - sourceB) * 37.0
            - time * 3.8
        )
        * exp(
            -length(p - sourceB) * 2.0
        );

    float flowingNoise =
        fbm(
            p * 4.5
            + vec2(
                time * 0.12,
                -time * 0.10
            )
        )
        * 2.0
        - 1.0;

    return
        centerRipple * 1.10
        + centerRippleFine * 0.32
        + rippleA * 0.24
        + rippleB * 0.22
        + flowingNoise * 0.18;
}

void main()
{
    vec2 screenUv =
        gl_FragCoord.xy
        * invFrameSize;

    float sceneDepth =
        linearDepth(
            texture(
                depthTex,
                screenUv
            ).r
        );

    float portalDepth =
        linearDepth(gl_FragCoord.z);

    float depthDifference =
        max(
            0.0,
            portalDepth - sceneDepth
        )
        * 10000.0;

    if (depthDifference > 2.0)
    {
        discard;
    }

    float time =
        u_time;

    vec2 centeredUv =
        (uv - 0.5)
        * 2.0;

    float radial =
        length(centeredUv);

    float angle =
        atan(
            centeredUv.y,
            centeredUv.x
        );

    /*
        Completely remove the square billboard before its edges become
        visible. The portal's visible silhouette always remains circular.
    */
    float circularBounds =
        inverseSmoothstep(
            0.925,
            1.00,
            radial
        );

    if (circularBounds <= 0.001)
    {
        discard;
    }

    /*
        Slightly irregular boundary. This gives the portal an arcane edge
        without turning it into a smooth soap bubble.
    */
    float edgeNoise =
        fbm(
            vec2(
                angle * 2.7,
                time * 0.11
            )
        );

    float fineEdgeNoise =
        fbm(
            vec2(
                angle * 7.5 - time * 0.15,
                13.7
            )
        );

    float irregularRadius =
        0.885
        + (edgeNoise - 0.5) * 0.065
        + (fineEdgeNoise - 0.5) * 0.022;

    float portalMask =
        inverseSmoothstep(
            irregularRadius - 0.035,
            irregularRadius + 0.020,
            radial
        );

    /*
        The interior coordinate twists increasingly toward the center.
        Two opposite rotations give the surface a deep vortex motion.
    */
    float centerPull =
        inverseSmoothstep(
            0.15,
            0.88,
            radial
        );

    vec2 swirlUvA =
        rotate2d(
            time * 0.24
            + centerPull * 2.4
        )
        * centeredUv;

    vec2 swirlUvB =
        rotate2d(
            -time * 0.16
            - centerPull * 1.8
        )
        * centeredUv;

    float spiralA =
        sin(
            angle * 6.0
            - radial * 18.0
            + time * 2.0
            + fbm(swirlUvA * 2.4) * 3.2
        )
        * 0.5
        + 0.5;

    float spiralB =
        sin(
            angle * -9.0
            - radial * 24.0
            - time * 1.35
            + fbm(swirlUvB * 3.0) * 4.0
        )
        * 0.5
        + 0.5;

    spiralA =
        smoothstep(
            0.48,
            0.83,
            spiralA
        );

    spiralB =
        smoothstep(
            0.56,
            0.88,
            spiralB
        );

    float deepNoise =
        fbm(
            swirlUvA * 3.4
            + vec2(
                time * 0.10,
                -time * 0.13
            )
        );

    float secondaryNoise =
        fbm(
            swirlUvB * 6.2
            + vec2(
                -time * 0.08,
                time * 0.14
            )
        );

    /*
        Fake three-dimensional liquid membrane.

        The portal is still a flat quad, but this height field creates
        expanding ripples, moving wave sources and slow flowing turbulence.
        Neighboring height samples form a fake surface normal used for
        refraction, highlights and shadowing.
    */
    float surfaceHeight =
        portalSurfaceHeight(
            centeredUv,
            time
        );

    float normalSampleDistance =
        0.012;

    float surfaceHeightX =
        portalSurfaceHeight(
            centeredUv
            + vec2(
                normalSampleDistance,
                0.0
            ),
            time
        );

    float surfaceHeightY =
        portalSurfaceHeight(
            centeredUv
            + vec2(
                0.0,
                normalSampleDistance
            ),
            time
        );

    vec3 surfaceNormal =
        normalize(
            vec3(
                (surfaceHeight - surfaceHeightX) * 9.0,
                (surfaceHeight - surfaceHeightY) * 9.0,
                normalSampleDistance * 1.5
            )
        );

    vec3 portalLightDirection =
        normalize(
            vec3(
                -0.35,
                0.45,
                0.82
            )
        );

    float surfaceLighting =
        dot(
            surfaceNormal,
            portalLightDirection
        )
        * 0.5
        + 0.5;

    float surfaceHighlight =
        pow(
            saturate(
                dot(
                    surfaceNormal,
                    normalize(
                        vec3(
                            -0.20,
                            0.30,
                            1.0
                        )
                    )
                )
            ),
            9.0
        );

    float surfaceShadow =
        saturate(
            0.68
            + surfaceLighting * 0.52
        );

    float rippleCrest =
        smoothstep(
            0.28,
            0.78,
            surfaceHeight
        );

    float rippleTrough =
        smoothstep(
            0.22,
            0.72,
            -surfaceHeight
        );

    /*
        Two slower parallax layers moving at different rates make the
        interior appear to continue behind the liquid membrane.
    */
    float depthLayerA =
        fbm(
            swirlUvA * 2.1
            + surfaceNormal.xy * 0.30
            + vec2(
                time * 0.055,
                -time * 0.070
            )
        );

    float depthLayerB =
        fbm(
            swirlUvB * 3.2
            - surfaceNormal.xy * 0.22
            + vec2(
                -time * 0.038,
                time * 0.046
            )
        );

    float parallaxDepth =
        depthLayerA * 0.62
        + depthLayerB * 0.38;

    /*
        Thin arcane veins moving across the portal surface.
    */
    float veinNoise =
        fbm(
            swirlUvB * 8.5
            + vec2(
                time * 0.20,
                -time * 0.09
            )
        );

    float veins =
        1.0
        - abs(
            veinNoise * 2.0
            - 1.0
        );

    veins =
        smoothstep(
            0.91,
            0.985,
            veins
        );

    veins *=
        smoothstep(
            0.20,
            0.72,
            radial
        );

    /*
        Sparse drifting stars/soul fragments inside the portal.
    */
    vec2 starGridUv =
        swirlUvA * 10.0;

    vec2 starCell =
        floor(starGridUv);

    vec2 starLocal =
        fract(starGridUv)
        - 0.5;

    float starRandom =
        hash21(
            starCell
            + floor(time * 0.35)
        );

    float stars =
        inverseSmoothstep(
            0.020,
            0.085,
            length(starLocal)
        );

    stars *=
        step(
            0.935,
            starRandom
        );

    stars *=
        inverseSmoothstep(
            0.18,
            0.88,
            radial
        );

    stars *=
        0.55
        + 0.45
        * sin(
            time * 3.0
            + starRandom * TAU
        );

    /*
        Central black void. It is intentionally motionless while the
        surrounding portal surface spirals around it.
    */
    float voidRadius =
        0.60
        + sin(time * 0.65) * 0.008;

    float voidSphere =
        inverseSmoothstep(
            voidRadius - 0.018,
            voidRadius + 0.018,
            radial
        );

    float voidRim =
        smoothstep(
            voidRadius - 0.045,
            voidRadius - 0.006,
            radial
        )
        * inverseSmoothstep(
            voidRadius + 0.002,
            voidRadius + 0.055,
            radial
        );

    /*
        Three-dimensional rippling outer ring.

        The ring center is displaced inward and outward by several traveling
        waves. A bright crest, dark trough and secondary inner band make the
        edge read like raised liquid energy instead of a flat painted circle.
    */
    float ringBaseCenter =
        irregularRadius - 0.060;

    float ringWaveA =
        sin(
            angle * 9.0
            - time * 1.05
        );

    float ringWaveB =
        sin(
            angle * 15.0
            + time * 0.72
            + deepNoise * 2.6
        );

    float ringWaveC =
        sin(
            angle * 5.0
            - time * 0.38
            + secondaryNoise * 3.0
        );

    /*
        Stronger silhouette displacement. This is intentionally large enough
        to be visible at normal gameplay distance instead of only changing the
        ring's shading.
    */
    float ringHeartbeat =
        sin(time * 0.72)
        * 0.010;

    float ringRipple =
        ringWaveA * 0.032
        + ringWaveB * 0.019
        + ringWaveC * 0.014
        + ringHeartbeat;

    float ringCenter =
        ringBaseCenter
        + ringRipple;

    float ringDistance =
        radial - ringCenter;

    float outerRing =
        inverseSmoothstep(
            0.018,
            0.070,
            abs(ringDistance)
        );

    /*
        Approximate a rounded cross-section across the ring. The outer-facing
        half catches light while the inner-facing half falls into shadow.
    */
    float ringCrest =
        inverseSmoothstep(
            0.000,
            0.036,
            abs(ringDistance - 0.015)
        );

    float ringInnerShadow =
        inverseSmoothstep(
            0.000,
            0.044,
            abs(ringDistance + 0.026)
        );

    float ringOuterGlow =
        inverseSmoothstep(
            0.018,
            0.125,
            abs(ringDistance - 0.038)
        );

    /*
        A second displaced ridge follows the main wave with a slight phase
        offset. This gives the ring a layered, liquid-energy thickness.
    */
    float secondaryRingRidge =
        inverseSmoothstep(
            0.000,
            0.026,
            abs(
                radial
                - (
                    ringBaseCenter
                    - 0.050
                    + ringWaveA * 0.020
                    - ringWaveB * 0.012
                )
            )
        );

    float ringBreakup =
        fbm(
            vec2(
                angle * 8.0 + time * 0.12,
                radial * 7.0 - time * 0.06
            )
        );

    outerRing *=
        smoothstep(
            0.27,
            0.67,
            ringBreakup
        );

    ringCrest *=
        smoothstep(
            0.24,
            0.62,
            ringBreakup
        );

    ringOuterGlow *=
        smoothstep(
            0.18,
            0.72,
            ringBreakup
        );

    float rotatingArcs =
        sin(
            angle * 13.0
            - time * 0.62
            + deepNoise * 4.0
        )
        * 0.5
        + 0.5;

    rotatingArcs =
        smoothstep(
            0.72,
            0.96,
            rotatingArcs
        );

    rotatingArcs *=
        inverseSmoothstep(
            0.030,
            0.115,
            abs(ringDistance + 0.012)
        );

    /*
        Gravitational lensing: bend the framebuffer toward the center.
        The center remains translucent, showing a darkened and strongly
        distorted view of the world behind the portal.
    */
    vec2 radialDirection =
        centeredUv
        / max(radial, 0.0001);

    float centerLens =
        inverseSmoothstep(
            0.0,
            voidRadius + 0.10,
            radial
        );

    float outerLens =
        inverseSmoothstep(
            voidRadius + 0.08,
            0.82,
            radial
        );

    float lensBand =
        max(
            centerLens,
            outerLens * 0.55
        );

    float lensStrength =
        lensBand
        * (
            0.012
            + deepNoise * 0.010
        );

    vec2 distortedScreenUv =
        screenUv
        - radialDirection
        * lensStrength;

    /*
        Refraction follows the fake surface normal. Ripple crests and troughs
        bend the world behind the portal in opposite directions.
    */
    float refractionStrength =
        (
            0.0285
            + centerLens * 0.070
            + rippleCrest * 0.045
        )
        * portalMask;

    distortedScreenUv +=
        surfaceNormal.xy
        * refractionStrength;

    distortedScreenUv +=
        radialDirection
        * surfaceHeight
        * 0.0075
        * portalMask;

    distortedScreenUv +=
        vec2(
            cnoise2(swirlUvA * 4.0 + time * 0.25),
            cnoise2(swirlUvB * 4.0 - time * 0.20)
        )
        * 0.0018
        * portalMask;

    distortedScreenUv =
        clamp(
            distortedScreenUv,
            vec2(0.001),
            vec2(0.999)
        );

    vec4 sceneColor =
        texture(
            primaryFb,
            distortedScreenUv
        );

    /*
        Portal palette:
        deep blue-purple body, renderer-controlled membrane, rings and veins,
        with white highlights retained for contrast.
    */
    vec3 voidBlack =
        vec3(
            0.0,
            0.0,
            0.003
        );

    vec3 deepIndigo =
        vec3(
            0.015,
            0.008,
            0.075
        );

    vec3 deepPurple =
        vec3(
            0.12,
            0.015,
            0.28
        );

    vec3 arcaneViolet =
        vec3(
            0.48,
            0.07,
            0.90
        );

    vec3 arcaneBlue =
        vec3(
            0.08,
            0.32,
            0.95
        );

    vec3 cyanEnergy =
        vec3(
            0.10,
            0.92,
            1.00
        );

    vec3 whiteEnergy =
        vec3(
            0.82,
            0.94,
            1.00
        );

    vec3 membraneBlue =
        vec3(
            0.20,
            0.66,
            1.00
        );

    vec3 membraneLightBlue =
        vec3(
            0.56,
            0.88,
            1.00
        );

    // The portal center tint now follows the renderer-controlled membrane color.

    // Uniforms default to zero when the renderer does not set them.
    // These fallbacks preserve the original shader appearance.
    vec3 activeMembraneColor =
        length(portalMembraneColor) > 0.001
        ? portalMembraneColor
        : membraneBlue;

    vec3 activeRingPrimaryColor =
        length(portalRingPrimaryColor) > 0.001
        ? portalRingPrimaryColor
        : arcaneViolet;

    vec3 activeRingSecondaryColor =
        length(portalRingSecondaryColor) > 0.001
        ? portalRingSecondaryColor
        : cyanEnergy;

    vec3 activeVeinColor =
        length(portalVeinColor) > 0.001
        ? portalVeinColor
        : cyanEnergy;

    vec3 activeMembraneLightColor =
        mix(
            activeMembraneColor,
            vec3(1.0),
            0.46
        );

    vec3 interiorColor =
        mix(
            deepIndigo,
            deepPurple,
            deepNoise * 0.64
            + parallaxDepth * 0.36
        );

    /*
        The fake normal produces broad shading across the membrane, while
        crests catch cyan light and troughs deepen into indigo.
    */
    interiorColor *=
        surfaceShadow;

    interiorColor +=
        activeRingSecondaryColor
        * rippleCrest
        * 0.16;

    interiorColor -=
        deepIndigo
        * rippleTrough
        * 0.10;

    interiorColor +=
        whiteEnergy
        * surfaceHighlight
        * 0.22;

    interiorColor +=
        activeRingPrimaryColor
        * spiralA
        * 0.42;

    interiorColor +=
        activeRingSecondaryColor
        * spiralB
        * 0.32;

    interiorColor +=
        activeVeinColor
        * veins
        * 0.78;

    interiorColor +=
        whiteEnergy
        * stars
        * 1.35;

    /*
        Give the membrane its own clear light-blue identity. The center remains
        darker and translucent while the outer ring stays purple.
    */
    float membraneRegion =
        smoothstep(
            voidRadius - 0.015,
            voidRadius + 0.100,
            radial
        )
        * inverseSmoothstep(
            ringCenter - 0.135,
            ringCenter + 0.020,
            radial
        );

    /*
        Additional radial crest/trough lighting makes the outward motion
        readable even when the framebuffer behind the portal is dark.
    */
    float outwardWave =
        sin(
            radial * 18.0
            - time * 2.2
        );

    float outwardWaveCrest =
        smoothstep(
            0.42,
            0.95,
            outwardWave
        );

    float outwardWaveTrough =
        smoothstep(
            0.42,
            0.95,
            -outwardWave
        );

    float membraneWaveLight =
        saturate(
            0.28
            + surfaceLighting * 0.52
            + rippleCrest * 0.62
            + outwardWaveCrest * 0.52
            - rippleTrough * 0.20
            - outwardWaveTrough * 0.18
        );

    vec3 blueMembraneColor =
        mix(
            activeMembraneColor * 0.42,
            activeMembraneLightColor * 1.10,
            membraneWaveLight
        );

    blueMembraneColor +=
        activeVeinColor
        * veins
        * 0.34;

    blueMembraneColor +=
        activeMembraneLightColor
        * outwardWaveCrest
        * membraneRegion
        * 0.34;

    blueMembraneColor -=
        deepIndigo
        * outwardWaveTrough
        * membraneRegion
        * 0.16;

    interiorColor =
        mix(
            interiorColor,
            blueMembraneColor,
            membraneRegion * 0.72
        );

    /*
        Preserve a little distorted world imagery in the outer interior,
        but darken it strongly so the portal feels like depth rather than
        a transparent colored window.
    */
    float sceneVisibility =
        smoothstep(
            voidRadius + 0.08,
            0.72,
            radial
        )
        * 0.20;

    vec3 finalRgb =
        mix(
            interiorColor,
            sceneColor.rgb * 0.34 + interiorColor,
            sceneVisibility
        );

    /*
        Ring lighting. The crest is nearly white, the outer shoulder glows
        cyan, and the inner trough darkens to create apparent thickness.
    */
    finalRgb +=
        activeRingPrimaryColor
        * outerRing
        * 1.08;

    finalRgb +=
        activeRingSecondaryColor
        * ringOuterGlow
        * 0.72;

    finalRgb +=
        whiteEnergy
        * ringCrest
        * 1.18;

    finalRgb +=
        activeRingSecondaryColor
        * secondaryRingRidge
        * 0.62;

    finalRgb -=
        deepIndigo
        * ringInnerShadow
        * 0.58;

    finalRgb +=
        activeRingSecondaryColor
        * rotatingArcs
        * 0.72;

    finalRgb +=
        whiteEnergy
        * ringCrest
        * rotatingArcs
        * 0.58;

    /*
        Moving caustic-like highlights make the surface read as curved rather
        than as a flat animated texture.
    */
    finalRgb +=
        activeRingSecondaryColor
        * rippleCrest
        * surfaceHighlight
        * 0.38
        * portalMask;

    finalRgb +=
        activeRingPrimaryColor
        * voidRim
        * 0.55;

    finalRgb +=
        activeVeinColor
        * voidRim
        * veins
        * 0.45;

    /*
        Transparent black-hole center.

        Instead of filling the center with solid black, show the distorted
        framebuffer through it. Darkening and a faint blue-violet tint make
        the distortion readable while preserving visibility through the portal.
    */
    vec3 distortedVoidColor =
        sceneColor.rgb
        * vec3(
            0.46,
            0.46,
            0.46
        );

    /*
        The transparent center now carries a definite cool-blue tint instead
        of reading as black-purple. Keep it subtle enough that the distorted
        world remains visible through the portal.
    */
    distortedVoidColor +=
        activeMembraneColor
        * (
            0.18
            + centerLens * 0.20
        );

    distortedVoidColor +=
        activeMembraneLightColor
        * voidRim
        * 0.24;

    finalRgb =
        mix(
            finalRgb,
            distortedVoidColor,
            voidSphere
        );

    float interiorAlpha =
        portalMask
        * (
            0.70
            + deepNoise * 0.20
            + spiralA * 0.12
            + spiralB * 0.10
        );

    float rimAlpha =
        saturate(
            outerRing * 0.82
            + ringCrest * 0.78
            + ringOuterGlow * 0.48
            + secondaryRingRidge * 0.52
            + rotatingArcs * 0.62
            + voidRim * 0.48
        );

    float alpha =
        max(
            interiorAlpha,
            rimAlpha
        );

    /*
        Keep the black-hole center translucent. The framebuffer distortion
        provides the visual content while alpha allows the scene behind the
        portal to remain visible.
    */
    float transparentVoidAlpha =
        0.42
        + voidRim * 0.20;

    alpha =
        mix(
            alpha,
            transparentVoidAlpha,
            voidSphere
        );

    alpha *=
        circularBounds;

    alpha =
        clamp(
            alpha - depthDifference,
            0.0,
            1.0
        );

    alpha -=
        clamp(
            (
                dist
                * (
                    1.0
                    + fogAmount * 0.5
                )
                - 50.0
            )
            / 40.0,
            0.0,
            0.72
            + fogAmount * 0.28
        );

    if (alpha < 0.015)
    {
        discard;
    }

    outColor =
        applyFog(
            vec4(
                finalRgb,
                alpha
            ),
            fogAmount
        );
}
