#version 330 core

uniform vec3 primaryColor;
uniform vec3 secondaryColor;
uniform float primaryAlpha;
uniform float secondaryAlpha;
uniform float u_time;
uniform float effectProgress;

in vec2 fragUv;
out vec4 outColor;

float hash21(vec2 p)
{
    p = fract(p * vec2(127.1, 311.7));
    p += dot(p, p + 34.5);
    return fract(p.x * p.y);
}

float noise21(vec2 p)
{
    vec2 i = floor(p);
    vec2 f = fract(p);

    f = f * f * (3.0 - 2.0 * f);

    float a = hash21(i);
    float b = hash21(i + vec2(1.0, 0.0));
    float c = hash21(i + vec2(0.0, 1.0));
    float d = hash21(i + vec2(1.0, 1.0));

    return mix(mix(a, b, f.x), mix(c, d, f.x), f.y);
}

void main()
{
    vec2 p = fragUv * 2.0 - 1.0;

    float progress = clamp(effectProgress, 0.0, 1.0);

    /*
        Fast initial burst, then ease toward maximum radius.
    */
    float expansion = 1.0 - (1.0 - progress) * (1.0 - progress);

    float radius = length(p);
    float angle = atan(p.y, p.x);

    /*
        Full 360 degree taunt ring.
    */
    float shockRadius = mix(
        0.10,
        0.78,
        expansion
    );

    /*
        Slight animated irregularity so the ring feels energetic.
    */
    float ringNoise = noise21(vec2(
        angle * 10.0 - u_time * 1.1,
        radius * 18.0 + u_time * 0.25
    ));

    float noisyRadius = radius + (ringNoise - 0.5) * 0.012;

    /*
        Main bright ring.
    */
    float ringThickness = mix(
        0.045,
        0.020,
        expansion
    );

    float ringDistance = abs(
        noisyRadius - shockRadius
    );

    float ringBody = 1.0 - smoothstep(
        ringThickness * 0.70,
        ringThickness,
        ringDistance
    );

    float ringCore = 1.0 - smoothstep(
        ringThickness * 0.08,
        ringThickness * 0.28,
        ringDistance
    );

    /*
        Secondary softer ring just behind the main shockwave.
    */
    float secondaryRadius = shockRadius - 0.095;

    float secondaryRing = 1.0 - smoothstep(
        0.016,
        0.036,
        abs(noisyRadius - secondaryRadius)
    );

    /*
    16 triangular spikes around the ring.
*/
float spikeCount = 16.0;

float spikeCell = fract(
    (angle / 6.2831853 + 0.5) * spikeCount
);

float spikeCenterDistance = abs(
    spikeCell - 0.5
) * 2.0;

/*
    0 at the shock ring.
    1 at the outer tip.
*/
float spikeLength = 0.20;

float spikeProgress = clamp(
    (noisyRadius - shockRadius) / spikeLength,
    0.0,
    1.0
);

/*
    Wide base -> narrow pointed tip.
*/
float spikeHalfWidth = mix(
    0.72,
    0.0,
    spikeProgress
);

float spikeAngularMask = 1.0 - smoothstep(
    spikeHalfWidth - 0.08,
    spikeHalfWidth,
    spikeCenterDistance
);

/*
    Only allow the spike between the ring and its outer tip.
*/
float spikeRadialMask =
    smoothstep(
        shockRadius - 0.010,
        shockRadius + 0.008,
        noisyRadius
    )
    *
    (
        1.0 - smoothstep(
            shockRadius + spikeLength - 0.015,
            shockRadius + spikeLength,
            noisyRadius
        )
    );

float spikes = spikeAngularMask * spikeRadialMask;

    /*
        Make spikes slightly uneven so they do not look perfectly stamped.
    */
    float spikeNoise = noise21(vec2(
        angle * 22.0 + u_time * 1.8,
        radius * 34.0 - u_time * 2.8
    ));

    spikes *= mix(
        0.65,
        1.0,
        spikeNoise
    );

    /*
        Small energetic fragments riding around the ring.
    */
    float fragmentNoise = noise21(vec2(
        angle * 34.0 - u_time * 2.4,
        radius * 52.0 + u_time * 3.0
    ));

    float fragments = smoothstep(
        0.84,
        0.96,
        fragmentNoise
    );

    fragments *= 1.0 - smoothstep(
        0.050,
        0.115,
        abs(noisyRadius - shockRadius)
    );

    /*
        Very soft haze around the shock front.
    */
    float haze = 1.0 - smoothstep(
        ringThickness,
        ringThickness + 0.060,
        ringDistance
    );

    haze = max(
        0.0,
        haze - ringBody * 0.90
    );

    /*
        Overall timing.
    */
    float fadeIn = smoothstep(
        0.0,
        0.035,
        progress
    );

    float fadeOut = 1.0 - smoothstep(
        0.58,
        1.0,
        progress
    );

    float fade = fadeIn * fadeOut;

    ringBody *= fade;
    ringCore *= fade;
    secondaryRing *= fade;
    spikes *= fade;
    fragments *= fade;
    haze *= fade;

    /*
        STATIC TAUNT COLORS.

        White core + yellow/gold spikes and outer energy.
        primaryColor / secondaryColor remain declared for renderer compatibility.
    */
    vec3 ringColor = vec3(
        1.00,
        0.94,
        0.62
    );

    vec3 coreColor = vec3(
        1.00,
        1.00,
        1.00
    );

    vec3 spikeColor = vec3(
        1.00,
        0.78,
        0.16
    );

    vec3 secondaryRingColor = vec3(
        0.95,
        0.82,
        0.38
    );

    vec3 fragmentColor = vec3(
        1.00,
        0.92,
        0.56
    );

    vec3 hazeColor = vec3(
        0.90,
        0.76,
        0.34
    );

    /*
        Keep RGB bright while alpha fades so the outside remains transparent
        instead of creating a dark border.
    */
    float alpha = 0.0;

    alpha += ringBody * 0.72;
    alpha += ringCore * 1.00;
    alpha += secondaryRing * 0.30;
    alpha += spikes * 0.78;
    alpha += fragments * 0.28;
    alpha += haze * 0.08;

    alpha = clamp(alpha, 0.0, 1.0);

    if (alpha <= 0.01)
    {
        discard;
    }

    vec3 color = secondaryRingColor;

    color = mix(color, hazeColor, haze * 0.15);
    color = mix(color, secondaryRingColor, secondaryRing * 0.30);
    color = mix(color, ringColor, ringBody * 0.72);
    color = mix(color, spikeColor, spikes * 0.85);
    color = mix(color, fragmentColor, fragments * 0.35);
    color = mix(color, coreColor, ringCore * 0.95);

    outColor = vec4(
        color,
        alpha
    );
}
