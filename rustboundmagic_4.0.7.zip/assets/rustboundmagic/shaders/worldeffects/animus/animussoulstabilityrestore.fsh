#version 330 core

/*
 * Rustbound Magic - Animus Restoration / Soul Stabilization
 *
 * Visual language:
 *   - broken gold/cyan rings
 *   - inward-moving soul wisps
 *   - instability violet at the beginning
 *   - bright white/gold repaired core
 *   - final gold/cyan pulse
 *
 * Optional:
 *   stabilityDamage = normalized damage before repair:
 *       0.0 = barely damaged
 *       1.0 = heavily damaged
 */

uniform vec3 primaryColor;
uniform vec3 secondaryColor;

uniform float primaryAlpha;
uniform float secondaryAlpha;

uniform float u_time;
uniform float effectProgress;
uniform float stabilityDamage;

in vec2 fragUv;

out vec4 outColor;


//--------//--------//--------//--------//
//               Helpers               //
//--------//--------//--------//--------//

float hash21(vec2 p)
{
    p = fract(p * vec2(123.34, 456.21));
    p += dot(p, p + 45.32);

    return fract(p.x * p.y);
}


float valueNoise(vec2 p)
{
    vec2 i = floor(p);
    vec2 f = fract(p);

    f = f * f * (3.0 - 2.0 * f);

    float a = hash21(i);
    float b = hash21(i + vec2(1.0, 0.0));
    float c = hash21(i + vec2(0.0, 1.0));
    float d = hash21(i + vec2(1.0, 1.0));

    return mix(
        mix(a, b, f.x),
        mix(c, d, f.x),
        f.y
    );
}


float fbm(vec2 p)
{
    float value = 0.0;
    float amplitude = 0.5;

    for (int i = 0; i < 5; i++)
    {
        value += valueNoise(p) * amplitude;

        p = p * 2.03 + vec2(13.71, 8.41);
        amplitude *= 0.5;
    }

    return value;
}


float pulse(float value, float startValue, float peakValue, float endValue)
{
    return
        smoothstep(startValue, peakValue, value)
        *
        (
            1.0
            -
            smoothstep(peakValue, endValue, value)
        );
}


vec2 rotateUv(vec2 p, float angle)
{
    float c = cos(angle);
    float s = sin(angle);

    return vec2(
        c * p.x - s * p.y,
        s * p.x + c * p.y
    );
}


//--------//--------//--------//--------//
//            Broken Ring Mask         //
//--------//--------//--------//--------//

float brokenRing(
    vec2 uv,
    float radius,
    float thickness,
    float rotation,
    float gapAmount,
    float segmentCount,
    float seed)
{
    vec2 ruv =
        rotateUv(
            uv,
            rotation
        );

    float dist =
        length(ruv);

    float angle =
        atan(
            ruv.y,
            ruv.x
        );

    float ring =
        1.0
        -
        smoothstep(
            thickness * 0.35,
            thickness,
            abs(dist - radius)
        );

    float segment =
        sin(
            angle * segmentCount
            +
            seed
        );

    float broken =
        smoothstep(
            -0.15 + gapAmount,
            0.25 + gapAmount,
            segment
        );

    return ring * broken;
}


//--------//--------//--------//--------//
//           Inward Soul Motes         //
//--------//--------//--------//--------//

float inwardMoteField(
    vec2 uv,
    float progress,
    float scale,
    float threshold,
    float seed)
{
    float inwardProgress =
        smoothstep(
            0.08,
            0.62,
            progress
        );

    /*
     * We sample the star/mote field at an outward-scaled UV,
     * making the visible motes appear to travel inward as progress rises.
     */
    float zoom =
        mix(
            0.60,
            2.30,
            inwardProgress
        );

    vec2 sampleUv =
        rotateUv(
            uv * zoom,
            -u_time * 0.08
        );

    vec2 gridUv =
        sampleUv * scale;

    vec2 cell =
        floor(gridUv);

    vec2 localUv =
        fract(gridUv) - 0.5;

    float randomValue =
        hash21(
            cell + vec2(seed)
        );

    float enabled =
        step(
            threshold,
            randomValue
        );

    vec2 offset =
        vec2(
            hash21(cell + vec2(seed + 11.1, 2.8)),
            hash21(cell + vec2(5.6, seed + 31.7))
        )
        -
        0.5;

    localUv -=
        offset * 0.60;

    float mote =
        1.0
        -
        smoothstep(
            0.02,
            0.09,
            length(localUv)
        );

    float flicker =
        0.70
        +
        sin(
            u_time * 6.0
            +
            randomValue * 30.0
        )
        *
        0.30;

    return mote * enabled * flicker;
}


//--------//--------//--------//--------//
//               Main                  //
//--------//--------//--------//--------//

void main()
{
    vec2 uv =
        fragUv * 2.0 - 1.0;

    float radius =
        length(uv);

    if (radius > 1.20)
    {
        discard;
    }

    float progress =
        clamp(
            effectProgress,
            0.0,
            1.0
        );

    float damageAmount =
        clamp(
            stabilityDamage,
            0.0,
            1.0
        );


    //--------//--------//--------//--------//
    //             Base Flow              //
    //--------//--------//--------//--------//

    float angle =
        atan(
            uv.y,
            uv.x
        );

    float turbulence =
        fbm(
            rotateUv(
                uv,
                -u_time * 0.14
            )
            * 4.0
            +
            vec2(
                u_time * 0.08,
                -u_time * 0.05
            )
        );

    float fineNoise =
        fbm(
            uv * 10.0
            +
            vec2(
                -u_time * 0.16,
                u_time * 0.11
            )
        );


    //--------//--------//--------//--------//
    //         Initial Instability        //
    //--------//--------//--------//--------//

    float instabilityPhase =
        1.0
        -
        smoothstep(
            0.12,
            0.52,
            progress
        );

    float instability =
        smoothstep(
            0.40,
            0.78,
            turbulence
        );

    instability *=
        1.0
        -
        smoothstep(
            0.15,
            0.88,
            radius
        );

    instability *=
        instabilityPhase
        *
        mix(
            0.25,
            1.0,
            damageAmount
        );


    //--------//--------//--------//--------//
    //           Broken Soul Rings         //
    //--------//--------//--------//--------//

    float ringRepair =
        smoothstep(
            0.12,
            0.72,
            progress
        );

    float gapAmount =
        mix(
            0.48,
            -0.20,
            ringRepair
        );

    float ring1 =
        brokenRing(
            uv,
            0.30,
            0.035,
            u_time * 0.55,
            gapAmount,
            5.0,
            0.6
        );

    float ring2 =
        brokenRing(
            uv,
            0.47,
            0.030,
            -u_time * 0.38,
            gapAmount * 0.85,
            7.0,
            1.8
        );

    float ring3 =
        brokenRing(
            uv,
            0.64,
            0.026,
            u_time * 0.24,
            gapAmount * 0.70,
            9.0,
            3.1
        );

    float rings =
        ring1
        +
        ring2 * 0.90
        +
        ring3 * 0.75;

    /*
     * As restoration approaches completion,
     * ring visibility briefly strengthens.
     */
    float ringAlignment =
        pulse(
            progress,
            0.58,
            0.72,
            0.86
        );

    rings *=
        0.65
        +
        ringAlignment * 0.80;


    //--------//--------//--------//--------//
    //          Inward Mana Wisps          //
    //--------//--------//--------//--------//

    float inwardPhase =
        smoothstep(
            0.05,
            0.22,
            progress
        )
        *
        (
            1.0
            -
            smoothstep(
                0.68,
                0.82,
                progress
            )
        );

    float spiralAngle =
        angle
        +
        radius * 7.0
        +
        u_time * 0.55;

    float spiralNoise =
        fbm(
            vec2(
                spiralAngle * 1.8,
                radius * 7.5
                +
                u_time * 0.20
            )
        );

    float wisps =
        smoothstep(
            0.42,
            0.76,
            spiralNoise
        );

    wisps *=
        1.0
        -
        smoothstep(
            0.22,
            1.02,
            radius
        );

    wisps *=
        inwardPhase;


    //--------//--------//--------//--------//
    //           Inward Soul Motes         //
    //--------//--------//--------//--------//

    float motes =
        inwardMoteField(
            uv,
            progress,
            12.0,
            0.70,
            9.5
        );

    motes +=
        inwardMoteField(
            uv,
            progress,
            19.0,
            0.78,
            32.1
        )
        *
        0.70;

    float motePhase =
        smoothstep(
            0.04,
            0.18,
            progress
        )
        *
        (
            1.0
            -
            smoothstep(
                0.68,
                0.84,
                progress
            )
        );

    motes *=
        motePhase;

    motes *=
        1.0
        -
        smoothstep(
            0.88,
            1.12,
            radius
        );


    //--------//--------//--------//--------//
    //           Repaired Soul Core        //
    //--------//--------//--------//--------//

    float coreBirth =
        smoothstep(
            0.34,
            0.66,
            progress
        );

    float coreRadius =
        mix(
            0.035,
            0.13,
            coreBirth
        );

    float soulCore =
        1.0
        -
        smoothstep(
            coreRadius * 0.18,
            coreRadius,
            radius
        );

    float heartbeat =
        0.82
        +
        sin(
            u_time * 10.0
        )
        *
        0.18;

    soulCore *=
        coreBirth
        *
        heartbeat;


    //--------//--------//--------//--------//
    //            Completion Flash         //
    //--------//--------//--------//--------//

    float completionFlash =
        pulse(
            progress,
            0.66,
            0.74,
            0.84
        );

    float flashBody =
        1.0
        -
        smoothstep(
            0.02,
            0.45,
            radius
        );

    completionFlash *=
        flashBody;


    //--------//--------//--------//--------//
    //          Final Expanding Pulse      //
    //--------//--------//--------//--------//

    float pulsePhase =
        smoothstep(
            0.70,
            0.94,
            progress
        );

    float pulseRadius =
        mix(
            0.08,
            0.98,
            pulsePhase
        );

    float pulseDistortion =
        (turbulence - 0.5) * 0.045;

    float finalPulse =
        1.0
        -
        smoothstep(
            0.025,
            0.080,
            abs(
                radius
                +
                pulseDistortion
                -
                pulseRadius
            )
        );

    float finalPulseFade =
        1.0
        -
        smoothstep(
            0.88,
            1.0,
            progress
        );

    finalPulse *=
        smoothstep(
            0.68,
            0.75,
            progress
        )
        *
        finalPulseFade;


    //--------//--------//--------//--------//
    //              Colors                //
    //--------//--------//--------//--------//

    vec3 whiteColor =
        vec3(
            1.0,
            1.0,
            1.0
        );

    vec3 goldColor =
        vec3(
            1.00,
            0.70,
            0.15
        );

    vec3 paleGold =
        vec3(
            1.00,
            0.90,
            0.55
        );

    vec3 cyanColor =
        mix(
            primaryColor,
            vec3(0.20, 0.90, 1.00),
            0.60
        );

    vec3 paleCyan =
        mix(
            cyanColor,
            whiteColor,
            0.55
        );

    vec3 violetColor =
        mix(
            secondaryColor,
            vec3(0.50, 0.15, 0.80),
            0.65
        );


    //--------//--------//--------//--------//
    //         Color Composition           //
    //--------//--------//--------//--------//

    vec3 finalColor =
        vec3(0.0);

    /*
     * Instability being removed.
     */
    finalColor +=
        violetColor
        *
        instability
        *
        0.85;

    /*
     * Broken rings restoring into whole geometry.
     */
    finalColor +=
        goldColor
        *
        rings
        *
        1.10;

    finalColor +=
        paleCyan
        *
        rings
        *
        0.50;

    /*
     * Inward soul flow.
     */
    finalColor +=
        cyanColor
        *
        wisps
        *
        0.55;

    finalColor +=
        paleGold
        *
        wisps
        *
        0.38;

    /*
     * Soul motes.
     */
    finalColor +=
        paleGold
        *
        motes
        *
        1.55;

    finalColor +=
        paleCyan
        *
        motes
        *
        0.75;

    /*
     * Repaired Animus core.
     */
    finalColor +=
        paleGold
        *
        soulCore
        *
        2.20;

    finalColor +=
        whiteColor
        *
        soulCore
        *
        1.65;

    /*
     * Moment of completion.
     */
    finalColor +=
        whiteColor
        *
        completionFlash
        *
        2.40;

    finalColor +=
        goldColor
        *
        completionFlash
        *
        1.10;

    /*
     * Final outward pulse after the inward repair.
     */
    finalColor +=
        paleGold
        *
        finalPulse
        *
        1.35;

    finalColor +=
        cyanColor
        *
        finalPulse
        *
        0.80;


    //--------//--------//--------//--------//
    //                Alpha                //
    //--------//--------//--------//--------//

    float alpha =
        instability * 0.24
        +
        rings * 0.78
        +
        wisps * 0.34
        +
        motes * 0.90
        +
        soulCore
        +
        completionFlash
        +
        finalPulse * 0.82;

    /*
     * Fade everything rapidly at the very end.
     */
    float finalFade =
        1.0
        -
        smoothstep(
            0.90,
            1.0,
            progress
        );

    alpha *=
        finalFade;

    /*
     * Soft outer boundary.
     */
    alpha *=
        1.0
        -
        smoothstep(
            1.00,
            1.18,
            radius
        );

    float packetAlpha =
        mix(
            primaryAlpha,
            secondaryAlpha,
            turbulence
        );

    alpha *=
        packetAlpha;

    if (alpha <= 0.008)
    {
        discard;
    }

    outColor =
        vec4(
            finalColor,
            clamp(
                alpha,
                0.0,
                1.0
            )
        );
}
