#version 330 core

uniform mat4 projectionMatrix;
uniform mat4 modelViewMatrix;

in vec3 vertexPosition;
in vec2 uv;

out vec2 fragUv;

void main()
{
    fragUv = uv;
    gl_Position = projectionMatrix * modelViewMatrix * vec4(vertexPosition, 1.0);
}