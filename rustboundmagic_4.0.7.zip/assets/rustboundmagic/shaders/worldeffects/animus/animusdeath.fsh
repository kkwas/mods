#version 330 core

uniform vec3 primaryColor;
uniform vec3 secondaryColor;
uniform float primaryAlpha;
uniform float secondaryAlpha;
uniform float u_time;
uniform float effectProgress;
uniform float fractured;

in vec2 fragUv;
out vec4 outColor;

float hash21(vec2 p)
{
    p = fract(p * vec2(123.34, 456.21));
    p += dot(p, p + 45.32);
    return fract(p.x * p.y);
}

float valueNoise(vec2 p)
{
    vec2 i = floor(p);
    vec2 f = fract(p);
    f = f * f * (3.0 - 2.0 * f);

    float a = hash21(i);
    float b = hash21(i + vec2(1.0, 0.0));
    float c = hash21(i + vec2(0.0, 1.0));
    float d = hash21(i + vec2(1.0, 1.0));

    return mix(mix(a, b, f.x), mix(c, d, f.x), f.y);
}

float fbm(vec2 p)
{
    float value = 0.0;
    float amplitude = 0.5;

    for (int i = 0; i < 5; i++)
    {
        value += valueNoise(p) * amplitude;
        p = p * 2.03 + vec2(13.71, 8.41);
        amplitude *= 0.5;
    }

    return value;
}

float pulse(float value, float startValue, float peakValue, float endValue)
{
    return smoothstep(startValue, peakValue, value)
        * (1.0 - smoothstep(peakValue, endValue, value));
}

vec2 rotateUv(vec2 p, float angle)
{
    float c = cos(angle);
    float s = sin(angle);

    return vec2(
        c * p.x - s * p.y,
        s * p.x + c * p.y
    );
}

float fractureRay(float angle, float radius, float rayAngle, float rayLength, float rayWidth)
{
    float angleDifference = abs(atan(sin(angle - rayAngle), cos(angle - rayAngle)));

    float angularMask = 1.0 - smoothstep(rayWidth, rayWidth * 2.5, angleDifference);
    float lengthMask = 1.0 - smoothstep(rayLength * 0.65, rayLength, radius);
    float innerMask = smoothstep(0.03, 0.11, radius);

    return angularMask * lengthMask * innerMask;
}

float soulFractures(vec2 uv, float progress)
{
    float radius = length(uv);
    float angle = atan(uv.y, uv.x);
    float fracturePhase = pulse(progress, 0.05, 0.15, 0.36);

    float angularNoise = (fbm(vec2(angle * 3.0, radius * 8.0 - u_time * 0.8)) - 0.5) * 0.10;
    float finalAngle = angle + angularNoise;

    float rays = 0.0;
    rays = max(rays, fractureRay(finalAngle, radius, 0.20, 0.88, 0.022));
    rays = max(rays, fractureRay(finalAngle, radius, 1.18, 0.68, 0.018));
    rays = max(rays, fractureRay(finalAngle, radius, 2.05, 0.92, 0.020));
    rays = max(rays, fractureRay(finalAngle, radius, 2.92, 0.62, 0.016));
    rays = max(rays, fractureRay(finalAngle, radius, 3.72, 0.84, 0.021));
    rays = max(rays, fractureRay(finalAngle, radius, 4.62, 0.72, 0.017));
    rays = max(rays, fractureRay(finalAngle, radius, 5.42, 0.96, 0.020));

    float brokenEdge = 0.65 + fbm(uv * 12.0 + vec2(u_time * 0.4, -u_time * 0.3)) * 0.55;
    return rays * brokenEdge * fracturePhase;
}

float moteField(vec2 uv, float scale, float threshold, float seed)
{
    vec2 gridUv = uv * scale;
    vec2 cell = floor(gridUv);
    vec2 localUv = fract(gridUv) - 0.5;

    float randomValue = hash21(cell + vec2(seed));
    float enabled = step(threshold, randomValue);

    vec2 offset = vec2(
        hash21(cell + vec2(seed + 11.1, 2.8)),
        hash21(cell + vec2(5.6, seed + 31.7))
    ) - 0.5;

    localUv -= offset * 0.65;

    float mote = 1.0 - smoothstep(0.025, 0.10, length(localUv));
    float flicker = 0.65 + sin(u_time * 5.0 + randomValue * 30.0) * 0.35;

    return mote * enabled * flicker;
}

float fragmentPiece(vec2 uv, vec2 direction, float distance, float progress, float seed)
{
    float fragmentPhase = smoothstep(0.72, 0.82, progress);
    vec2 center = direction * distance * fragmentPhase;

    vec2 localUv = rotateUv(uv - center, seed + u_time * 0.7);

    float shard = 1.0 - smoothstep(
        0.025,
        0.095,
        length(vec2(localUv.x * 0.55, localUv.y * 1.8))
    );

    float fade = 1.0 - smoothstep(0.84, 1.0, progress);
    return shard * fragmentPhase * fade;
}

void main()
{
    vec2 uv = fragUv * 2.0 - 1.0;
    float radius = length(uv);

    if (radius > 1.20)
    {
        discard;
    }

    float progress = clamp(effectProgress, 0.0, 1.0);
    float angle = atan(uv.y, uv.x);

    float turbulence = fbm(
        rotateUv(uv, u_time * 0.18) * 4.5
        + vec2(u_time * 0.12, -u_time * 0.08)
    );

    float fineNoise = fbm(
        uv * 10.0
        + vec2(-u_time * 0.22, u_time * 0.15)
    );

    float initialFlash = 1.0 - smoothstep(0.015, 0.12, progress);
    initialFlash *= 1.0 - smoothstep(0.05, 0.72, radius);

    float centerCore = 1.0 - smoothstep(0.015, 0.17, radius);
    centerCore *= 1.0 - smoothstep(0.12, 0.34, progress);

    float cracks = soulFractures(uv, progress);

    float compressionPhase = pulse(progress, 0.20, 0.31, 0.40);
    float compressionRadius = mix(0.30, 0.055, smoothstep(0.20, 0.34, progress));
    float compression = 1.0 - smoothstep(compressionRadius * 0.20, compressionRadius, radius);
    compression *= compressionPhase;

    float explosionPhase = smoothstep(0.32, 0.72, progress);
    float shockRadius = mix(0.05, 0.96, explosionPhase);

    float shockDistortion = (turbulence - 0.5) * 0.09 + (fineNoise - 0.5) * 0.035;
    float distortedRadius = radius + shockDistortion;
    float shockThickness = mix(0.19, 0.045, explosionPhase);

    float shockwave = 1.0 - smoothstep(
        shockThickness * 0.25,
        shockThickness,
        abs(distortedRadius - shockRadius)
    );

    shockwave *= smoothstep(0.30, 0.39, progress);
    shockwave *= 1.0 - smoothstep(0.72, 0.94, progress);

    float wispPhase = smoothstep(0.42, 0.62, progress);
    float wispFade = 1.0 - smoothstep(0.72, 1.0, progress);

    float radialFlow = fbm(vec2(
        angle * 2.8 - u_time * 0.30,
        radius * 6.0 - u_time * 0.25
    ));

    float wisps = smoothstep(0.42, 0.78, radialFlow);
    wisps *= 1.0 - smoothstep(0.18, 1.04, radius);
    wisps *= wispPhase * wispFade;

    float moteBirth = smoothstep(0.40, 0.56, progress);
    float moteFade = 1.0 - smoothstep(0.80, 1.0, progress);

    float motes = moteField(uv, 14.0, 0.72, 8.1);
    motes += moteField(uv, 22.0, 0.79, 34.7) * 0.70;
    motes *= moteBirth * moteFade;
    motes *= 1.0 - smoothstep(0.74, 1.10, radius);

    float soulCoreBirth = smoothstep(0.57, 0.69, progress);
    float soulCoreFade = 1.0 - smoothstep(0.84, 1.0, progress);

    float survivingCore = 1.0 - smoothstep(0.025, 0.095, radius);
    float corePulse = 0.80 + sin(u_time * 11.0) * 0.20;
    survivingCore *= soulCoreBirth * soulCoreFade * corePulse;
    survivingCore *= 1.0 - clamp(fractured, 0.0, 1.0);

    float fracturedAmount = clamp(fractured, 0.0, 1.0);

    float fracturedCore = 1.0 - smoothstep(0.025, 0.105, radius);
    float fracturedCoreBirth = smoothstep(0.57, 0.69, progress);
    float fracturedCoreDeath = 1.0 - smoothstep(0.76, 0.84, progress);
    float unstableFlicker = 0.45 + 0.55 * step(0.15, sin(u_time * 31.0 + fineNoise * 8.0));

    fracturedCore *= fracturedCoreBirth * fracturedCoreDeath * unstableFlicker * fracturedAmount;

    float soulCrack = 1.0 - smoothstep(
        0.012,
        0.038,
        abs(uv.x + sin(uv.y * 22.0) * 0.018)
    );

    soulCrack *= 1.0 - smoothstep(0.03, 0.13, radius);
    soulCrack *= smoothstep(0.63, 0.72, progress)
        * (1.0 - smoothstep(0.78, 0.86, progress))
        * fracturedAmount;

    float soulFragments = 0.0;
    soulFragments += fragmentPiece(uv, normalize(vec2( 1.00,  0.22)), 0.50, progress, 0.4);
    soulFragments += fragmentPiece(uv, normalize(vec2(-0.72,  0.88)), 0.42, progress, 1.2);
    soulFragments += fragmentPiece(uv, normalize(vec2(-0.92, -0.38)), 0.58, progress, 2.1);
    soulFragments += fragmentPiece(uv, normalize(vec2( 0.38, -1.00)), 0.46, progress, 3.0);
    soulFragments += fragmentPiece(uv, normalize(vec2( 0.76,  0.74)), 0.36, progress, 4.3);
    soulFragments *= fracturedAmount;

    vec3 whiteColor = vec3(1.0);
    vec3 cyanColor = mix(primaryColor, vec3(0.20, 0.94, 1.00), 0.60);
    vec3 paleCyan = mix(cyanColor, whiteColor, 0.65);
    vec3 violetColor = mix(secondaryColor, vec3(0.55, 0.10, 0.90), 0.60);
    vec3 deepViolet = vec3(0.18, 0.025, 0.34);
    vec3 goldWhite = vec3(1.00, 0.88, 0.48);
    vec3 fragmentBlue = vec3(0.35, 0.67, 1.00);

    vec3 finalColor = vec3(0.0);

    finalColor += whiteColor * initialFlash * 2.5;
    finalColor += paleCyan * centerCore * 2.0;

    finalColor += paleCyan * cracks * 1.8;
    finalColor += violetColor * cracks * 0.70;

    finalColor += whiteColor * compression * 2.8;
    finalColor += cyanColor * compression * 1.2;

    finalColor += paleCyan * shockwave * 1.65;
    finalColor += violetColor * shockwave * turbulence * 0.80;

    finalColor += cyanColor * wisps * 0.55;
    finalColor += violetColor * wisps * 0.50;

    finalColor += paleCyan * motes * 1.55;

    finalColor += goldWhite * survivingCore * 2.8;
    finalColor += whiteColor * survivingCore * 1.0;

    finalColor += paleCyan * fracturedCore * 1.6;
    finalColor += deepViolet * soulCrack * 3.4;
    finalColor += fragmentBlue * soulFragments * 2.5;

    float alpha =
        initialFlash * 0.92
        + centerCore
        + cracks * 0.92
        + compression
        + shockwave * 0.88
        + wisps * 0.34
        + motes * 0.85
        + survivingCore
        + fracturedCore
        + soulCrack * 0.85
        + soulFragments;

    alpha *= 1.0 - smoothstep(1.00, 1.19, radius);

    float packetAlpha = mix(primaryAlpha, secondaryAlpha, turbulence);
    alpha *= packetAlpha;

    if (alpha <= 0.008)
    {
        discard;
    }

    outColor = vec4(finalColor, clamp(alpha, 0.0, 1.0));
}
