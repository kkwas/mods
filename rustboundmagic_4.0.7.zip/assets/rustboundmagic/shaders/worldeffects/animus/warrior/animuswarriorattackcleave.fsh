#version 330 core

uniform vec3 primaryColor;
uniform vec3 secondaryColor;
uniform float primaryAlpha;
uniform float secondaryAlpha;
uniform float u_time;
uniform float effectProgress;

in vec2 fragUv;
out vec4 outColor;

float hash21(vec2 p)
{
    p = fract(p * vec2(123.34, 456.21));
    p += dot(p, p + 45.32);
    return fract(p.x * p.y);
}

float valueNoise(vec2 p)
{
    vec2 i = floor(p);
    vec2 f = fract(p);

    f = f * f * (3.0 - 2.0 * f);

    float a = hash21(i);
    float b = hash21(i + vec2(1.0, 0.0));
    float c = hash21(i + vec2(0.0, 1.0));
    float d = hash21(i + vec2(1.0, 1.0));

    return mix(mix(a, b, f.x), mix(c, d, f.x), f.y);
}

float fbm(vec2 p)
{
    float value = 0.0;
    float amplitude = 0.5;

    for (int i = 0; i < 4; i++)
    {
        value += valueNoise(p) * amplitude;
        p = p * 2.05 + vec2(7.2, 11.8);
        amplitude *= 0.5;
    }

    return value;
}

void main()
{
    vec2 p = fragUv * 2.0 - 1.0;

    float progress = clamp(effectProgress, 0.0, 1.0);
    float expansion = smoothstep(0.0, 0.82, progress);

    float radius = length(p);
    float angle = atan(p.x, p.y);

    float halfArc = 1.25;

    float arcMask = 1.0 - smoothstep(
        halfArc - 0.055,
        halfArc,
        abs(angle)
    );

    arcMask *= smoothstep(-0.08, 0.08, p.y);

    float slashRadius = mix(0.08, 0.72, expansion);

    float edgeNoise = fbm(
        vec2(
            angle * 8.0 + u_time * 0.10,
            radius * 12.0
        )
    );

    float distortedRadius = radius + (edgeNoise - 0.5) * 0.006;

    float normalizedAngle = clamp(abs(angle) / halfArc, 0.0, 1.0);

    float taper = 1.0 - smoothstep(
        0.48,
        1.0,
        normalizedAngle
    );

    taper = pow(taper, 0.62);

    float centerThickness = mix(
        0.090,
        0.060,
        expansion
    );

    float slashThickness = mix(
        0.0025,
        centerThickness,
        taper
    );

    float slashDistance = abs(
        distortedRadius - slashRadius
    );

    float slashBody = 1.0 - smoothstep(
        slashThickness * 0.76,
        slashThickness,
        slashDistance
    );

    float slashCore = 1.0 - smoothstep(
        slashThickness * 0.10,
        slashThickness * 0.42,
        slashDistance
    );

    slashBody *= arcMask;
    slashCore *= arcMask;

    float glow = 1.0 - smoothstep(
        slashThickness,
        slashThickness + 0.005,
        slashDistance
    );

    glow *= arcMask;

    glow = max(
        0.0,
        glow - slashBody * 0.92
    );

    float fadeIn = smoothstep(
        0.0,
        0.045,
        progress
    );

    float fadeOut = 1.0 - smoothstep(
        0.68,
        1.0,
        progress
    );

    float fade = fadeIn * fadeOut;

    slashBody *= fade;
    slashCore *= fade;
    glow *= fade;

    vec3 bodyColor = vec3(
    1.00,
    0.22,
    0.035
);

vec3 coreColor = vec3(
    1.00,
    0.82,
    0.20
);

vec3 glowColor = vec3(
    0.85,
    0.08,
    0.015
);

    vec3 color = vec3(0.0);

    color += bodyColor * slashBody * 1.10;
    color += coreColor * slashCore * 1.80;
    color += glowColor * glow * 0.22;

    float alpha = 0.0;

    alpha += slashBody * 0.96;
    alpha += slashCore;
    alpha += glow * 0.14;

    alpha = clamp(alpha, 0.0, 1.0);

    if (alpha <= 0.01)
    {
        discard;
    }

    outColor = vec4(
        color,
        alpha
    );
}