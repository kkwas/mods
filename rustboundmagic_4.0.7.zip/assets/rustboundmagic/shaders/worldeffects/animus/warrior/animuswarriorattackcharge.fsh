#version 330 core

uniform vec3 primaryColor;
uniform vec3 secondaryColor;
uniform float primaryAlpha;
uniform float secondaryAlpha;
uniform float u_time;
uniform float effectProgress;

in vec2 fragUv;
out vec4 outColor;

float hash21(vec2 p)
{
    p = fract(p * vec2(123.34, 456.21));
    p += dot(p, p + 45.32);
    return fract(p.x * p.y);
}

float noise21(vec2 p)
{
    vec2 i = floor(p);
    vec2 f = fract(p);

    f = f * f * (3.0 - 2.0 * f);

    float a = hash21(i);
    float b = hash21(i + vec2(1.0, 0.0));
    float c = hash21(i + vec2(0.0, 1.0));
    float d = hash21(i + vec2(1.0, 1.0));

    return mix(mix(a, b, f.x), mix(c, d, f.x), f.y);
}

void main()
{
    vec2 p = fragUv * 2.0 - 1.0;

    float progress = clamp(effectProgress, 0.0, 1.0);
    float expansion = smoothstep(0.0, 0.82, progress);

    float radius = length(p);
    float angle = atan(p.y, p.x);

    /*
        Full circular wind barrier.

        Start almost at full size and expand only slightly.
        The renderer is already doing the larger world-space scaling.
    */
    float barrierRadius = mix(0.62, 0.70, expansion);

    /*
        Thin, uniform circular barrier.
    */
    float barrierThickness = mix(
        0.050,
        0.035,
        expansion
    );

    /*
        Slight animated rippling so the circle does not look perfectly mechanical.
    */
    float rippleNoise = noise21(vec2(
        angle * 13.0 - u_time * 1.6,
        radius * 17.0 + u_time * 0.35
    ));

    float waveOffset = (rippleNoise - 0.5) * 0.014;

    float barrierDistance = abs(
        radius + waveOffset - barrierRadius
    );

    /*
        Main translucent wind ring.
    */
    float barrierBody = 1.0 - smoothstep(
        barrierThickness * 0.72,
        barrierThickness,
        barrierDistance
    );

    /*
        Thin bright white center line.
    */
    float leadingEdge = 1.0 - smoothstep(
        barrierThickness * 0.05,
        barrierThickness * 0.18,
        barrierDistance
    );

    /*
        Layered airflow moving through the ring.
    */
    float bandCoordinate =
        (radius - barrierRadius) / max(barrierThickness, 0.001);

    float movingBands =
        sin(
            bandCoordinate * 22.0
            + angle * 7.0
            - u_time * 12.0
        );

    movingBands = smoothstep(
        0.58,
        0.92,
        movingBands
    );

    movingBands *= barrierBody;

    /*
        Fine streaks traveling around the circular barrier.
    */
    float streakNoise = noise21(vec2(
        angle * 28.0 + u_time * 2.8,
        radius * 45.0 - u_time * 5.0
    ));

    float streaks = smoothstep(
        0.72,
        0.92,
        streakNoise
    );

    streaks *= barrierBody;

    /*
        Soft transparent wind wisps just outside the ring.
    */
    float outerWisp = 1.0 - smoothstep(
        barrierThickness,
        barrierThickness + 0.025,
        barrierDistance
    );

    outerWisp = max(
        0.0,
        outerWisp - barrierBody * 0.88
    );

    float fadeIn = smoothstep(
        0.0,
        0.045,
        progress
    );

    float fadeOut = 1.0 - smoothstep(
        0.68,
        1.0,
        progress
    );

    float fade = fadeIn * fadeOut;

    barrierBody *= fade;
    leadingEdge *= fade;
    movingBands *= fade;
    streaks *= fade;
    outerWisp *= fade;

    /*
        Static white / pale-gray wind colors.
    */
    vec3 bodyColor = vec3(0.82, 0.88, 0.96);
    vec3 edgeColor = vec3(1.00, 1.00, 1.00);
    vec3 bandColor = vec3(0.94, 0.97, 1.00);
    vec3 streakColor = vec3(0.72, 0.80, 0.90);
    vec3 wispColor = vec3(0.70, 0.76, 0.84);

    float alpha = 0.0;

    alpha += barrierBody * 0.48;
    alpha += leadingEdge * 0.82;
    alpha += movingBands * 0.30;
    alpha += streaks * 0.20;
    alpha += outerWisp * 0.12;

    alpha = clamp(alpha, 0.0, 1.0);

    if (alpha <= 0.01)
    {
        discard;
    }

    /*
        Keep RGB bright while alpha fades so the outside of the wind
        barrier becomes transparent instead of forming a black outline.
    */
    float edgeStrength = clamp(leadingEdge + movingBands * 0.45, 0.0, 1.0);
    float streakStrength = clamp(streaks * 0.35, 0.0, 1.0);

    vec3 color = bodyColor;

    color = mix(color, wispColor, outerWisp * 0.20);
    color = mix(color, bandColor, movingBands * 0.45);
    color = mix(color, streakColor, streakStrength);
    color = mix(color, edgeColor, edgeStrength);

    outColor = vec4(
        color,
        alpha
    );
}
