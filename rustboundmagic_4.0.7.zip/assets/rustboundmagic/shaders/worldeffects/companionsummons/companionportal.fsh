#version 330 core

uniform sampler2D primaryFb;
uniform sampler2D depthTex;

uniform vec2 invFrameSize;

uniform vec3 primaryColor;
uniform vec3 secondaryColor;

uniform float primaryAlpha;
uniform float secondaryAlpha;

uniform float u_time;
uniform float effectProgress;
uniform float effectDirection;
uniform float effectIntensity;
uniform float distortionStrength;
uniform float edgeWidth;
uniform float jaggedness;

in vec2 fragUv;

out vec4 outColor;


float hash21(vec2 p)
{
    p = fract(p * vec2(123.34, 456.21));
    p += dot(p, p + 45.32);

    return fract(p.x * p.y);
}


float valueNoise(vec2 p)
{
    vec2 i = floor(p);
    vec2 f = fract(p);

    f = f * f * (3.0 - 2.0 * f);

    float a = hash21(i);
    float b = hash21(i + vec2(1.0, 0.0));
    float c = hash21(i + vec2(0.0, 1.0));
    float d = hash21(i + vec2(1.0, 1.0));

    return mix(
        mix(a, b, f.x),
        mix(c, d, f.x),
        f.y
    );
}


float fbm(vec2 p)
{
    float total = 0.0;
    float amplitude = 0.5;

    for (int i = 0; i < 5; i++)
    {
        total += valueNoise(p) * amplitude;
        p = p * 2.03 + vec2(17.13, 9.71);
        amplitude *= 0.5;
    }

    return total;
}


float smoothPulse(float value, float center, float width)
{
    float distanceFromCenter = abs(value - center);

    return 1.0 - smoothstep(
        width * 0.35,
        width,
        distanceFromCenter
    );
}


float getOpenAmount(float progress, float direction)
{
    float summonOpen =
        smoothstep(0.00, 0.25, progress)
        *
        (1.0 - smoothstep(0.78, 1.00, progress));

    float dismissOpen =
        smoothstep(0.00, 0.12, progress)
        *
        (1.0 - smoothstep(0.48, 1.00, progress));

    return mix(summonOpen, dismissOpen, step(0.5, direction));
}


void main()
{
    vec2 centeredUv = fragUv * 2.0 - 1.0;

    /*
     * Makes the rift taller than it is wide.
     * Increasing X makes the final visual narrower.
     */
    vec2 tearUv = centeredUv;
    tearUv.x *= 1.65;
    tearUv.y *= 1.2;

    float openAmount = getOpenAmount(
        effectProgress,
        effectDirection
    );

    if (openAmount <= 0.001)
    {
        discard;
    }

    float timeSlow = u_time * 0.32;
    float timeFast = u_time * 0.85;

    /*
     * Noise used to bend the central tear.
     */
    float centerNoise =
        fbm(
            vec2(
                tearUv.y * 3.5 + timeSlow,
                tearUv.y * 1.7 - timeSlow
            )
        );

    centerNoise = centerNoise * 2.0 - 1.0;

    float secondCenterNoise =
        fbm(
            vec2(
                tearUv.y * 7.0 - timeSlow * 0.7,
                tearUv.y * 3.0 + timeSlow
            )
        );

    secondCenterNoise = secondCenterNoise * 2.0 - 1.0;

    float centerOffset =
        centerNoise * 0.11 * jaggedness
        +
        secondCenterNoise * 0.045 * jaggedness;

    /*
     * Width varies along Y so this looks like a crack,
     * not an oval portal.
     */
    float widthNoise =
        fbm(
            vec2(
                tearUv.y * 5.0,
                timeSlow * 0.45
            )
        );

    /*
     * Diamond/tear profile:
     * broad through the middle and narrowing continuously toward
     * a sharp point at both the top and bottom.
     */
    float normalizedHeight =
        clamp(
            abs(tearUv.y) / 0.6,
            0.0,
            1.0
        );

    float verticalShape =
        pow(
            1.0 - normalizedHeight,
            0.55
        );

    /*
     * Softly remove all remaining rim and branch energy at the tips.
     * This follows the same tapered profile instead of cutting the
     * seams off independently from the black center.
     */
    float seamVerticalMask =
        verticalShape
        *
        (
            1.0
            -
            smoothstep(
                0.72,
                1.0,
                normalizedHeight
            )
        );

    float baseHalfWidth =
        mix(
            0.015,
            0.38,
            openAmount
        );

    float widthVariation =
        mix(
            0.82,
            1.18,
            widthNoise
        );

    float varyingWidth =
        baseHalfWidth
        *
        verticalShape
        *
        widthVariation;

    /*
     * Spiked side profile.
     */
    float spikeWave =
        sin(
            tearUv.y * 22.0
            +
            timeFast * 1.7
            +
            centerNoise * 8.0
        );

    float secondSpikeWave =
        sin(
            tearUv.y * 43.0
            -
            timeFast * 1.15
        );

    float spikeAmount =
        pow(abs(spikeWave), 7.0) * 0.11
        +
        pow(abs(secondSpikeWave), 11.0) * 0.045;

    varyingWidth +=
        spikeAmount
        *
        openAmount
        *
        verticalShape
        *
        verticalShape
        *
        jaggedness;

    float horizontalDistance =
        abs(tearUv.x - centerOffset);

    /*
     * Main black interior.
     */
    float coreMask =
        1.0
        -
        smoothstep(
            varyingWidth * 0.72,
            varyingWidth,
            horizontalDistance
        );

    /*
     * Bright inner rim.
     */
    float innerRim =
        smoothPulse(
            horizontalDistance,
            varyingWidth,
            max(0.012, edgeWidth * 0.55)
        )
        *
        seamVerticalMask;

    /*
     * Wider outer energy around the crack.
     */
    float outerRim =
        smoothPulse(
            horizontalDistance,
            varyingWidth + edgeWidth * 1.35,
            edgeWidth * 2.4
        )
        *
        seamVerticalMask;

    /*
     * Large-scale branching crack field.
     */
    vec2 branchUv = tearUv;

    float branchNoise =
        fbm(
            branchUv * vec2(4.0, 7.5)
            +
            vec2(timeSlow * 0.35, -timeSlow * 0.18)
        );

    float branchNoiseFine =
        fbm(
            branchUv * vec2(11.0, 16.0)
            -
            vec2(timeSlow * 0.6, timeSlow * 0.25)
        );

    float branchLines =
        1.0
        -
        smoothstep(
            0.025,
            0.115,
            abs(branchNoise - 0.5)
        );

    float fineBranchLines =
        1.0
        -
        smoothstep(
            0.018,
            0.07,
            abs(branchNoiseFine - 0.5)
        );

    float distanceFromRift =
        max(
            0.0,
            horizontalDistance - varyingWidth
        );

    float branchFalloff =
        1.0
        -
        smoothstep(
            0.0,
            0.72,
            distanceFromRift
        );

    float branchMask =
        max(
            branchLines,
            fineBranchLines * 0.55
        )
        *
        branchFalloff
        *
        seamVerticalMask
        *
        openAmount;

    /*
     * Prevent the branching field from filling the black core.
     */
    branchMask *= 1.0 - coreMask;

    /*
     * Alternate purple and orange through animated noise.
     */
    float colorNoise =
        fbm(
            tearUv * vec2(5.0, 6.5)
            +
            vec2(
                timeSlow * 0.4,
                -timeSlow * 0.3
            )
        );

    float angularColor =
        sin(
            tearUv.y * 9.0
            +
            tearUv.x * 5.0
            -
            timeFast
        )
        *
        0.5
        +
        0.5;

    float colorMix =
        clamp(
            colorNoise * 0.65
            +
            angularColor * 0.35,
            0.0,
            1.0
        );

    vec3 energyColor =
        mix(
            primaryColor,
            secondaryColor,
            colorMix
        );

    /*
     * White-hot center inside the brightest rim.
     */
    vec3 brightRimColor =
        mix(
            energyColor,
            vec3(1.0, 0.84, 1.0),
            innerRim * 0.55
        );

    float pulse =
        0.76
        +
        sin(
            timeFast * 3.0
            +
            tearUv.y * 12.0
        )
        *
        0.16;

    float edgeEnergy =
        innerRim * 1.35
        +
        outerRim * 0.55
        +
        branchMask * 0.75;

    edgeEnergy *= pulse;
    edgeEnergy *= effectIntensity;
    edgeEnergy *= openAmount;

    /*
     * Screen-space distortion around the tear.
     */
    vec2 screenUv =
        gl_FragCoord.xy
        *
        invFrameSize;

    vec2 distortionDirection =
        vec2(
            sign(tearUv.x - centerOffset),
            centerNoise * 0.38
        );

    distortionDirection =
        normalize(
            distortionDirection
            +
            vec2(0.0001)
        );

    float distortionMask =
        max(
            coreMask * 0.85,
            outerRim * 0.7
        );

    distortionMask += branchMask * 0.17;

    float animatedDistortion =
        distortionStrength
        *
        distortionMask
        *
        openAmount
        *
        (
            0.7
            +
            centerNoise * 0.3
        );

    vec2 distortedScreenUv =
        screenUv
        +
        distortionDirection
        *
        animatedDistortion
        *
        invFrameSize
        *
        32.0;

    distortedScreenUv = clamp(
        distortedScreenUv,
        vec2(0.001),
        vec2(0.999)
    );

    vec3 sceneColor =
        texture(
            primaryFb,
            distortedScreenUv
        ).rgb;

    /*
     * Darken the center heavily while keeping slight
     * scene motion so it feels like a warped void.
     */
    vec3 voidColor =
        sceneColor
        *
        mix(
            1.0,
            0.025,
            coreMask
        );

    voidColor *=
        1.0
        -
        coreMask * 0.82;

    vec3 finalColor = voidColor;

    finalColor +=
        brightRimColor
        *
        edgeEnergy;

    /*
     * Slight colored haze surrounding the crack.
     */
    float haze =
        outerRim * 0.19
        +
        branchMask * 0.10;

    finalColor +=
        energyColor
        *
        haze
        *
        effectIntensity;

    /*
     * The center remains visually black.
     */
    finalColor =
        mix(
            finalColor,
            vec3(0.0),
            coreMask * 0.91
        );

    float alpha =
        max(
            coreMask,
            edgeEnergy
        );

    alpha = max(
        alpha,
        branchMask * 0.85
    );

    alpha *= openAmount;

    /*
     * Use the packet alpha values to influence the final result.
     */
    float combinedAlpha =
        mix(
            primaryAlpha,
            secondaryAlpha,
            colorMix
        );

    alpha *= combinedAlpha;

    /*
     * Keep the entire effect inside the pointed tear silhouette.
     * Alpha is tapered, while color remains bright until it fades out.
     */
    alpha *= seamVerticalMask;

    if (alpha <= 0.008)
    {
        discard;
    }

    outColor = vec4(
        finalColor,
        clamp(alpha, 0.0, 1.0)
    );
}