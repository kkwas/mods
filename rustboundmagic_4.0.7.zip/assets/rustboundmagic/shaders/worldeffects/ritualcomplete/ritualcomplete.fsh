#version 330 core

uniform vec3 primaryColor;
uniform vec3 secondaryColor;

uniform float primaryAlpha;
uniform float secondaryAlpha;

uniform float u_time;
uniform float effectProgress;

in vec2 fragUv;

out vec4 outColor;


//--------//--------//--------//--------//
//               Random                //
//--------//--------//--------//--------//

float hash21(vec2 p)
{
    p = fract(p * vec2(123.34, 456.21));
    p += dot(p, p + 45.32);

    return fract(p.x * p.y);
}


//--------//--------//--------//--------//
//                Noise                //
//--------//--------//--------//--------//

float valueNoise(vec2 p)
{
    vec2 i = floor(p);
    vec2 f = fract(p);

    f = f * f * (3.0 - 2.0 * f);

    float a = hash21(i);
    float b = hash21(i + vec2(1.0, 0.0));
    float c = hash21(i + vec2(0.0, 1.0));
    float d = hash21(i + vec2(1.0, 1.0));

    return mix(
        mix(a, b, f.x),
        mix(c, d, f.x),
        f.y
    );
}


float fbm(vec2 p)
{
    float total = 0.0;
    float amplitude = 0.5;

    for (int i = 0; i < 5; i++)
    {
        total += valueNoise(p) * amplitude;

        p = p * 2.03 + vec2(13.71, 8.41);
        amplitude *= 0.5;
    }

    return total;
}


//--------//--------//--------//--------//
//               Rotation              //
//--------//--------//--------//--------//

vec2 rotateUv(vec2 p, float angle)
{
    float c = cos(angle);
    float s = sin(angle);

    return vec2(
        c * p.x - s * p.y,
        s * p.x + c * p.y
    );
}


//--------//--------//--------//--------//
//               Star Shape            //
//--------//--------//--------//--------//

float starShape(vec2 uv)
{
    float horizontal =
        smoothstep(0.045, 0.0, abs(uv.y))
        *
        smoothstep(0.30, 0.0, abs(uv.x));

    float vertical =
        smoothstep(0.045, 0.0, abs(uv.x))
        *
        smoothstep(0.30, 0.0, abs(uv.y));

    float center =
        1.0
        -
        smoothstep(
            0.0,
            0.070,
            length(uv)
        );

    return max(
        center,
        max(horizontal, vertical)
    );
}


//--------//--------//--------//--------//
//               Star Field            //
//--------//--------//--------//--------//

float starField(
    vec2 uv,
    float time,
    float gridScale,
    float threshold,
    float seed)
{
    vec2 gridUv =
        uv * gridScale;

    vec2 cell =
        floor(gridUv);

    vec2 localUv =
        fract(gridUv) - 0.5;

    float randomValue =
        hash21(
            cell
            +
            vec2(seed)
        );

    float enabled =
        step(
            threshold,
            randomValue
        );

    vec2 randomOffset =
        vec2(
            hash21(cell + vec2(13.2 + seed, 8.7)),
            hash21(cell + vec2(5.4, 19.1 + seed))
        )
        -
        0.5;

    localUv -=
        randomOffset * 0.60;

    /*
     * The position does NOT use time.
     * Only brightness changes.
     */
    float flicker =
        0.60
        +
        sin(
            time * 3.5
            +
            randomValue * 35.0
        )
        *
        0.40;

    return
        starShape(localUv)
        *
        enabled
        *
        flicker;
}


//--------//--------//--------//--------//
//            Purple Nebula            //
//--------//--------//--------//--------//

float getNebula(
    vec2 uv,
    float distanceFromCenter,
    float time)
{
    /*
     * Only the nebula rotates.
     */
    vec2 rotatedUv =
        rotateUv(
            uv,
            time * 0.055
        );

    vec2 nebulaUv =
        vec2(
            rotatedUv.x * 1.10,
            rotatedUv.y * 0.78
        );

    float angle =
        atan(
            nebulaUv.y,
            nebulaUv.x
        );

    float radius =
        length(nebulaUv);

    float spiral =
        angle
        +
        radius * 5.5
        -
        time * 0.12;

    vec2 spiralUv =
        vec2(
            cos(spiral),
            sin(spiral)
        )
        *
        radius * 3.0;

    float cloudLarge =
        fbm(
            spiralUv * 1.20
            +
            vec2(
                time * 0.035,
                -time * 0.025
            )
        );

    float cloudMedium =
        fbm(
            nebulaUv * 4.5
            +
            vec2(
                -time * 0.045,
                time * 0.030
            )
        );

    float cloudFine =
        fbm(
            nebulaUv * 9.0
            +
            vec2(
                time * 0.070,
                time * 0.040
            )
        );

    float cloud =
        cloudLarge * 0.50
        +
        cloudMedium * 0.35
        +
        cloudFine * 0.15;

    float nebula =
        smoothstep(
            0.38,
            0.76,
            cloud
        );

    nebula *=
        1.0
        -
        smoothstep(
            0.35,
            1.02,
            distanceFromCenter
        );

    return nebula;
}


//--------//--------//--------//--------//
//                 Main                //
//--------//--------//--------//--------//

void main()
{
    vec2 centeredUv =
        fragUv * 2.0 - 1.0;

    float distanceFromCenter =
        length(centeredUv);

    if (distanceFromCenter > 1.15)
    {
        discard;
    }


    //--------//--------//--------//--------//
    //               Timing                //
    //--------//--------//--------//--------//

    float progress =
        clamp(
            effectProgress,
            0.0,
            1.0
        );

    float birthPhase =
        smoothstep(
            0.0,
            0.16,
            progress
        );

    float expansionPhase =
        smoothstep(
            0.08,
            0.72,
            progress
        );

    float fadePhase =
        1.0
        -
        smoothstep(
            0.78,
            0.96,
            progress
        );


    //--------//--------//--------//--------//
    //           Cyan Mana Flow            //
    //--------//--------//--------//--------//

    float angle =
        atan(
            centeredUv.y,
            centeredUv.x
        );

    float timeSlow =
        u_time * 0.16;

    float timeFast =
        u_time * 0.42;

    vec2 swirlUv =
        centeredUv * 3.5;

    float swirlNoise =
        fbm(
            vec2(
                angle * 2.2
                + timeSlow,
                distanceFromCenter * 5.0
                - timeSlow * 1.5
            )
        );

    float turbulence =
        fbm(
            swirlUv
            +
            vec2(
                timeSlow * 0.75,
                -timeSlow * 0.45
            )
        );

    float fineTurbulence =
        fbm(
            centeredUv * 8.0
            +
            vec2(
                -timeFast * 0.25,
                timeFast * 0.18
            )
        );


    //--------//--------//--------//--------//
    //            Compressed Core           //
    //--------//--------//--------//--------//

    float coreRadius =
        mix(
            0.25,
            0.055,
            birthPhase
        );

    float core =
        1.0
        -
        smoothstep(
            coreRadius * 0.15,
            coreRadius,
            distanceFromCenter
        );

    core *=
        1.0
        -
        smoothstep(
            0.18,
            0.48,
            progress
        );


    //--------//--------//--------//--------//
    //           Expanding Mana Ring        //
    //--------//--------//--------//--------//

    float ringRadius =
        mix(
            0.10,
            0.88,
            expansionPhase
        );

    float ringDistortion =
        (swirlNoise - 0.5) * 0.095
        +
        (turbulence - 0.5) * 0.055;

    float distortedDistance =
        distanceFromCenter
        +
        ringDistortion;

    float ringThickness =
        mix(
            0.22,
            0.045,
            expansionPhase
        );

    float ring =
        1.0
        -
        smoothstep(
            ringThickness * 0.35,
            ringThickness,
            abs(
                distortedDistance
                - ringRadius
            )
        );


    //--------//--------//--------//--------//
    //            Mana Saturation           //
    //--------//--------//--------//--------//

    float manaFieldRadius =
        mix(
            0.12,
            0.92,
            expansionPhase
        );

    float manaField =
        1.0
        -
        smoothstep(
            manaFieldRadius * 0.25,
            manaFieldRadius,
            distanceFromCenter
        );

    manaField *=
        mix(
            0.95,
            0.18,
            expansionPhase
        );

    manaField *=
        0.65
        +
        turbulence * 0.35;


    //--------//--------//--------//--------//
    //              Wispy Edge             //
    //--------//--------//--------//--------//

    float wispNoise =
        smoothstep(
            0.34,
            0.78,
            turbulence * 0.70
            +
            fineTurbulence * 0.30
        );

    float wisps =
        ring
        *
        wispNoise;

    float outerVeil =
        1.0
        -
        smoothstep(
            0.08,
            0.25,
            abs(
                distortedDistance
                -
                (
                    ringRadius - 0.08
                )
            )
        );

    outerVeil *=
        smoothstep(
            0.38,
            0.76,
            turbulence
        );

    outerVeil *=
        expansionPhase;


    //--------//--------//--------//--------//
    //           Galactic Nebula           //
    //--------//--------//--------//--------//

    float nebula =
        getNebula(
            centeredUv,
            distanceFromCenter,
            u_time
        );

    float nebulaBirth =
        smoothstep(
            0.08,
            0.30,
            progress
        );

    nebula *=
        nebulaBirth;

    nebula *=
        1.0
        -
        smoothstep(
            manaFieldRadius,
            manaFieldRadius + 0.15,
            distanceFromCenter
        );


    //--------//--------//--------//--------//
    //          Stationary Star Fields      //
    //--------//--------//--------//--------//

    /*
     * IMPORTANT:
     *
     * centeredUv is passed directly into every star field.
     * No rotateUv() is used here.
     *
     * The stars therefore remain in fixed positions.
     * The time parameter only controls their twinkle.
     */

    float starsLarge =
        starField(
            centeredUv,
            u_time,
            9.0,
            0.72,
            3.7
        );

    float starsSmall =
        starField(
            centeredUv,
            u_time * 1.3,
            17.0,
            0.76,
            27.4
        );

    float starsRare =
        starField(
            centeredUv,
            u_time * 0.7,
            6.0,
            0.88,
            61.2
        );

    float starBirth =
        smoothstep(
            0.08,
            0.25,
            progress
        );

    float starBoundary =
        1.0
        -
        smoothstep(
            ringRadius,
            ringRadius + 0.20,
            distanceFromCenter
        );

    starsLarge *=
        starBirth
        *
        starBoundary
        *
        fadePhase;

    starsSmall *=
        starBirth
        *
        starBoundary
        *
        fadePhase;

    starsRare *=
        starBirth
        *
        starBoundary
        *
        fadePhase;


    //--------//--------//--------//--------//
    //               Colors                //
    //--------//--------//--------//--------//

    vec3 whiteColor =
        vec3(
            1.0,
            1.0,
            1.0
        );

    vec3 cyanColor =
        mix(
            primaryColor,
            secondaryColor,
            0.35
            +
            turbulence * 0.45
        );

    vec3 paleCyan =
        mix(
            cyanColor,
            whiteColor,
            0.55
        );

    vec3 deepPurple =
        vec3(
            0.18,
            0.035,
            0.36
        );

    vec3 richPurple =
        vec3(
            0.43,
            0.10,
            0.68
        );

    vec3 violet =
        vec3(
            0.62,
            0.22,
            0.90
        );

    vec3 galaxyBlue =
        vec3(
            0.20,
            0.48,
            1.00
        );

    vec3 starWhite =
        vec3(
            0.90,
            0.97,
            1.00
        );


    //--------//--------//--------//--------//
    //          Galaxy Composition          //
    //--------//--------//--------//--------//

    float purpleVariation =
        fbm(
            centeredUv * 3.0
            +
            vec2(
                u_time * 0.025,
                0.0
            )
        );

    vec3 nebulaColor =
        mix(
            deepPurple,
            richPurple,
            purpleVariation
        );

    nebulaColor =
        mix(
            nebulaColor,
            violet,
            nebula * 0.30
        );


    //--------//--------//--------//--------//
    //           Mana Composition           //
    //--------//--------//--------//--------//

    float brightRing =
        ring
        *
        (
            0.75
            +
            fineTurbulence * 0.55
        );

    /*
     * Purple galaxy is behind everything else.
     */
    vec3 finalColor =
        nebulaColor
        *
        nebula
        *
        0.85;

    finalColor +=
        richPurple
        *
        manaField
        *
        nebula
        *
        0.30;


    /*
     * Cyan mana explosion over the nebula.
     */
    finalColor +=
        cyanColor
        *
        (
            manaField * 0.42
            +
            outerVeil * 0.42
        );

    finalColor +=
        paleCyan
        *
        (
            brightRing * 1.35
            +
            wisps * 0.80
        );


    /*
     * White-hot center.
     */
    finalColor +=
        whiteColor
        *
        core
        *
        2.3;


    //--------//--------//--------//--------//
    //           Initial Flash             //
    //--------//--------//--------//--------//

    float releaseFlash =
        1.0
        -
        smoothstep(
            0.02,
            0.18,
            progress
        );

    releaseFlash *=
        1.0
        -
        smoothstep(
            0.0,
            0.42,
            distanceFromCenter
        );

    finalColor +=
        whiteColor
        *
        releaseFlash
        *
        1.75;


    //--------//--------//--------//--------//
    //               Stars                 //
    //--------//--------//--------//--------//

    finalColor +=
        galaxyBlue
        *
        starsSmall
        *
        1.25;

    finalColor +=
        starWhite
        *
        starsLarge
        *
        2.20;

    finalColor +=
        whiteColor
        *
        starsRare
        *
        2.80;


    //--------//--------//--------//--------//
    //                Alpha                 //
    //--------//--------//--------//--------//

    float alpha =
        core
        +
        brightRing * 0.92
        +
        wisps * 0.72
        +
        outerVeil * 0.28
        +
        manaField * 0.20
        +
        nebula * 0.30;

    alpha *=
        mix(
            1.0,
            0.48,
            expansionPhase
        );

    alpha *=
        fadePhase;

    float starAlpha =
        max(
            starsLarge * 0.90,
            max(
                starsSmall * 0.55,
                starsRare
            )
        );

    alpha =
        max(
            alpha,
            starAlpha * fadePhase
        );

    float packetAlpha =
        mix(
            primaryAlpha,
            secondaryAlpha,
            turbulence
        );

    alpha *=
        packetAlpha;


    //--------//--------//--------//--------//
    //             Outer Fade              //
    //--------//--------//--------//--------//

    alpha *=
        1.0
        -
        smoothstep(
            0.90,
            1.12,
            distanceFromCenter
        );

    if (alpha <= 0.008)
    {
        discard;
    }

    outColor =
        vec4(
            finalColor,
            clamp(
                alpha,
                0.0,
                1.0
            )
        );
}