#version 330 core

uniform sampler2D primaryFb;

/*
    0.0 = original vanilla night vision
    1.0 = completely recolored
*/
uniform float effectStrength;

/*
    Actual desired color, normalized from 0 to 1.

    Blue:
        vec3(0.45, 0.70, 1.00)

    Light purple:
        vec3(0.82, 0.62, 1.00)

    Yellow/gold:
        vec3(1.00, 0.88, 0.40)
*/
uniform vec3 tintColor;

in vec2 uv;
out vec4 outColor;

void main()
{
    vec4 scene = texture(primaryFb, uv);
    vec3 originalColor = scene.rgb;

    /*
        Extract perceived brightness from the green-heavy
        vanilla night-vision image.
    */
    float luminance = dot(
        originalColor,
        vec3(0.2126, 0.7152, 0.0722)
    );

    /*
        Rebuild the image using the requested tint.
    */
    vec3 recolored = tintColor * luminance;

    /*
        Preserve some texture contrast and bright highlights.
    */
    recolored += originalColor * 0.12;

    vec3 finalColor = mix(
        originalColor,
        recolored,
        clamp(effectStrength, 0.0, 1.0)
    );

    outColor = vec4(
        clamp(finalColor, 0.0, 1.0),
        scene.a
    );
}