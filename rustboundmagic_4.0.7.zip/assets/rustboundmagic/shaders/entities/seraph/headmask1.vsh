#version 330 core

in vec3 vertexPosition;

uniform mat4 projectionMatrix;
uniform mat4 modelViewMatrix;

void main()
{
    gl_Position =
        projectionMatrix *
        modelViewMatrix *
        vec4(vertexPosition, 1.0);
}