#version 330 core

uniform sampler2D primaryFb;
uniform vec2 invFrameSize;

out vec4 outColor;

void main()
{
    vec2 screenUv =
        gl_FragCoord.xy *
        invFrameSize;

    outColor =
        texture(
            primaryFb,
            screenUv
        );
}